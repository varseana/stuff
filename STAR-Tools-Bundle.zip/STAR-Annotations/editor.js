// toggle del tema (ya no se usa, siempre es dark glass)
const themeBtn = document.getElementById("themeToggle");

function applyTheme(dark) {
  document.body.classList.toggle("dark", dark);
  themeBtn.textContent = dark ? "☀️" : "🌙";
}

chrome.storage.local.get(["qaDarkMode"], (res) => applyTheme(res.qaDarkMode || false));

themeBtn.onclick = () => {
  const isDark = !document.body.classList.contains("dark");
  chrome.storage.local.set({ qaDarkMode: isDark });
  applyTheme(isDark);
};

// cat-headers colapsables
document.querySelectorAll(".cat-header").forEach(function(h) {
  h.onclick = function() {
    h.classList.toggle("collapsed");
    var list = h.nextElementSibling;
    if (list) list.classList.toggle("collapsed");
  };
});

const LISTS = {
  GRNT: document.getElementById("grntList"),
  NOGRNT: document.getElementById("nogrntList"),
  Miscellaneous: document.getElementById("miscList")
};

const DEFAULT_COLORS = { GRNT: "#006878", NOGRNT: "#c0392b", Miscellaneous: "#2c3e50" };
let buttons = [];
let catColors = { ...DEFAULT_COLORS };
let folders = [];
let dragIdx = null;

function load() {
  chrome.storage.local.get(["qaButtons", "qaCatColors", "qaFolders"], (res) => {
    buttons = res.qaButtons || [];
    catColors = { ...DEFAULT_COLORS, ...(res.qaCatColors || {}) };
    folders = res.qaFolders || [];
    document.getElementById("colorGRNT").value = catColors.GRNT;
    document.getElementById("colorNOGRNT").value = catColors.NOGRNT;
    document.getElementById("colorMiscellaneous").value = catColors.Miscellaneous;
    renderFolders();
    render();
  });
}

function save() {
  chrome.storage.local.set({ qaButtons: buttons, qaCatColors: catColors, qaFolders: folders });
}

// poblar todos los selects de folder (add form + cada row)
function populateFolderSelects() {
  document.querySelectorAll(".folder-select").forEach(function(sel) {
    var val = sel.value;
    sel.innerHTML = '<option value="">No folder</option>';
    folders.forEach(function(f) {
      var opt = document.createElement("option");
      opt.value = f; opt.textContent = f;
      sel.appendChild(opt);
    });
    sel.value = val;
  });
}

function renderFolders() {
  var list = document.getElementById("folderList");
  list.innerHTML = "";
  folders.forEach(function(f, i) {
    var tag = document.createElement("span");
    tag.style.cssText = "display:inline-flex;align-items:center;gap:4px;padding:3px 8px;border-radius:8px;font-size:11px;background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.12);color:rgba(255,255,255,0.8);";
    tag.textContent = f;
    var del = document.createElement("span");
    del.textContent = "✕";
    del.style.cssText = "cursor:pointer;opacity:0.5;font-size:10px;";
    del.title = "Delete folder";
    del.onclick = function() {
      if (!confirm("Delete folder '" + f + "'? Buttons in it will become unassigned.")) return;
      folders.splice(i, 1);
      // limpiar folder de botones que la tenian
      buttons.forEach(function(b) { if (b.folder === f) b.folder = ""; });
      save();
      renderFolders();
      populateFolderSelects();
      render();
    };
    tag.appendChild(del);
    list.appendChild(tag);
  });
  populateFolderSelects();
}

document.getElementById("addFolderBtn").onclick = function() {
  var input = document.getElementById("newFolderName");
  var name = input.value.trim();
  if (!name) return;
  if (folders.indexOf(name) !== -1) { alert("Folder already exists"); return; }
  folders.push(name);
  save();
  renderFolders();
  input.value = "";
};

function render() {
  for (const cat of Object.keys(LISTS)) {
    const list = LISTS[cat];
    list.innerHTML = "";
    const catBtns = buttons.filter(b => b.category === cat);

    if (catBtns.length === 0) {
      const empty = document.createElement("div");
      empty.className = "empty";
      empty.textContent = "No buttons yet";
      list.appendChild(empty);
      continue;
    }

    catBtns.forEach(b => {
      const globalIdx = buttons.indexOf(b);
      const row = document.createElement("div");
      row.className = "btn-row";
      row.draggable = true;
      row.dataset.idx = globalIdx;

      row.ondragstart = (e) => {
        dragIdx = globalIdx;
        row.classList.add("dragging");
        e.dataTransfer.effectAllowed = "move";
      };
      row.ondragend = () => {
        row.classList.remove("dragging");
        document.querySelectorAll(".drag-over").forEach(el => el.classList.remove("drag-over"));
        dragIdx = null;
      };
      row.ondragover = (e) => {
        e.preventDefault();
        row.classList.add("drag-over");
      };
      row.ondragleave = () => row.classList.remove("drag-over");
      row.ondrop = (e) => {
        e.preventDefault();
        row.classList.remove("drag-over");
        const toIdx = parseInt(row.dataset.idx);
        if (dragIdx !== null && dragIdx !== toIdx) {
          const item = buttons.splice(dragIdx, 1)[0];
          buttons.splice(toIdx > dragIdx ? toIdx - 1 : toIdx, 0, item);
          save();
          render();
        }
      };

      const drag = document.createElement("span");
      drag.className = "btn-drag";
      drag.textContent = "⠿";

      const colorDot = document.createElement("input");
      colorDot.type = "color";
      colorDot.className = "btn-color-dot";
      colorDot.value = b.color || "#e6e6e6";
      colorDot.title = "Change button color";
      colorDot.onchange = () => {
        buttons[globalIdx].color = colorDot.value;
        save();
      };

      const title = document.createElement("span");
      title.className = "btn-title";
      title.textContent = b.title;

      const preview = document.createElement("span");
      preview.className = "btn-preview";
      preview.textContent = b.content.substring(0, 60);

      const editBtn = document.createElement("button");
      editBtn.className = "btn-edit";
      editBtn.textContent = "✏️";
      editBtn.onclick = () => {
        const newTitle = prompt("Title:", b.title);
        if (!newTitle) return;
        const newContent = prompt("Content:", b.content);
        if (!newContent) return;
        buttons[globalIdx].title = newTitle;
        buttons[globalIdx].content = newContent;
        save();
        render();
      };

      const delBtn = document.createElement("button");
      delBtn.className = "btn-del";
      delBtn.textContent = "✖";
      delBtn.onclick = () => {
        if (!confirm("Delete '" + b.title + "'?")) return;
        buttons.splice(globalIdx, 1);
        save();
        render();
      };

      row.append(drag, colorDot, title, preview, editBtn, delBtn);

      // folder select per row
      const folderSel = document.createElement("select");
      folderSel.className = "folder-select";
      folderSel.style.cssText = "font-size:10px;padding:2px 4px;max-width:80px;";
      folderSel.innerHTML = '<option value="">No folder</option>';
      folders.forEach(function(f) {
        var opt = document.createElement("option");
        opt.value = f; opt.textContent = f;
        folderSel.appendChild(opt);
      });
      folderSel.value = b.folder || "";
      folderSel.onchange = function() {
        buttons[globalIdx].folder = folderSel.value;
        save();
      };
      row.insertBefore(folderSel, editBtn);

      list.appendChild(row);
    });
  }
}

// guardar colores de las categorias
document.getElementById("saveColorsBtn").onclick = () => {
  catColors.GRNT = document.getElementById("colorGRNT").value;
  catColors.NOGRNT = document.getElementById("colorNOGRNT").value;
  catColors.Miscellaneous = document.getElementById("colorMiscellaneous").value;
  save();
  alert("✅ Colors saved!");
};

// agregar boton nuevo
document.getElementById("addBtn").onclick = () => {
  const category = document.getElementById("addCategory").value;
  const title = document.getElementById("addTitle").value.trim();
  const content = document.getElementById("addContent").value.trim();
  const color = document.getElementById("addColor").value;
  const folder = document.getElementById("addFolder").value;

  if (!title || !content) {
    alert("Fill in title and content");
    return;
  }

  buttons.push({ category, title, content, color, folder });
  save();
  render();

  document.getElementById("addTitle").value = "";
  document.getElementById("addContent").value = "";
};

// exportar botones a json
document.getElementById("exportBtn").onclick = () => {
  const data = { buttons, catColors };
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "quick-annotations.json";
  a.click();
  URL.revokeObjectURL(url);
};

// importar botones desde json (reemplaza todo)
const importFile = document.getElementById("importFile");
document.getElementById("importBtn").onclick = () => importFile.click();

importFile.onchange = (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (ev) => {
    try {
      const imported = JSON.parse(ev.target.result);
      if (Array.isArray(imported)) {
        buttons = imported;
      } else if (imported.buttons) {
        buttons = imported.buttons;
        if (imported.catColors) catColors = { ...DEFAULT_COLORS, ...imported.catColors };
      } else {
        throw new Error("Invalid format");
      }
      save();
      load();
      document.getElementById("importStatus").textContent = "✅ Imported " + buttons.length + " buttons (replaced all)";
      document.getElementById("importStatus").style.color = "green";
    } catch(err) {
      document.getElementById("importStatus").textContent = "❌ Invalid file: " + err.message;
      document.getElementById("importStatus").style.color = "red";
    }
  };
  reader.readAsText(file);
  importFile.value = "";
};

load();
