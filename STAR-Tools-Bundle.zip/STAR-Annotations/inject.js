if (!window._qaInjected) {
window._qaInjected = true;

// salir rapido si este frame no tiene nada que nos interese
// esto evita correr 7 intervals en los 22 iframes de paragon
var _qaHasTarget = !!(document.getElementById("ta_claimActionAnnotation") ||
  document.getElementById("email-body-id") ||
  document.getElementById("btn_claimActionPreviewNative") ||
  document.getElementById("page-left-sidebar") ||
  document.getElementById("queue_name"));

// chequear si podemos acceder al top frame (same-origin paragon frames)
var _canAccessTop = false;
try { _canAccessTop = !!window.top.document.querySelectorAll; } catch(e) {}

if (!_qaHasTarget && !_canAccessTop && window !== window.top) {
  // nada que hacer en este frame ~ no gastar cpu
} else {

// limpiar returnData si el caso cambio
var _caseId = (document.getElementById("claim_id") || {}).value || (location.href.match(/caseId=(\d+)/i) || [])[1] || "";
if (_caseId) {
  chrome.storage.local.get(["returnData"], function(res) {
    var rd = res.returnData || {};
    if (rd._caseId && rd._caseId !== _caseId) {
      chrome.storage.local.set({ returnData: { _caseId: _caseId } });
    } else if (!rd._caseId) {
      rd._caseId = _caseId;
      chrome.storage.local.set({ returnData: rd });
    }
  });
}

// helper ~ buscar iframes hermanos desde el top frame
function getSiblingDocs() {
  var docs = [];
  var topDoc;
  try { topDoc = window.top.document; } catch(e) { return [document]; }
  topDoc.querySelectorAll("iframe").forEach(function(f) {
    try { if (f.contentDocument) docs.push(f.contentDocument); } catch(e) {}
  });
  return docs;
}

var CATEGORIES = ["GRNT", "NOGRNT", "Miscellaneous"];
var DEFAULT_COLORS = { GRNT: "#006878", NOGRNT: "#c0392b", Miscellaneous: "#2c3e50" };
var appendMode = false;

function textColorFor(hex) {
  var r = parseInt(hex.slice(1,3), 16);
  var g = parseInt(hex.slice(3,5), 16);
  var b = parseInt(hex.slice(5,7), 16);
  return (r * 0.299 + g * 0.587 + b * 0.114) > 150 ? "#333" : "#fff";
}

function findTextarea() {
  // primero revisamos este documento directamente
  var ta = document.getElementById("ta_claimActionAnnotation");
  if (ta) return { textarea: ta, doc: document };
  // Then check iframes (needed if script runs in parent frame)
  var iframes = document.querySelectorAll("iframe[srcdoc]");
  for (var i = 0; i < iframes.length; i++) {
    try {
      var doc = iframes[i].contentDocument;
      if (doc) {
        var ta2 = doc.getElementById("ta_claimActionAnnotation");
        if (ta2) return { textarea: ta2, doc: doc };
      }
    } catch(e) {}
  }
  return null;
}

function injectPanel() {
  var found = findTextarea();
  if (!found) return;
  if (found.doc.getElementById("qa-panel")) return;
  // evitar que otros frames inyecten ~ marcamos el textarea
  if (found.textarea.dataset.qaOwned) return;
  found.textarea.dataset.qaOwned = "1";

  var textarea = found.textarea;
  var doc = found.doc;

  if (!doc.getElementById("qa-style")) {
    var style = doc.createElement("style");
    style.id = "qa-style";
    // ⁘[ DESIGN TOKENS ]⁘
    // surface:#fff  surface-muted:#f7f7f7  border:#e0e0e0  border-subtle:#eee
    // text-primary:#333  text-secondary:#666  text-muted:#999  active:#232f3e
    // ⁘[ injected css ]⁘
    // paragon-native feel ~ blends with amazon UI, doesn't scream "extension"
    // 60% white surface, 30% warm gray (#f7f7f7, #eee), 10% category color accents
    // spacing: 4px base grid | radius: 4px (professional, B2B) | motion: 150ms ease
    style.textContent =
      // panel ~ sits below textarea, thin top border separates it
      "#qa-panel { margin-top:8px; padding-top:10px; border-top:1px solid #ddd; font-family:'Amazon Ember','Segoe UI',Arial,sans-serif; font-size:11px; line-height:1.4; }" +
      // toolbar row
      ".qa-toolbar { display:flex; align-items:center; gap:8px; margin-bottom:10px; flex-wrap:wrap; }" +
      // folder pills ~ pill shape (12px radius = friendly), dark active state
      ".qa-pills { display:flex; gap:4px; flex-wrap:wrap; }" +
      ".qa-pill { padding:3px 10px; border:1px solid #ddd; border-radius:12px; font-size:10px; cursor:pointer; background:#fff; color:#888; font-weight:600; transition:all 150ms cubic-bezier(0.4,0,0.2,1); user-select:none; }" +
      ".qa-pill:hover { background:#f5f5f5; border-color:#aaa; color:#333; }" +
      ".qa-pill.active { background:#232f3e; color:#fff; border-color:#232f3e; }" +
      // sections
      ".qa-section { margin-bottom:6px; }" +
      // headers ~ the dominant element. uppercase, accented left border, muted surface
      // visually heavier than buttons so hierarchy is felt
      ".qa-header { padding:6px 12px; font-weight:700; font-size:12px; text-transform:uppercase; letter-spacing:0.8px; border-radius:3px; margin-bottom:6px; border-left:3px solid currentColor; background:#f5f5f5; transition:background 150ms ease; }" +
      ".qa-header:hover { background:#efefef; }" +
      // button grid
      ".qa-buttons { display:flex; flex-wrap:wrap; gap:4px; padding:2px 0; }" +
      // annotation buttons ~ user-colored, subtle resting shadow, lift on hover
      // radius 3px = professional, matches paragon native buttons
      ".qa-btn { padding:4px 10px; border:none; border-radius:3px; font-size:11px; cursor:pointer; font-weight:600; box-shadow:0 1px 2px rgba(0,0,0,0.08); transition:transform 150ms cubic-bezier(0.4,0,0.2,1),box-shadow 150ms cubic-bezier(0.4,0,0.2,1); }" +
      ".qa-btn:hover { transform:scale(1.06); box-shadow:0 2px 6px rgba(0,0,0,0.12),0 4px 12px rgba(0,0,0,0.06); }" +
      ".qa-btn:active { transform:scale(0.95); box-shadow:0 1px 2px rgba(0,0,0,0.1); }" +
      // utility buttons hover ~ subtle lift, bg shift
      "#qa-auto-email:hover { transform:scale(1.03); box-shadow:0 2px 6px rgba(46,125,50,0.15); background:#c8e6c9; }" +
      "#qa-fill-tracking:hover { transform:scale(1.03); box-shadow:0 2px 6px rgba(91,33,182,0.15); background:#d1c4e9; }" +
      "#qa-auto-email:active,#qa-fill-tracking:active { transform:scale(0.97); box-shadow:none; }" +
      // empty state
      ".qa-empty { color:#bbb; font-size:10px; font-style:italic; padding:4px 0; }";
    doc.head.appendChild(style);
  }

  chrome.storage.local.get(["qaCatColors", "qaButtons", "qaActiveFolder", "qaAppendMode"], function(res) {
    var colors = {};
    var stored = res.qaCatColors || {};
    for (var k in DEFAULT_COLORS) colors[k] = stored[k] || DEFAULT_COLORS[k];
    var activeFolder = res.qaActiveFolder || "";
    appendMode = !!res.qaAppendMode;

    // extraer folders de los botones + qaFolders de storage
    var allButtons = res.qaButtons || [];
    var folderSet = {};
    for (var bi = 0; bi < allButtons.length; bi++) {
      var bf = allButtons[bi].folder;
      if (bf) folderSet[bf] = true;
    }
    var folders = Object.keys(folderSet).sort();

    var panel = doc.createElement("div");
    panel.id = "qa-panel";

    // ⁘[ TOOLBAR: append toggle + folder pills ~ todo en una linea ]⁘
    var toolbar = doc.createElement("div");
    toolbar.className = "qa-toolbar";

    // append toggle ~ pill style, persiste en storage
    var appendBtn = doc.createElement("span");
    appendBtn.className = "qa-pill" + (appendMode ? " active" : "");
    appendBtn.textContent = appendMode ? "Append ON" : "Append";
    appendBtn.onclick = function() {
      appendMode = !appendMode;
      appendBtn.classList.toggle("active", appendMode);
      appendBtn.textContent = appendMode ? "Append ON" : "Append";
      chrome.storage.local.set({ qaAppendMode: appendMode });
    };
    toolbar.appendChild(appendBtn);

    // folder pills ~ extraidos de los botones, solo si hay al menos 1
    if (folders.length > 0) {
      var sep = doc.createElement("span");
      sep.style.cssText = "width:1px;height:16px;background:#e0e0e0;";
      toolbar.appendChild(sep);

      var allPill = doc.createElement("span");
      allPill.className = "qa-pill" + (!activeFolder ? " active" : "");
      allPill.textContent = "All";
      allPill.onclick = function() {
        activeFolder = "";
        chrome.storage.local.set({ qaActiveFolder: "" });
        toolbar.querySelectorAll(".qa-pill").forEach(function(p) { if (p !== appendBtn) p.classList.remove("active"); });
        allPill.classList.add("active");
        var f = findTextarea();
        if (f) loadButtons(f, colors, "");
      };
      toolbar.appendChild(allPill);

      for (var fi = 0; fi < folders.length; fi++) {
        (function(folderName) {
          var pill = doc.createElement("span");
          pill.className = "qa-pill" + (activeFolder === folderName ? " active" : "");
          pill.textContent = folderName;
          pill.onclick = function() {
            activeFolder = folderName;
            chrome.storage.local.set({ qaActiveFolder: folderName });
            toolbar.querySelectorAll(".qa-pill").forEach(function(p) { if (p !== appendBtn) p.classList.remove("active"); });
            pill.classList.add("active");
            var f = findTextarea();
            if (f) loadButtons(f, colors, folderName);
          };
          toolbar.appendChild(pill);
        })(folders[fi]);
      }
    }

    panel.appendChild(toolbar);

    for (var i = 0; i < CATEGORIES.length; i++) {
      var cat = CATEGORIES[i];
      var section = doc.createElement("div");
      section.className = "qa-section";

      var header = doc.createElement("div");
      header.className = "qa-header";
      var baseColor = colors[cat] || DEFAULT_COLORS[cat];
      header.style.color = baseColor;
      header.style.borderLeftColor = baseColor;
      header.textContent = cat;
      section.appendChild(header);

      var btnContainer = doc.createElement("div");
      btnContainer.className = "qa-buttons";
      btnContainer.dataset.category = cat;
      section.appendChild(btnContainer);

      panel.appendChild(section);
    }

    var annotationRow = textarea.closest(".a-row.a-spacing-small") || textarea.parentElement.parentElement.parentElement;
    if (annotationRow && annotationRow.parentElement) {
      annotationRow.parentElement.insertBefore(panel, annotationRow.nextSibling);
    }

    loadButtons(found, colors, activeFolder);
  });
}

function loadButtons(found, colors, activeFolder) {
  if (!found) return;
  var textarea = found.textarea;
  var doc = found.doc;

  chrome.storage.local.get(["qaButtons", "qaCatColors", "qaActiveFolder"], function(res) {
    var buttons = res.qaButtons || [];
    var catColors = colors || {};
    var stored = res.qaCatColors || {};
    if (!colors) {
      for (var k in DEFAULT_COLORS) catColors[k] = stored[k] || DEFAULT_COLORS[k];
    }
    // si no se paso activeFolder, leerlo de storage
    if (activeFolder === undefined) activeFolder = res.qaActiveFolder || "";

    for (var i = 0; i < CATEGORIES.length; i++) {
      var cat = CATEGORIES[i];
      var container = doc.querySelector('.qa-buttons[data-category="' + cat + '"]');
      if (!container) continue;
      container.innerHTML = "";

      var catButtons = [];
      for (var j = 0; j < buttons.length; j++) {
        if (buttons[j].category !== cat) continue;
        // filtro de folder: "All" muestra todo, folder especifico muestra ese + sin folder
        if (activeFolder) {
          var bf = buttons[j].folder || "";
          if (bf !== activeFolder && bf !== "") continue;
        }
        catButtons.push(buttons[j]);
      }

      for (var b = 0; b < catButtons.length; b++) {
        (function(btnData) {
          var btn = doc.createElement("button");
          btn.className = "qa-btn";
          btn.textContent = btnData.title;
          btn.style.background = btnData.color || "#e6e6e6";
          btn.style.color = textColorFor(btnData.color || "#e6e6e6");
          btn.title = btnData.content.substring(0, 100) + "...";
          btn.onclick = function() {
            if (appendMode && textarea.value.trim()) {
              textarea.value = textarea.value.trimEnd() + " | " + btnData.content;
            } else {
              textarea.value = btnData.content;
            }
            textarea.dispatchEvent(new Event("input", { bubbles: true }));
            textarea.dispatchEvent(new Event("change", { bubbles: true }));
          };
          container.appendChild(btn);
        })(catButtons[b]);
      }

      if (catButtons.length === 0) {
        var empty = doc.createElement("span");
        empty.className = "qa-empty";
        empty.textContent = "sin botones ~ agrega en el editor";
        container.appendChild(empty);
      }
    }
  });
}

var observer = new MutationObserver(function() {
  var found = findTextarea();
  if (found && !found.doc.getElementById("qa-panel")) {
    injectPanel();
  }
});

if (document.body) {
  observer.observe(document.body, { childList: true, subtree: true });
  setInterval(function() {
    var found = findTextarea();
    if (found && !found.doc.getElementById("qa-panel")) {
      injectPanel();
    }
  }, 2000);
}

// ⁘[ CALCULO DE RETURN WINDOW (NA) ]⁘
// reglas actualizadas 2026-04-28:
// 1. si hay delivery date, window empieza el dia despues de delivery
// 2. si no, dia despues de return request date
// 3. si no, dia despues de max edd
// 4. in window = shipped date - window start <= return window days
function calcReturnWindow(rd) {
  if (!rd.shippedDate) {
    rd.daysToReturn = "Missing shipped date";
    rd.inReturnWindow = "Missing shipped date";
    rd.windowSource = rd.deliveredDate ? "delivery" : rd.returnRequestDate ? "request" : rd.maxEdd ? "maxEdd" : "Missing all dates";
    return;
  }
  var shipClean = rd.shippedDate.replace(/\s+\d{2}:\d{2}\s+\w+$/, "");
  var shipDate = new Date(shipClean);
  if (isNaN(shipDate.getTime())) {
    rd.daysToReturn = "Invalid shipped date";
    rd.inReturnWindow = "Invalid shipped date";
    return;
  }

  // determinar fecha de inicio del window (prioridad: delivered > request > max edd)
  var windowStartStr = null;
  var windowSource = null;
  if (rd.deliveredDate) {
    windowStartStr = rd.deliveredDate;
    windowSource = "delivery";
  } else if (rd.returnRequestDate) {
    windowStartStr = rd.returnRequestDate;
    windowSource = "request";
  } else if (rd.maxEdd) {
    windowStartStr = rd.maxEdd;
    windowSource = "maxEdd";
  }
  if (!windowStartStr) {
    rd.daysToReturn = "Missing delivery/request/EDD";
    rd.inReturnWindow = "Missing delivery/request/EDD";
    rd.windowSource = "Missing all dates";
    return;
  }

  var startClean = windowStartStr.replace(/\s+\d{2}:\d{2}\s+\w+$/, "").replace(/\s+(PST|PDT|GMT|UTC|EST|EDT|CST|CDT|MST|MDT)$/i, "");
  var startDate = new Date(startClean);
  if (isNaN(startDate.getTime())) {
    rd.daysToReturn = "Invalid " + windowSource + " date";
    rd.inReturnWindow = "Invalid " + windowSource + " date";
    rd.windowSource = windowSource;
    return;
  }

  // window empieza el dia DESPUES de la fecha base
  startDate.setDate(startDate.getDate() + 1);

  var diffDays = Math.floor((shipDate - startDate) / (1000 * 60 * 60 * 24));
  var windowDays = parseInt(rd.returnWindow || "30");

  rd.daysToReturn = String(diffDays);
  rd.windowSource = windowSource;
  rd.inReturnWindow = diffDays <= windowDays ? "Yes" : "No";
}

chrome.storage.onChanged.addListener(function(changes) {
  if (changes.qaButtons || changes.qaCatColors) {
    var found = findTextarea();
    if (!found) return;
    var doc = found.doc;
    if (changes.qaButtons) {
      var panel = doc.getElementById("qa-panel");
      if (panel) { panel.remove(); found.textarea.dataset.qaOwned = ""; injectPanel(); }
    } else {
      loadButtons(found);
    }
  }
  // recalcular days to return cuando llegan nuevos datos
  if (changes.returnData) {
    var rd = (changes.returnData.newValue) || {};
    var oldDtr = rd.daysToReturn;
    var oldIrw = rd.inReturnWindow;
    calcReturnWindow(rd);
    // solo escribir si el calculo cambio algo ~ si no, se arma un loop infinito
    // porque set() dispara onChanged en todos los frames y cada uno recalcula
    if (rd.daysToReturn !== oldDtr || rd.inReturnWindow !== oldIrw) {
      chrome.storage.local.set({ returnData: rd });
    }
  }
});

// ⁘[ BOTON AUTO EMAIL (en el panel de QA) ]⁘
// mapea las lineas $ARGS{USE IF...} del template del blurb a los componentes de reembolso
// lee los montos del formulario de paragon, reemplaza $ARGS{AMOUNT} con valores reales,
// y borra bloques enteros de $ARGS cuando el componente tiene $0 o no existe

var ARGS_TO_COMPONENT = {
  "USE IF REFUNDING ITEM COSTS": "PRINCIPAL",
  "USE IF REFUNDING RESTOCKING FEE": "PRINCIPAL_PARTIAL",
  "USE IF REFUNDING PARTIAL ORDER AMOUNT": "PRINCIPAL_PARTIAL",
  "USE IF REFUNDING ORIGINAL SHIPPING COSTS": "SHIPPING",
  "USE IF REFUNDING RETURN LABEL COSTS": "RETURN_SHIPPING"
};

function getEnteredAmount(doc, componentType) {
  var spans = doc.querySelectorAll("[id$='-" + componentType + "-percentageValPlaceholder']");
  for (var i = 0; i < spans.length; i++) {
    var txt = spans[i].textContent.trim();
    if (txt && !/^$/.test(txt)) {
      var numMatch = txt.match(/([\d,.]+)/);
      if (numMatch && parseFloat(numMatch[1].replace(/,/g, "")) > 0) return txt;
    }
  }
  return null;
}

function getPrincipalPercent(doc) {
  var input = doc.querySelector("[id$='_PRINCIPAL_amnt']");
  return input ? parseFloat(input.value) || 0 : 0;
}

function addEmailButton() {
  var found = findTextarea();
  if (!found) return;
  var doc = found.doc;
  if (doc.getElementById("qa-auto-email")) return;

  var panel = doc.getElementById("qa-panel");
  if (!panel) return;

  var target = doc.getElementById("gr_entry_buttons");
  if (!target) return;

  var btn = doc.createElement("button");
  btn.id = "qa-auto-email";
  btn.type = "button";
  btn.style.cssText = "background:#e8f5e9;color:#2e7d32;padding:4px 12px;margin-top:12px;font-size:11px;border:1px solid #c8e6c9;border-radius:3px;cursor:pointer;font-weight:600;box-shadow:0 1px 2px rgba(0,0,0,0.06);transition:transform 150ms cubic-bezier(0.4,0,0.2,1),box-shadow 150ms cubic-bezier(0.4,0,0.2,1),background 150ms ease;";
  btn.textContent = "Fill Amounts";
  btn.onclick = function() {
    var emailBody = doc.getElementById("email-body-id");
    if (!emailBody) { alert("Email body not found"); return; }

    var body = emailBody.value || "";
    if (!body.trim()) { alert("Select a blurb first (e.g. grant_en)"); return; }

    var principalAmt = getEnteredAmount(doc, "PRINCIPAL");
    var shippingAmt = getEnteredAmount(doc, "SHIPPING");
    var returnShipAmt = getEnteredAmount(doc, "RETURN_SHIPPING");
    var goodwillAmt = getEnteredAmount(doc, "GOODWILL");
    var principalPct = getPrincipalPercent(doc);

    if (!principalAmt && !shippingAmt && !returnShipAmt && !goodwillAmt) {
      alert("No amounts entered yet");
      return;
    }

    // procesar cada $ARGS{USE IF...} + su linea $ARGS{AMOUNT} siguiente
    // matchea tanto $ARGS{...} como $ARGS {...} (con o sin espacio)
    var lines = body.split("\n");
    var result = [];
    var i = 0;

    while (i < lines.length) {
      var line = lines[i];
      var argsMatch = line.match(/\$ARGS\s*\{([^}]+)\}/);

      if (argsMatch) {
        var argsKey = argsMatch[1].trim();

        if (ARGS_TO_COMPONENT[argsKey]) {
          var comp = ARGS_TO_COMPONENT[argsKey];
          var amt = null;

          if (comp === "PRINCIPAL") {
            amt = (principalPct >= 100) ? principalAmt : null;
          } else if (comp === "PRINCIPAL_PARTIAL") {
            amt = (principalPct > 0 && principalPct < 100) ? principalAmt : null;
            if (!amt) amt = goodwillAmt;
          } else if (comp === "SHIPPING") {
            amt = shippingAmt;
          } else if (comp === "RETURN_SHIPPING") {
            amt = returnShipAmt;
          }

          if (amt) {
            i++;
            if (i < lines.length) {
              result.push(lines[i].replace(/\$ARGS\s*\{AMOUNT\}/g, amt));
            }
          } else {
            i++;
          }
        } else if (argsKey === "AMOUNT") {
          result.push(line);
        } else if (argsKey === "REFUND AMOUNT") {
          // template BR: un solo $ARGS{REFUND AMOUNT} inline = total de todos los montos
          var allAmounts = [principalAmt, shippingAmt, returnShipAmt, goodwillAmt].filter(Boolean);
          var totalAmt = allAmounts.length > 0 ? allAmounts[0] : "$0.00";
          // si hay varios montos, sumarlos ~ pero son strings tipo "BRL 429,90"
          // Just use the first non-null as the total (Paragon shows total elsewhere)
          // o intentar leer el monto total reembolsado del DOM
          var totalEl = doc.getElementById("txt_total_reimbursed_amount") || doc.querySelector("[id$='_reimbursed_amount']");
          if (totalEl && totalEl.textContent.trim()) totalAmt = totalEl.textContent.trim();
          result.push(line.replace(/\$ARGS\s*\{REFUND AMOUNT\}/g, totalAmt));
        } else {
          result.push(line);
        }
      } else {
        result.push(line);
      }
      i++;
    }

    var cleaned = result.join("\n").replace(/\n{3,}/g, "\n\n");

    emailBody.value = cleaned;
    emailBody.dispatchEvent(new Event("input", { bubbles: true }));
    emailBody.dispatchEvent(new Event("change", { bubbles: true }));
    btn.textContent = "Done";
    setTimeout(function() {
      btn.textContent = "Fill Amounts";
    }, 2000);
  };
  // ponerlo debajo del area de submit ~ no adentro pa no romper el layout
  var previewBtn = doc.getElementById("btn_claimActionPreviewNative");
  if (previewBtn) {
    var submitArea = previewBtn.closest(".a-row, .a-section, div") || previewBtn.parentNode;
    submitArea.parentNode.insertBefore(btn, submitArea.nextSibling);
    return;
  }
  var blurbArea = doc.getElementById("blurb-list-id") || doc.getElementById("blurb-list-native-id");
  if (blurbArea) {
    var blurbCol = blurbArea.closest(".a-column") || blurbArea.parentElement;
    if (blurbCol) { blurbCol.appendChild(btn); return; }
  }
  target.parentNode.insertBefore(btn, target.nextSibling);
}

setInterval(addEmailButton, 2000);

// ⁘[ CAPTURA DE DATOS DE RETORNO ]⁘
// lee tracking/carrier/status del DOM del widget returnDetails
// lo guarda en chrome.storage.local pa que Fill Tracking lo lea desde cualquier frame

var returnDataCaptured = false;
var eventsClicked = false;

// click seguro ~ quita href antes de clickear pa que el browser no navegue si paragon no cargo sus handlers
function safeClick(el) {
  var href = el.getAttribute("href");
  if (href) el.removeAttribute("href");
  el.addEventListener("click", function(e) { e.preventDefault(); }, { once: true, capture: true });
  el.dispatchEvent(new MouseEvent("click", { bubbles: false }));
  if (href) el.setAttribute("href", href);
}

function captureReturnData() {
  if (returnDataCaptured) return;

  // paso 1: auto-click en "Events" pa que se despliegue el tracking history
  // sin esto el shipped date no aparece, paragon siendo paragon
  if (!eventsClicked) {
    function clickEvents(doc) {
      doc.querySelectorAll('[data-action="show-events-info"] a').forEach(function(a) {
        if (/events/i.test(a.textContent)) { safeClick(a); eventsClicked = true; }
      });
    }
    // solo buscar en este frame ~ no en hermanos, pa no clickear cosas en otros widgets
    clickEvents(document);
    if (eventsClicked) return;
  }

  // buscar return data ~ usar top frame pa acceder a todos los iframes hermanos
  var text = "";
  // si estamos dentro del iframe de return details, document ya tiene la data
  var rdRoot = document.getElementById("returns_widget_root_section");
  if (rdRoot) {
    var spinner = document.getElementById("return-details-spinner");
    if (spinner && !spinner.classList.contains("aok-hidden")) return;
    text = rdRoot.innerText || "";
  }
  // si no, buscar en iframes desde el top frame
  if (!text || !/Tracking/i.test(text)) {
    getSiblingDocs().forEach(function(idoc) {
      if (text) return;
      try {
        var rd = idoc.getElementById("returns_widget_root_section");
        if (!rd) return;
        var sp = idoc.getElementById("return-details-spinner");
        if (sp && !sp.classList.contains("aok-hidden")) return;
        var it = rd.innerText || "";
        if (it.length > 100 && /Tracking/i.test(it)) text = it;
      } catch(e) {}
    });
  }

  if (!text || text.length < 50) return;
  if (!/\b(Tracking|Carrier)\b/i.test(text)) return;

  var data = {};

  // tracking ~ "Tracking Number\t1ZR096K99021644232" o similar
  var tn = text.match(/Tracking\s*(?:Number|#)[\s\t:]*([A-Z0-9]{10,30})/i);
  if (!tn) tn = text.match(/\b(1Z[A-Z0-9]{6,20})\b/i);
  if (!tn) tn = text.match(/\b(\d{15,22})\b/);
  if (tn) data.trackingNumber = tn[1];

  // carrier ~ "Carrier\tUPS" ~ tab-separated, parar en newline
  var cr = text.match(/Carrier\t([^\n]+)/i);
  if (!cr) cr = text.match(/Carrier[\s:]+([A-Za-z]+)/i);
  if (cr) data.carrier = cr[1].trim();

  // status ~ buscar especificamente en la seccion de tracking, no el status del return request
  var st = text.match(/Status\t(DELIVERED|IN[_\s-]?TRANSIT|LOST|UNDELIVERABLE)/i);
  if (st) data.status = st[1].toUpperCase().replace(/[\s-]+/g, "_");

  // fechas ~ "Delivered Date\n01 Apr 2026 08:51 PDT" (newline entre label y valor)
  var dd = text.match(/Delivered\s+Date\s*\n\s*(\d{1,2}\s+\w{3}\s+\d{4}[^\n]*)/i);
  if (dd) data.deliveredDate = dd[1].trim();
  // shipped ~ buscar "picked up" en events primero, luego "Shipped Date"
  var sd = text.match(/picked up[^\d]*(\d{1,2}\s+\w{3}\s+\d{4}[^\n]*)/i);
  if (!sd) sd = text.match(/Shipped\s+Date\s*\n\s*(\d{1,2}\s+\w{3}\s+\d{4}[^\n]*)/i);
  if (sd) data.shippedDate = sd[1].trim();
  var ea = text.match(/Estimated\s+Arrival\s+Date\s*[\t\n]\s*(\d{1,2}\s+\w{3}\s+\d{4}[^\n]*)/i);
  if (ea) data.estimatedArrival = ea[1].trim();

  // request date ~ "Request Date\n15 Mar 2026" o "Requested Date"
  var rqd = text.match(/Request(?:ed)?\s+Date\s*[\t\n]\s*(\d{1,2}\s+\w{3}\s+\d{4}[^\n]*)/i);
  if (rqd) data.returnRequestDate = rqd[1].trim();

  if (data.trackingNumber || data.carrier) {
    // no marcar como captured hasta que tengamos carrier o status (indica que Events cargo)
    // si solo tenemos tracking number, seguir reintentando
    var hasDetail = data.carrier || data.status || data.deliveredDate;
    if (hasDetail) returnDataCaptured = true;
    chrome.storage.local.get(["returnData"], function(res) {
      var rd = res.returnData || {};
      for (var k in data) rd[k] = data[k];
      chrome.storage.local.set({ returnData: rd });
    });
  }
}

setInterval(captureReturnData, 2000);
setInterval(injectReturnPanel, 2000);

// auto-refresh: despues de clickear events, reintentar cada 3s hasta que agarre los datos
// si no los encuentra en 30s ya fue, que le de retry manual
var retryCount = 0;
setInterval(function() {
  if (!returnDataCaptured && eventsClicked && retryCount < 10) {
    retryCount++;
    captureReturnData();
  }
}, 3000);

// ⁘[ CAPTURA DE FORWARD TRACKING ]⁘
// auto-click en el link del tracking number pa expandir eventos
// lee shipped/delivered/status del DOM de forward tracking

var fwdCaptured = false;
var fwdClicked = false;

function captureForwardTracking() {
  if (fwdCaptured) return;

  // buscar en todos los docs del mismo caso
  var docs = [document].concat(getSiblingDocs());

  var data = {};

  // paso 1: leer tracking number y carrier de la tabla (no necesita click)
  for (var di = 0; di < docs.length; di++) {
    var spans = docs[di].querySelectorAll('[data-action="show-tracking-events"]');
    for (var si = 0; si < spans.length; si++) {
      try {
        var json = JSON.parse(spans[si].dataset.showTrackingEvents || "{}");
        if (json.trackingId) {
          data.fwdTrackingNumber = json.trackingId;
          // shipMethod es el carrier ~ OnTrac, Ground, etc
          if (json.shipMethod) data.fwdCarrier = json.shipMethod;
          break;
        }
      } catch(e) {}
    }
    if (data.fwdTrackingNumber) break;
  }

  if (!data.fwdTrackingNumber) return;

  // shipped date ~ de la primera columna de la tabla de forward tracking
  for (var di2 = 0; di2 < docs.length; di2++) {
    var ths = docs[di2].querySelectorAll("th");
    for (var ti = 0; ti < ths.length; ti++) {
      if (/forward\s*tracking/i.test(ths[ti].textContent)) {
        // la fila de headers, la siguiente fila tiene los datos
        var headerRow = ths[ti].closest("tr");
        if (headerRow && headerRow.nextElementSibling) {
          var firstTd = headerRow.nextElementSibling.querySelector("td");
          if (firstTd) {
            var dm = firstTd.textContent.trim().match(/(\d{1,2}\s+\w{3}\s+\d{4})/);
            if (dm) data.fwdShippedDate = dm[1];
          }
        }
        break;
      }
    }
    if (data.fwdShippedDate) break;
  }

  // paso 2: auto-click pa expandir tracking events (status + delivered date)
  if (!fwdClicked) {
    for (var di3 = 0; di3 < docs.length; di3++) {
      var links = docs[di3].querySelectorAll('[data-action="show-tracking-events"] a');
      for (var li = 0; li < links.length; li++) {
        if (links[li].textContent.trim() === data.fwdTrackingNumber) {
          safeClick(links[li]);
          fwdClicked = true;
          break;
        }
      }
      if (fwdClicked) break;
    }
  }

  // paso 3: leer status y fechas del div de tracking events expandido
  if (fwdClicked) {
    for (var di4 = 0; di4 < docs.length; di4++) {
      var detailDiv = docs[di4].querySelector("[id^='div_tracking_details_']");
      if (!detailDiv || detailDiv.textContent.trim().length < 10) continue;

      // status ~ "Status : DELIVERED"
      var stm = detailDiv.textContent.match(/Status\s*:\s*(\w+)/i);
      if (stm) data.fwdStatus = stm[1].toUpperCase();

      // parsear filas de la tabla de eventos pa sacar delivered date
      var rows = detailDiv.querySelectorAll("tr");
      for (var ri = 0; ri < rows.length; ri++) {
        var tds = rows[ri].querySelectorAll("td");
        if (tds.length < 3) continue;
        var evt = tds[0].textContent.trim().toLowerCase();
        var dateStr = tds[2].textContent.trim().match(/(\d{1,2}\s+\w{3}\s+\d{4})/);
        if (!dateStr) continue;
        if (/^delivered$/i.test(evt)) data.fwdDeliveredDate = dateStr[1];
        if (/picked up/i.test(evt) && !data.fwdShippedDate) data.fwdShippedDate = dateStr[1];
      }
      break;
    }
  }

  // guardar lo que tengamos ~ tracking number ya es suficiente
  if (data.fwdTrackingNumber) {
    // si ya clickeamos pero no hay status, esperar un poco ~ pero no forever
    var hasExtra = data.fwdStatus || data.fwdDeliveredDate;
    if (fwdClicked && !hasExtra && fwdRetryCount < 5) return;
    fwdCaptured = true;
    chrome.storage.local.get(["returnData"], function(res) {
      var rd = res.returnData || {};
      for (var k in data) rd[k] = data[k];
      chrome.storage.local.set({ returnData: rd });
    });
  }
}

setInterval(captureForwardTracking, 2000);
var fwdRetryCount = 0;
setInterval(function() {
  if (!fwdCaptured && fwdRetryCount < 15) {
    fwdRetryCount++;
    captureForwardTracking();
  }
}, 3000);

// ⁘[ CAPTURA DE CLAIM ACTION HISTORY ]⁘
// parsea la tabla del iframe safetClaimActionHistory pa sacar fechas de reembolso, RASI, etc

var claimHistoryCaptured = false;

function captureClaimHistory() {
  if (claimHistoryCaptured) return;

  var docs = [document].concat(getSiblingDocs());

  for (var di = 0; di < docs.length; di++) {
    var widget = docs[di].querySelector('[data-widget-id="safetClaimActionHistory"]');
    if (!widget) continue;
    var rows = widget.querySelectorAll("tr");
    if (rows.length < 2) continue;

    var data = {};
    for (var ri = 1; ri < rows.length; ri++) {
      var tds = rows[ri].querySelectorAll("td");
      if (tds.length < 5) continue;
      var reason = (tds[4].textContent || "").trim();
      var date = (tds[5].textContent || "").trim();
      var amount = (tds[3].textContent || "").trim();

      if (reason === "REIMBURSE" && date) {
        data.reimbursementDate = date;
        if (amount) data.reimbursedAmount = amount;
      }
      if (reason === "SELLER_MORE_INFO_REQUIRED" && date) {
        data.rasiDate = date;
      }
    }

    if (data.reimbursementDate || data.rasiDate) {
      claimHistoryCaptured = true;
      chrome.storage.local.get(["returnData"], function(res) {
        var rd = res.returnData || {};
        for (var k in data) rd[k] = data[k];
        chrome.storage.local.set({ returnData: rd });
      });
    }
    break;
  }
}

setInterval(captureClaimHistory, 3000);

// ⁘[ CAPTURA DE REVERSAL TRANSACTIONS ]⁘
// parsea la tabla "Reversal Transactions" en claim items pa sacar la fecha del refund al buyer

var reversalCaptured = false;

function captureReversalTransaction() {
  if (reversalCaptured) return;

  var docs = [document].concat(getSiblingDocs());
  var latestDate = null;
  var latestDateStr = "";

  for (var di = 0; di < docs.length; di++) {
    var tables = docs[di].querySelectorAll("table.a-keyvalue");
    for (var ti = 0; ti < tables.length; ti++) {
      var ths = tables[ti].querySelectorAll("th");
      var hasType = false, hasDate = false;
      for (var hi = 0; hi < ths.length; hi++) {
        var htxt = ths[hi].textContent.trim();
        if (htxt === "Type") hasType = true;
        if (htxt === "Date") hasDate = true;
      }
      if (!hasType || !hasDate) continue;

      var rows = tables[ti].querySelectorAll("tr");
      for (var ri = 1; ri < rows.length; ri++) {
        var tds = rows[ri].querySelectorAll("td");
        if (tds.length < 9) continue;
        var type = tds[0].textContent.replace(/\s+/g, " ").trim();
        if (type !== "Refund") continue;
        // normalizar whitespace ~ los spans de paragon meten newlines y tabs
        var rawDate = tds[8].textContent.replace(/\s+/g, " ").trim();
        if (!rawDate) continue;

        // extraer fecha con regex flexible ~ "16 Mar 2026 08:35 GMT" o "11 Mar 2026 12:30 PDT"
        var dateMatch = rawDate.match(/(\d{1,2}\s+\w{3}\s+\d{4}\s+\d{2}:\d{2})\s*\w*/);
        if (!dateMatch) continue;
        var cleanDate = dateMatch[1];
        var txDate = new Date(cleanDate);
        if (isNaN(txDate.getTime())) continue;

        if (!latestDate || txDate > latestDate) {
          latestDate = txDate;
          latestDateStr = rawDate;
        }
      }
    }
  }

  if (latestDate) {
    var diffDays = Math.floor((new Date() - latestDate) / (1000 * 60 * 60 * 24));
    reversalCaptured = true;
    chrome.storage.local.get(["returnData"], function(res) {
      var rd = res.returnData || {};
      rd.reversalDate = latestDateStr;
      rd.daysSinceTransaction = String(diffDays);
      chrome.storage.local.set({ returnData: rd });
    });
  }
}

setInterval(captureReversalTransaction, 3000);

// ⁘[ CAPTURA DE ORDER SUMMARY ]⁘
// parsea el iframe de safetOrderSummary pa sacar Max EDD y calcular return window
// holiday window: si max edd cae entre nov 1 y dic 31, el buyer tiene 90 dias pa devolver

var orderSummaryCaptured = false;

function captureOrderSummary() {
  if (orderSummaryCaptured) return;

  var docs = [document].concat(getSiblingDocs());

  for (var di = 0; di < docs.length; di++) {
    var rows = docs[di].querySelectorAll(".a-row");
    for (var ri = 0; ri < rows.length; ri++) {
      var bold = rows[ri].querySelector(".a-text-bold");
      if (!bold || !/Max EDD/i.test(bold.textContent.trim())) continue;
      var valCol = rows[ri].querySelector(".a-span10, .a-span-last");
      if (!valCol) continue;
      var dateStr = valCol.textContent.trim();
      if (!dateStr || dateStr.length < 10) continue;

      var cleanDate = dateStr.replace(/\s+(PST|PDT|GMT|UTC|EST|EDT|CST|CDT|MST|MDT)$/i, "");
      var eddDate = new Date(cleanDate);
      if (isNaN(eddDate.getTime())) continue;

      // holiday window: nov 1 - dec 31 = 90 dias, sino 30
      var month = eddDate.getMonth(); // 0-indexed: 10=nov, 11=dec
      var isHoliday = (month === 10 || month === 11);
      var returnWindow = isHoliday ? 90 : 30;

      var data = { maxEdd: dateStr, returnWindow: String(returnWindow), isHoliday: isHoliday ? "Yes" : "No" };

      orderSummaryCaptured = true;
      chrome.storage.local.get(["returnData"], function(res) {
        var rd = res.returnData || {};
        rd.maxEdd = data.maxEdd;
        rd.returnWindow = data.returnWindow;
        rd.isHoliday = data.isHoliday;

        calcReturnWindow(rd);

        chrome.storage.local.set({ returnData: rd });
      });
      return;
    }
  }
}

setInterval(captureOrderSummary, 3000);

// ⁘[ PANEL EDITABLE DE DATOS DE RETORNO ]⁘
// muestra los datos capturados al lado del header de Return Details pa corregir a mano

function injectReturnPanel() {
  if (window !== window.top) return;
  var sidebar = document.getElementById("page-left-sidebar");
  if (!sidebar) return;

  // si el widget ya existe en el DOM, no hacer nada
  // pero si paragon reconstruyo el sidebar y lo borro, re-inyectar
  if (document.getElementById("qa-tracking-widget")) return;

  // css en el documento principal
  if (!document.getElementById("qa-sidebar-style")) {
    var sStyle = document.createElement("style");
    sStyle.id = "qa-sidebar-style";
    sStyle.textContent =
      "#qa-tracking-widget { margin:12px 8px !important; padding:12px !important; background:#fff !important; border:1px solid #ddd !important; border-radius:3px !important; font-family:'Amazon Ember','Segoe UI',Arial,sans-serif !important; font-size:11px !important; line-height:1.4 !important; box-shadow:0 1px 2px rgba(0,0,0,0.06) !important; }" +
      "#qa-tracking-widget .qa-tw-header { display:flex !important; align-items:center !important; justify-content:space-between !important; margin-bottom:10px !important; padding-bottom:8px !important; border-bottom:1px solid #eee !important; }" +
      "#qa-tracking-widget .qa-tw-title { font-weight:700 !important; font-size:15px !important; color:#232f3e !important; text-transform:none !important; letter-spacing:normal !important; line-height:1.3 !important; }" +
      "#qa-tracking-widget .qa-tw-retry { background:#f5f5f5 !important; color:#333 !important; border:1px solid #ddd !important; border-radius:3px !important; padding:3px 10px !important; font-size:10px !important; cursor:pointer !important; font-weight:600 !important; transition:all 150ms cubic-bezier(0.4,0,0.2,1) !important; }" +
      "#qa-tracking-widget .qa-tw-retry:hover { background:#eaeaea !important; }" +
      "#qa-tracking-widget .qa-tw-retry:active { transform:scale(0.97) !important; }" +
      "#qa-tracking-widget .qa-tw-section { margin-bottom:10px !important; }" +
      "#qa-tracking-widget .qa-tw-section:last-child { margin-bottom:0 !important; }" +
      "#qa-tracking-widget .qa-tw-sec-title { font-weight:700 !important; font-size:13px !important; color:#666 !important; text-transform:uppercase !important; letter-spacing:0.8px !important; margin-bottom:6px !important; padding-bottom:4px !important; border-bottom:1px solid #f0f0f0 !important; }" +
      "#qa-tracking-widget .qa-tw-grid { display:flex !important; flex-direction:column !important; gap:6px !important; }" +
      "#qa-tracking-widget .qa-tw-row { display:flex !important; align-items:center !important; gap:6px !important; }" +
      "#qa-tracking-widget .qa-tw-label { font-weight:600 !important; color:#666 !important; font-size:10px !important; min-width:64px !important; white-space:nowrap !important; }" +
      "#qa-tracking-widget input[type='text'] { flex:1 !important; padding:4px 8px !important; border:1px solid #ddd !important; border-radius:3px !important; font-size:11px !important; background:#fafafa !important; color:#333 !important; font-family:'Amazon Ember',Arial,sans-serif !important; box-sizing:border-box !important; transition:border-color 150ms,box-shadow 150ms,background 150ms !important; width:auto !important; height:auto !important; margin:0 !important; }" +
      "#qa-tracking-widget input[type='text']:focus { outline:none !important; border-color:#232f3e !important; background:#fff !important; box-shadow:0 0 0 2px rgba(35,47,62,0.1) !important; }" +
      "#qa-tracking-widget input[type='text']::placeholder { color:#ccc !important; }" +
      "[data-paragon-widget-id='related-items'] { display:none !important; }";
    document.head.appendChild(sStyle);
  }

  var widget = document.createElement("div");
  widget.id = "qa-tracking-widget";

  // header
  var hdr = document.createElement("div");
  hdr.className = "qa-tw-header";
  var title = document.createElement("span");
  title.className = "qa-tw-title";
  title.textContent = "STAR Information";
  var retryBtn = document.createElement("button");
  retryBtn.textContent = "Retry";
  retryBtn.className = "qa-tw-retry";
  retryBtn.onclick = function() {
    // solo re-parsear lo que ya esta en el DOM ~ no re-clickear events ni forward
    returnDataCaptured = false;
    retryCount = 0;
    fwdCaptured = false;
    fwdRetryCount = 0;
    claimHistoryCaptured = false;
    reversalCaptured = false;
    orderSummaryCaptured = false;
    captureReturnData();
    captureForwardTracking();
    captureClaimHistory();
    captureReversalTransaction();
    captureOrderSummary();
    retryBtn.textContent = "...";
    setTimeout(function() { retryBtn.textContent = "Retry"; }, 2000);
  };
  hdr.append(title, retryBtn);
  widget.appendChild(hdr);

  // helper pa crear seccion
  function buildSection(label, fields) {
    var sec = document.createElement("div");
    sec.className = "qa-tw-section";
    var secTitle = document.createElement("div");
    secTitle.className = "qa-tw-sec-title";
    secTitle.textContent = label;
    sec.appendChild(secTitle);
    var grid = document.createElement("div");
    grid.className = "qa-tw-grid";
    fields.forEach(function(f) {
      var row = document.createElement("div");
      row.className = "qa-tw-row";
      var lbl = document.createElement("span");
      lbl.className = "qa-tw-label";
      lbl.textContent = f.label + ":";
      var input = document.createElement("input");
      input.type = "text";
      input.dataset.rdKey = f.key;
      input.placeholder = "—";
      input.onchange = function() {
        chrome.storage.local.get(["returnData"], function(res) {
          var rd = res.returnData || {};
          rd[f.key] = input.value;
          chrome.storage.local.set({ returnData: rd });
        });
      };
      row.append(lbl, input);
      grid.appendChild(row);
    });
    sec.appendChild(grid);
    return sec;
  }

  widget.appendChild(buildSection("Return Tracking", [
    { key: "carrier", label: "Carrier" },
    { key: "trackingNumber", label: "Tracking #" },
    { key: "status", label: "Status" },
    { key: "deliveredDate", label: "Delivered" },
    { key: "shippedDate", label: "Shipped" }
  ]));
  widget.appendChild(buildSection("Forward Tracking", [
    { key: "fwdCarrier", label: "Carrier" },
    { key: "fwdTrackingNumber", label: "Tracking #" },
    { key: "fwdStatus", label: "Status" },
    { key: "fwdShippedDate", label: "Shipped" },
    { key: "fwdDeliveredDate", label: "Delivered" }
  ]));
  widget.appendChild(buildSection("Auto-Fill", [
    { key: "reimbursementDate", label: "Reimb. Date" },
    { key: "reimbursedAmount", label: "Reimb. Amt" },
    { key: "rasiDate", label: "RASI Date" },
    { key: "daysSinceTransaction", label: "Days Since Tx" }
  ]));
  widget.appendChild(buildSection("Return Window", [
    { key: "maxEdd", label: "Max EDD" },
    { key: "returnRequestDate", label: "Request Date" },
    { key: "returnWindow", label: "Window (days)" },
    { key: "isHoliday", label: "Holiday" },
    { key: "windowSource", label: "Window From" },
    { key: "daysToReturn", label: "Days to Return" },
    { key: "inReturnWindow", label: "In Window" }
  ]));

  sidebar.appendChild(widget);

  function fillPanel() {
    chrome.storage.local.get(["returnData"], function(res) {
      var rd = res.returnData || {};
      widget.querySelectorAll("input[data-rd-key]").forEach(function(inp) {
        inp.value = rd[inp.dataset.rdKey] || "";
      });
    });
  }
  fillPanel();
  chrome.storage.onChanged.addListener(function(changes) {
    if (changes.returnData) fillPanel();
  });
}

// ⁘[ BOTON FILL TRACKING ]⁘

function addDaysToDate(dateStr, days) {
  try {
    var d = new Date(dateStr);
    if (isNaN(d.getTime())) return null;
    d.setDate(d.getDate() + days);
    var months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    return ("0" + d.getDate()).slice(-2) + " " + months[d.getMonth()] + " " + d.getFullYear();
  } catch(e) { return null; }
}

function addTrackingButton() {
  var found = findTextarea();
  if (!found) return;
  var doc = found.doc;
  if (doc.getElementById("qa-fill-tracking")) return;

  // ponerlo debajo del area de submit
  var previewBtn = doc.getElementById("btn_claimActionPreviewNative");
  if (!previewBtn) return;
  var submitArea = previewBtn.closest(".a-row, .a-section, div") || previewBtn.parentNode;

  var btn = doc.createElement("button");
  btn.id = "qa-fill-tracking";
  btn.type = "button";
  btn.style.cssText = "background:#ede7f6;color:#5b21b6;padding:4px 12px;margin-top:12px;font-size:11px;border:1px solid #d1c4e9;border-radius:3px;cursor:pointer;font-weight:600;box-shadow:0 1px 2px rgba(0,0,0,0.06);transition:transform 150ms cubic-bezier(0.4,0,0.2,1),box-shadow 150ms cubic-bezier(0.4,0,0.2,1),background 150ms ease;";
  btn.textContent = "Fill Tracking";
  btn.onclick = function() {
    var emailBody = doc.getElementById("email-body-id");
    if (!emailBody) { alert("Email body not found"); return; }
    var body = emailBody.value || "";
    if (!body.trim()) { alert("Select a blurb first"); return; }

    chrome.storage.local.get(["returnData"], function(res) {
      var rd = res.returnData;
      if (!rd || (!rd.trackingNumber && !rd.carrier && !rd.fwdTrackingNumber && !rd.fwdCarrier)) {
        alert("No tracking data captured yet. Open the SAFE-T profile tab first to load Return Details.");
        return;
      }

      // heuristica ~ si el blurb habla del envio al buyer, usar forward tracking
      // si habla de devolucion, usar return tracking
      var useFwd = /shipped to the buyer|delivery at the buyer|outbound shipment|does not confirm delivery/i.test(body);
      var useRtn = /returned the item|received the return|received the item|devolu/i.test(body);
      // si ambos matchean o ninguno, default a return (caso mas comun)
      var carrier, tracking, status;
      if (useFwd && !useRtn && rd.fwdCarrier) {
        carrier = rd.fwdCarrier || "N/A";
        tracking = rd.fwdTrackingNumber || "N/A";
        status = (rd.fwdStatus || "").toUpperCase();
      } else {
        carrier = rd.carrier || "N/A";
        tracking = rd.trackingNumber || "N/A";
        status = (rd.status || "").toUpperCase();
      }

      // reemplazar placeholders simples
      body = body.replace(/\$ARGS\s*\{CARRIER\}/g, carrier);
      body = body.replace(/\$ARGS\s*\{Name of the carrier\}/g, carrier);
      body = body.replace(/\$ARGS\s*\{TRACKING NUMBER\}/g, tracking);
      body = body.replace(/\$ARGS\s*\{TRACKING-ID\}/g, tracking);

      // monto reembolsado ~ DOM primero, fallback a claim history
      var reimbAmt = ((doc.getElementById("txt_total_reimbursed_amount") || {}).textContent || "").trim() || rd.reimbursedAmount || "";
      if (reimbAmt) {
        body = body.replace(/\$ARGS\s*\{REIMBURSED AMOUNT\}/g, reimbAmt);
      }

      // fecha de reembolso ~ auto-capturada del claim action history
      if (rd.reimbursementDate) {
        body = body.replace(/\$ARGS\s*\{REIMBURSEMENT DATE\}/g, rd.reimbursementDate);
      }

      // reemplazar placeholders de fecha
      if (rd.deliveredDate) {
        body = body.replace(/\$ARGS\s*\{DELIVERY DATE\}/g, rd.deliveredDate);
        body = body.replace(/\$ARGS\s*\{DATE OF DELIVERY\}/g, rd.deliveredDate);
        body = body.replace(/\$ARGS\s*\{ENTER RETURN DATE\}/g, rd.deliveredDate);
      }

      // ship date ~ del forward tracking (fecha de envio del reemplazo)
      if (rd.fwdShippedDate) {
        body = body.replace(/\$ARGS\s*\{SHIP DATE\}/g, rd.fwdShippedDate);
      }

      // mm-dd-yyyy ~ fecha de hoy, el dia que mandas el correo
      // INITIAL EVIDENCE REQUESTED DATE ~ usa rasiDate del claim history si existe
      var _todayNA = function() {
        var d = new Date();
        return ("0"+(d.getMonth()+1)).slice(-2) + "-" + ("0"+d.getDate()).slice(-2) + "-" + d.getFullYear();
      };
      var _todayUK = function() {
        var d = new Date();
        return ("0"+d.getDate()).slice(-2) + "/" + ("0"+(d.getMonth()+1)).slice(-2) + "/" + d.getFullYear();
      };
      // rasi date ~ convertir "12 Apr 2026 20:19 PDT" a "04-12-2026"
      var _rasiNA = rd.rasiDate ? function() {
        var p = addDaysToDate(rd.rasiDate, 0);
        return p ? ("0"+(new Date(p).getMonth()+1)).slice(-2) + "-" + ("0"+new Date(p).getDate()).slice(-2) + "-" + new Date(p).getFullYear() : _todayNA();
      } : _todayNA;
      body = body.replace(/\$ARGS\s*\{mm-dd-yyyy INITIAL EVIDENCE REQUESTED DATE\}/g, _rasiNA);
      body = body.replace(/\$ARGS\s*\{mm-dd-yyyy\}/g, _todayNA);
      body = body.replace(/\$ARGS\s*\{dd\/mm\/yyyy\}/g, rd.rasiDate ? rd.rasiDate.replace(/\s+\d{2}:\d{2}\s+\w+$/, "") : _todayUK);

      // fecha de ultima actualizacion + 15 dias
      var lastDate = rd.deliveredDate || rd.shippedDate || rd.estimatedArrival;
      if (lastDate) {
        var plus15 = addDaysToDate(lastDate, 15);
        if (plus15) body = body.replace(/\$ARGS\s*\{LAST UPDATE DATE \+ 15 DAYS\}/g, plus15);
      }

      // manejar bloques condicionales NA: quedarse con el que matchea, borrar los demas
      var conditionalBlocks = [
        { key: "USE IN CASE OF BUYER NOTR", match: !status || status === "NOTR" || status === "NOT_RETURNED" },
        { key: "USE IN CASE OF RETURNS IN TRANSIT", match: status === "IN_TRANSIT" || status === "IN TRANSIT" },
        { key: "USE IN CASE OF RETURNS LOST", match: status === "LOST" || status === "UNDELIVERABLE" },
        { key: "USE IN CASE OF RETURN DELIVERED AT SELLER ADDRESS", match: status === "DELIVERED" }
      ];

      var hasConditionals = conditionalBlocks.some(function(b) {
        return body.indexOf("$ARGS{" + b.key + "}") !== -1 || body.match(new RegExp("\\$ARGS\\s*\\{" + b.key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + "\\}"));
      });

      if (hasConditionals) {
        var lines = body.split("\n");
        var result = [];
        var i = 0;
        while (i < lines.length) {
          var line = lines[i];
          var blockMatch = null;
          for (var b = 0; b < conditionalBlocks.length; b++) {
            if (line.indexOf(conditionalBlocks[b].key) !== -1) {
              blockMatch = conditionalBlocks[b];
              break;
            }
          }
          if (blockMatch) {
            if (blockMatch.match) {
              // quedarnos con este bloque ~ saltar la linea $ARGS{USE IN CASE OF...}, mantener contenido
              i++;
              while (i < lines.length) {
                var isNextBlock = false;
                for (var nb = 0; nb < conditionalBlocks.length; nb++) {
                  if (lines[i].indexOf(conditionalBlocks[nb].key) !== -1) { isNextBlock = true; break; }
                }
                if (isNextBlock) break;
                result.push(lines[i]);
                i++;
              }
            } else {
              // borrar este bloque ~ saltar hasta el siguiente bloque condicional
              i++;
              while (i < lines.length) {
                var isNext = false;
                for (var nc = 0; nc < conditionalBlocks.length; nc++) {
                  if (lines[i].indexOf(conditionalBlocks[nc].key) !== -1) { isNext = true; break; }
                }
                if (isNext) break;
                // parar de saltar en headers de seccion importantes
                if (/^(Can I appeal|Has this decision|We're here to help|Further information|Account Specialist)/.test(lines[i].trim())) break;
                i++;
              }
            }
          } else {
            result.push(line);
            i++;
          }
        }
        body = result.join("\n");
      }

      body = body.replace(/\n{3,}/g, "\n\n");
      emailBody.value = body;
      emailBody.dispatchEvent(new Event("input", { bubbles: true }));
      emailBody.dispatchEvent(new Event("change", { bubbles: true }));
      btn.textContent = "Done";
      setTimeout(function() {
        btn.textContent = "Fill Tracking";
      }, 2000);
    });
  };
  submitArea.parentNode.insertBefore(btn, submitArea.nextSibling);
}

setInterval(addTrackingButton, 2000);

// ⁘[ BOTON FILL DATES ]⁘
// rellena placeholders de fechas en el blurb usando datos capturados del DOM

function addDatesButton() {
  var found = findTextarea();
  if (!found) return;
  var doc = found.doc;
  if (doc.getElementById("qa-fill-dates")) return;

  var previewBtn = doc.getElementById("btn_claimActionPreviewNative");
  if (!previewBtn) return;
  var submitArea = previewBtn.closest(".a-row, .a-section, div") || previewBtn.parentNode;

  var btn = doc.createElement("button");
  btn.id = "qa-fill-dates";
  btn.type = "button";
  btn.style.cssText = "background:#fff3e0;color:#e65100;padding:4px 12px;margin-top:12px;font-size:11px;border:1px solid #ffe0b2;border-radius:3px;cursor:pointer;font-weight:600;box-shadow:0 1px 2px rgba(0,0,0,0.06);transition:transform 150ms cubic-bezier(0.4,0,0.2,1),box-shadow 150ms cubic-bezier(0.4,0,0.2,1),background 150ms ease;";
  btn.textContent = "Fill Dates";
  btn.onmouseover = function() { btn.style.transform = "scale(1.03)"; btn.style.boxShadow = "0 2px 6px rgba(230,81,0,0.15)"; btn.style.background = "#ffe0b2"; };
  btn.onmouseout = function() { btn.style.transform = ""; btn.style.boxShadow = "0 1px 2px rgba(0,0,0,0.06)"; btn.style.background = "#fff3e0"; };
  btn.onmousedown = function() { btn.style.transform = "scale(0.97)"; };
  btn.onmouseup = function() { btn.style.transform = "scale(1.03)"; };
  btn.onclick = function() {
    var emailBody = doc.getElementById("email-body-id");
    if (!emailBody) { alert("Email body not found"); return; }
    var body = emailBody.value || "";
    if (!body.trim()) { alert("Select a blurb first"); return; }

    chrome.storage.local.get(["returnData"], function(res) {
      var rd = res.returnData || {};

      // max edd
      if (rd.maxEdd) {
        body = body.replace(/\$ARGS\s*\{MAX EDD\}/g, rd.maxEdd);
        body = body.replace(/\$ARGS\s*\{ESTIMATED DELIVERY DATE\}/g, rd.maxEdd);
      }

      // return window
      if (rd.returnWindow) {
        body = body.replace(/\$ARGS\s*\{RETURN WINDOW\}/g, rd.returnWindow + " days");
      }

      // delivered date
      if (rd.deliveredDate) {
        body = body.replace(/\$ARGS\s*\{DELIVERY DATE\}/g, rd.deliveredDate);
        body = body.replace(/\$ARGS\s*\{DATE OF DELIVERY\}/g, rd.deliveredDate);
        body = body.replace(/\$ARGS\s*\{ENTER RETURN DATE\}/g, rd.deliveredDate);
      }

      // shipped date (return)
      if (rd.shippedDate) {
        body = body.replace(/\$ARGS\s*\{RETURN SHIPPED DATE\}/g, rd.shippedDate);
      }

      // forward shipped date
      if (rd.fwdShippedDate) {
        body = body.replace(/\$ARGS\s*\{SHIP DATE\}/g, rd.fwdShippedDate);
      }

      // forward delivered date
      if (rd.fwdDeliveredDate) {
        body = body.replace(/\$ARGS\s*\{FORWARD DELIVERY DATE\}/g, rd.fwdDeliveredDate);
      }

      // reimbursement date
      if (rd.reimbursementDate) {
        body = body.replace(/\$ARGS\s*\{REIMBURSEMENT DATE\}/g, rd.reimbursementDate);
      }

      // rasi date
      if (rd.rasiDate) {
        body = body.replace(/\$ARGS\s*\{RASI DATE\}/g, rd.rasiDate);
        var rasiClean = rd.rasiDate.replace(/\s+\d{2}:\d{2}\s+\w+$/, "");
        body = body.replace(/\$ARGS\s*\{mm-dd-yyyy INITIAL EVIDENCE REQUESTED DATE\}/g, function() {
          var d = new Date(rasiClean);
          if (isNaN(d.getTime())) return rd.rasiDate;
          return ("0"+(d.getMonth()+1)).slice(-2) + "-" + ("0"+d.getDate()).slice(-2) + "-" + d.getFullYear();
        });
      }

      // today dates
      var today = new Date();
      var todayNA = ("0"+(today.getMonth()+1)).slice(-2) + "-" + ("0"+today.getDate()).slice(-2) + "-" + today.getFullYear();
      var todayUK = ("0"+today.getDate()).slice(-2) + "/" + ("0"+(today.getMonth()+1)).slice(-2) + "/" + today.getFullYear();
      body = body.replace(/\$ARGS\s*\{mm-dd-yyyy\}/g, todayNA);
      body = body.replace(/\$ARGS\s*\{dd\/mm\/yyyy\}/g, todayUK);

      // last update + 15 days
      var lastDate = rd.deliveredDate || rd.shippedDate || rd.estimatedArrival;
      if (lastDate) {
        var plus15 = addDaysToDate(lastDate, 15);
        if (plus15) body = body.replace(/\$ARGS\s*\{LAST UPDATE DATE \+ 15 DAYS\}/g, plus15);
      }

      body = body.replace(/\n{3,}/g, "\n\n");
      emailBody.value = body;
      emailBody.dispatchEvent(new Event("input", { bubbles: true }));
      emailBody.dispatchEvent(new Event("change", { bubbles: true }));
      btn.textContent = "Done";
      setTimeout(function() { btn.textContent = "Fill Dates"; }, 2000);
    });
  };
  submitArea.parentNode.insertBefore(btn, submitArea.nextSibling);
}

setInterval(addDatesButton, 2000);

} // end _qaHasTarget else
}
