chrome.action.onClicked.addListener(() => {
  chrome.windows.create({
    url: chrome.runtime.getURL("editor.html"),
    type: "popup",
    width: 450,
    height: 600
  });
});
