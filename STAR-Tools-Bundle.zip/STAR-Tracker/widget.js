// widget flotante del star tracker -> corre en TODAS las paginas
// lee los casos activos del storage y muestra una bolita con timer en vivo
// es como un mini dashboard que se popula en la ventana del navegador miedo

if (!window._starWidgetLoaded) {
window._starWidgetLoaded = true;

function fmtTime(seconds) {
  var s = Math.abs(Math.floor(seconds));
  var h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
  return h > 0 ? h + ":" + ("0" + m).slice(-2) + ":" + ("0" + sec).slice(-2) : m + ":" + ("0" + sec).slice(-2);
}

function tmColor(elapsed, targetSec) {
  if (!targetSec) return "#a5f3fc";
  var p = elapsed / targetSec;
  return p < 0.7 ? "#4ade80" : p < 0.9 ? "#facc15" : p < 1.0 ? "#fb923c" : "#f87171";
}

function injectWidget() {
  if (document.getElementById("star-float-widget")) return;
  if (window !== window.top) return;

  var css = document.createElement("style");
  css.textContent = [
    "#star-float-widget { position:fixed;bottom:20px;left:50%;transform:translateX(-50%);z-index:999999;font-family:'Segoe UI',Arial,sans-serif;cursor:grab;user-select:none; }",
    "#star-float-widget.dragging { cursor:grabbing; }",
    "#star-float-btn { width:44px;height:44px;border-radius:12px;border:1px solid rgba(255,255,255,0.2);background:linear-gradient(135deg,rgba(26,26,46,0.85),rgba(83,52,131,0.85));backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);box-shadow:0 4px 20px rgba(0,0,0,0.4),inset 0 0 12px rgba(255,255,255,0.08);cursor:pointer;display:flex;align-items:center;justify-content:center;transition:transform .2s,box-shadow .2s;position:relative; }",
    "#star-float-btn:hover { transform:scale(1.1);box-shadow:0 6px 28px rgba(83,52,131,0.6),inset 0 0 16px rgba(255,255,255,0.12); }",
    "#star-float-btn img { width:26px;height:26px;filter:drop-shadow(0 0 4px rgba(255,255,255,0.3)); }",
    "#star-float-badge { position:absolute;top:-4px;right:-4px;background:#f87171;color:#fff;font-size:10px;font-weight:700;min-width:16px;height:16px;border-radius:8px;display:none;align-items:center;justify-content:center;box-shadow:0 2px 6px rgba(0,0,0,0.4); }",
    "#star-float-panel { position:absolute;bottom:52px;left:50%;min-width:260px;max-width:320px;background:linear-gradient(135deg,rgba(26,26,46,0.92),rgba(15,52,96,0.92));backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);border:1px solid rgba(255,255,255,0.15);border-radius:14px;box-shadow:0 8px 32px rgba(0,0,0,0.5),inset 0 0 20px rgba(255,255,255,0.05);color:#fff;overflow:hidden;transform:translateX(-50%) translateY(8px) scale(0.95);opacity:0;pointer-events:none;transition:transform .25s cubic-bezier(0.4,0,0.2,1),opacity .25s ease; }",
    "#star-float-panel.open { transform:translateX(-50%) translateY(0) scale(1);opacity:1;pointer-events:auto; }",
    "#star-fw-header { display:flex;justify-content:space-between;align-items:center;padding:8px 14px 6px;border-bottom:1px solid rgba(255,255,255,0.08);font-size:11px;font-weight:600;opacity:0.6; }",
    "#star-fw-reconnect { background:none;border:1px solid rgba(255,255,255,0.2);border-radius:6px;color:#fff;font-size:12px;cursor:pointer;padding:2px 6px;transition:background .15s,border-color .15s; }",
    "#star-fw-reconnect:hover { background:rgba(255,255,255,0.1);border-color:rgba(255,255,255,0.4); }",
    ".star-fw-empty { padding:16px;text-align:center;opacity:0.5;font-size:12px; }",
    ".star-fw-case { padding:10px 14px; }",
    ".star-fw-case+.star-fw-case { border-top:1px solid rgba(255,255,255,0.1); }",
    ".star-fw-row1 { display:flex;justify-content:space-between;align-items:center;margin-bottom:4px; }",
    ".star-fw-id { font-size:11px;opacity:0.6; }",
    ".star-fw-timer { font-size:22px;font-weight:700;font-variant-numeric:tabular-nums;letter-spacing:0.5px;text-shadow:0 0 10px currentColor; }",
    ".star-fw-row2 { display:flex;justify-content:space-between;align-items:center;font-size:11px; }",
    ".star-fw-queue { opacity:0.7;max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap; }",
    ".star-fw-target { opacity:0.5; }",
    "#star-float-widget.lite #star-float-btn { background:#2a2a3e;backdrop-filter:none;-webkit-backdrop-filter:none;box-shadow:none;transition:none; }",
    "#star-float-widget.lite #star-float-btn:hover { box-shadow:none;transform:none; }",
    "#star-float-widget.lite #star-float-btn img { filter:none; }",
    "#star-float-widget.lite #star-float-panel { background:#1e1e2e;backdrop-filter:none;-webkit-backdrop-filter:none;box-shadow:none;transition:none; }",
    "#star-float-widget.lite .star-fw-timer { text-shadow:none; }",
    "#star-fw-aux { padding:8px 14px;border-top:1px solid rgba(255,255,255,0.08); }",
    "#star-fw-aux .star-fw-row1 { margin-bottom:0; }",
    "#star-fw-aux .star-fw-id { font-size:10px;text-transform:uppercase;letter-spacing:0.5px; }",
    "#star-fw-aux .star-fw-timer { font-size:16px; }"
  ].join("\n");
  document.head.appendChild(css);

  var w = document.createElement("div");
  w.id = "star-float-widget";
  if (_liteMode) w.classList.add("lite");
  var iconUrl = chrome.runtime.getURL("icon48.png");
  w.innerHTML =
    '<div id="star-float-btn"><img src="' + iconUrl + '" alt="STAR"><span id="star-float-badge"></span></div>' +
    '<div id="star-float-panel"><div id="star-fw-header"><span><img src="' + chrome.runtime.getURL("icon48.png") + '" style="width:16px;height:16px;vertical-align:-2px;margin-right:4px;border-radius:2px"> STAR Tracker</span><button id="star-fw-reconnect" title="Reconnect detectors">🔄</button></div><div id="star-fw-body"></div><div id="star-fw-aux"></div></div>';
  document.body.appendChild(w);

  var btn = document.getElementById("star-float-btn");
  var panel = document.getElementById("star-float-panel");

  btn.addEventListener("click", function() {
    if (!btn._suppressClick) {
      panel.classList.toggle("open");
      chrome.storage.local.set({ widgetOpen: panel.classList.contains("open") });
    }
  });

  // restaurar si estaba abierto
  chrome.storage.local.get("widgetOpen", function(res) {
    if (res.widgetOpen) panel.classList.add("open");
  });

  document.getElementById("star-fw-reconnect").addEventListener("click", function(e) {
    e.stopPropagation();
    chrome.runtime.sendMessage({ type: "RECONNECT_DETECTORS" });
    setTimeout(function() { chrome.runtime.sendMessage({ type: "RECONNECT_DETECTORS" }); }, 5000);
    this.textContent = "✅";
    var self = this;
    setTimeout(function() { self.textContent = "🔄"; }, 1500);
  });

  // jalar y mover
  var ds = { dragging: false, sx: 0, sy: 0, ox: 0, oy: 0, moved: false };
  btn.addEventListener("mousedown", function(e) {
    var r = w.getBoundingClientRect();
    ds = { dragging: true, sx: e.clientX, sy: e.clientY, ox: r.left, oy: r.top, moved: false };
    w.classList.add("dragging"); e.preventDefault();
  });
  document.addEventListener("mousemove", function(e) {
    if (!ds.dragging) return;
    var dx = e.clientX - ds.sx, dy = e.clientY - ds.sy;
    if (Math.abs(dx) > 3 || Math.abs(dy) > 3) ds.moved = true;
    if (!ds.moved) return;
    w.style.left = (ds.ox + dx) + "px"; w.style.top = (ds.oy + dy) + "px";
    w.style.right = "auto"; w.style.bottom = "auto"; w.style.transform = "none";
  });
  document.addEventListener("mouseup", function() {
    if (ds.dragging) {
      w.classList.remove("dragging");
      if (ds.moved) {
        btn._suppressClick = true; setTimeout(function() { btn._suppressClick = false; }, 50);
        var r = w.getBoundingClientRect();
        chrome.storage.local.set({ widgetPos: { x: r.left, y: r.top } });
      }
      ds.dragging = false;
    }
  });

  // guardar posicion restored
  chrome.storage.local.get("widgetPos", function(res) {
    if (res.widgetPos) {
      w.style.left = res.widgetPos.x + "px"; w.style.top = res.widgetPos.y + "px";
      w.style.right = "auto"; w.style.bottom = "auto"; w.style.transform = "none";
    }
  });
}

function updateWidget() {
  if (window !== window.top) return;
  chrome.storage.local.get(["activeProfile", "activeCasesData", "widgetCases"], function(res) {
    if (!res.activeProfile) {
      var el = document.getElementById("star-float-widget");
      if (el) el.remove();
      return;
    }
    if (!document.getElementById("star-float-widget")) injectWidget();

    var badge = document.getElementById("star-float-badge");
    var body = document.getElementById("star-fw-body");
    if (!badge || !body) return;

    var cases = res.activeCasesData || {};
    var qdata = res.widgetCases || {};
    var ids = Object.keys(cases);
    var count = ids.length;

    badge.style.display = count > 0 ? "flex" : "none";
    badge.textContent = count;

    if (count === 0) { body.innerHTML = '<div class="star-fw-empty">⏳ No active cases</div>'; }

    if (count > 0) {
    var html = "";
    for (var i = 0; i < ids.length; i++) {
      var id = ids[i], c = cases[id];
      var elapsed = Math.round((Date.now() - c.startedAt) / 1000);
      var qd = qdata[id] || {};
      var targetSec = qd.targetMin ? qd.targetMin * 60 : 0;
      var color = tmColor(elapsed, targetSec);
      var ql = qd.flag ? qd.flag + " " + (qd.label || qd.queue || "—") : (qd.queue || "");
      var ts = qd.targetMin ? "🎯 " + fmtTime(qd.targetMin * 60) : "";
      var qDisp, qCls = "";
      if (ql) { qDisp = ql; }
      else if (elapsed < 15) { qDisp = "🔍 Detecting queue..."; }
      else { qDisp = "⚠️ Queue not detected"; qCls = ' style="color:#fb923c;opacity:1"'; }

      html += '<div class="star-fw-case"><div class="star-fw-row1">' +
        '<span class="star-fw-id">Task ID: ' + id + '</span>' +
        '<span class="star-fw-timer" style="color:' + color + '">' + fmtTime(elapsed) + '</span></div>' +
        '<div class="star-fw-row2"><span class="star-fw-queue"' + qCls + '>' + qDisp + '</span>' +
        '<span class="star-fw-target">' + (ts || (ql ? "" : "Try 🔄 Reconnect")) + '</span></div></div>';
    }
    body.innerHTML = html;
    }

    // aux en vivo ~ auxWidgetStatus (background, estable) con fallback a auxLiveStatus (content, inmediato)
    var auxDiv = document.getElementById("star-fw-aux");
    if (auxDiv) {
      chrome.storage.local.get(["auxWidgetStatus", "auxLiveStatus"], function(r) {
        var ws = r.auxWidgetStatus;
        var live = r.auxLiveStatus;
        var statusText, elapsed, color;

        if (ws && ws.status && ws.since) {
          statusText = ws.status;
          elapsed = Math.round((Date.now() - ws.since) / 1000);
        } else if (live && live.status && live.ts && (Date.now() - live.ts) < 5000) {
          statusText = live.status;
          elapsed = live.paragonTimer || 0;
        }

        if (!statusText) { auxDiv.innerHTML = ''; return; }
        color = statusText === "Available" ? "#4ade80" : "#a5f3fc";
        auxDiv.innerHTML = '<div class="star-fw-row1">' +
          '<span class="star-fw-id">🔄 ' + statusText + '</span>' +
          '<span class="star-fw-timer" style="color:' + color + '">' + fmtTime(elapsed) + '</span></div>';
      });
    }
  });
}

// solo correr el interval si hay perfil activo ~ cero cpu cuando no se usa
var widgetActive = false;
var widgetInterval = null;
var _liteMode = false;

function startWidgetLoop() {
  if (widgetInterval) return;
  widgetActive = true;
  widgetInterval = setInterval(updateWidget, _liteMode ? 3000 : 1000);
}

function stopWidgetLoop() {
  widgetActive = false;
  if (widgetInterval) { clearInterval(widgetInterval); widgetInterval = null; }
}

// escuchar cambios en storage en vez de polling ~ mucho mas liviano
chrome.storage.onChanged.addListener(function(changes) {
  if (changes.activeProfile) {
    if (changes.activeProfile.newValue && !widgetActive) startWidgetLoop();
    else if (!changes.activeProfile.newValue && widgetActive) { stopWidgetLoop(); updateWidget(); }
  }
  if (changes.liteMode) {
    _liteMode = !!changes.liteMode.newValue;
    var wEl = document.getElementById("star-float-widget");
    if (wEl) wEl.classList.toggle("lite", _liteMode);
    if (widgetActive) { stopWidgetLoop(); startWidgetLoop(); }
  }
});

// arrancar de una si ya hay perfil
chrome.storage.local.get(["activeProfile", "liteMode"], function(res) {
  _liteMode = !!res.liteMode;
  if (res.activeProfile) startWidgetLoop();
});

}
