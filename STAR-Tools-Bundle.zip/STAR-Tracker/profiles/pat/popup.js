function starAlert(msg) { var o = document.createElement("div"); o.className = "star-modal-overlay"; o.innerHTML = '<div class="star-modal"><div class="star-modal-msg"></div><button class="star-modal-ok">OK</button></div>'; o.querySelector(".star-modal-msg").textContent = msg; o.querySelector(".star-modal-ok").onclick = function() { o.remove(); }; document.body.appendChild(o); }
function starConfirm(msg, cb) { var o = document.createElement("div"); o.className = "star-modal-overlay"; o.innerHTML = '<div class="star-modal"><div class="star-modal-msg"></div><div style="display:flex;gap:8px;justify-content:center"><button class="star-modal-ok">OK</button><button class="star-modal-ok" style="opacity:0.6">Cancel</button></div></div>'; o.querySelector(".star-modal-msg").textContent = msg; var btns = o.querySelectorAll("button"); btns[0].onclick = function() { o.remove(); cb(true); }; btns[1].onclick = function() { o.remove(); cb(false); }; document.body.appendChild(o); }
chrome.storage.local.get(["liteMode"], function(r) { if (r.liteMode) document.body.classList.add("lite"); });

// lite custom props ~ aplica colores personalizados cuando lite mode esta on
function applyLiteProps() {
  chrome.storage.local.get(["liteMode", "liteCustomBg", "liteCustomText", "liteCustomAccent", "liteCustomFontSize"], function(r) {
    if (!r.liteMode) return;
    document.body.style.setProperty("--lite-bg", r.liteCustomBg || "#1e1e2e");
    document.body.style.setProperty("--lite-text", r.liteCustomText || "rgba(255,255,255,0.9)");
    document.body.style.setProperty("--lite-accent", r.liteCustomAccent || "#006878");
    document.body.style.setProperty("--lite-font", r.liteCustomFontSize || "12px");
  });
}
applyLiteProps();
document.getElementById("backBtn").onclick = function() { chrome.storage.local.set({ activeProfile: "" }); window.location.href = "../../launcher.html"; };
var PROFILE_ID = "pat";


// Click sound
const audioCtx = new AudioContext();
let muted = false;

function playClick() {
  if (muted) return;
  const t = audioCtx.currentTime;
  const o1 = audioCtx.createOscillator();
  const g1 = audioCtx.createGain();
  o1.type = "sine";
  o1.frequency.setValueAtTime(600, t);
  o1.frequency.exponentialRampToValueAtTime(300, t + 0.1);
  g1.gain.setValueAtTime(0.15, t);
  g1.gain.exponentialRampToValueAtTime(0.001, t + 0.1);
  o1.connect(g1);
  g1.connect(audioCtx.destination);
  o1.start(t);
  o1.stop(t + 0.1);

  const o2 = audioCtx.createOscillator();
  const g2 = audioCtx.createGain();
  o2.type = "sine";
  o2.frequency.setValueAtTime(900, t);
  o2.frequency.exponentialRampToValueAtTime(400, t + 0.07);
  g2.gain.setValueAtTime(0.08, t);
  g2.gain.exponentialRampToValueAtTime(0.001, t + 0.07);
  o2.connect(g2);
  g2.connect(audioCtx.destination);
  o2.start(t);
  o2.stop(t + 0.07);
}

document.addEventListener("click", (e) => {
  if (e.target.closest("button, .mp-header, .aux-header, .unknown-header, .toggle-switch, .pin-btn")) {
    playClick();
  }
});

// Mute toggle
const muteBtn = document.getElementById("muteToggle");

function applyMute(m) {
  muted = m;
  muteBtn.textContent = m ? "🔇" : "🔊";
}

chrome.storage.local.get(["muted"], (res) => applyMute(res.muted || false));

muteBtn.onclick = () => {
  muted = !muted;
  chrome.storage.local.set({ muted });
  applyMute(muted);
};

const pinnedDiv = document.getElementById("pinned");
const dashboard = document.getElementById("dashboard");
const auxSection = document.getElementById("auxSection");
const unknownDiv = document.getElementById("unknown");
const resetBtn = document.getElementById("reset");
const autoAcceptDiv = document.getElementById("autoAcceptToggle");
const autoCleanDiv = document.getElementById("autoCleanToggle");
const autoIncrementDiv = document.getElementById("autoIncrementToggle");
const autoOpenDiv = document.getElementById("autoOpenToggle");
const paragonDarkDiv = document.getElementById("paragonDarkToggle");
const devConsole = document.getElementById("devConsole");
const totalCounter = document.getElementById("totalCounter");
const recentCasesDiv = document.getElementById("recentCases");

const MP_ORDER = ["US", "UK", "CA", "DE", "FR", "ES", "IT", "IN", "JP", "BR", "MX", "AU", "AE", "SA", "EG", "SG", "PL", "NL", "SE", "TR", "BE", "IE", "ZA"];

// History navigation
let viewingDate = null; // null = live (today's stats), string = historical date

function fmt(seconds) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.round(seconds % 60);
  if (h > 0) return h + "hr " + String(m).padStart(2, "0") + ":" + String(s).padStart(2, "0");
  return m + ":" + String(s).padStart(2, "0");
}

function short(queue, qmap) {
  const info = qmap[queue];
  if (info) return (info.flag || "") + " " + (info.label || queue.replace(/@.*$/, ""));
  return queue.replace(/@.*$/, "");
}

function getQueues(cb) {
  chrome.storage.local.get(["customQueues_" + PROFILE_ID], (res) => {
    const custom = res["customQueues_" + PROFILE_ID] || {};
    const merged = {};
    // Start with hardcoded
    for (const [k, v] of Object.entries(QUEUE_MAP_PAT)) {
      if (custom[k] === null) continue; // deleted
      merged[k] = custom[k] || v;
    }
    // Add new custom queues
    for (const [k, v] of Object.entries(custom)) {
      if (v && !QUEUE_MAP_PAT[k]) merged[k] = v;
    }
    cb(merged);
  });
}

function groupByMp(qmap) {
  const g = {};
  for (const [q, info] of Object.entries(qmap)) {
    if (!g[info.mp]) g[info.mp] = [];
    g[info.mp].push({ queue: q, ...info });
  }
  return g;
}

function makeToggle(container, key, label) {
  if (container.dataset.initialized === key) {
    chrome.storage.local.get([key], (res) => {
      const input = container.querySelector("input");
      if (input) input.checked = res[key] || false;
    });
    return;
  }
  container.dataset.initialized = key;
  chrome.storage.local.get([key], (res) => {
    const enabled = res[key] || false;
    container.innerHTML = "";
    container.className = "toggle-row";

    const txt = document.createElement("span");
    txt.textContent = label;

    const toggle = document.createElement("label");
    toggle.className = "toggle-switch";

    const input = document.createElement("input");
    input.type = "checkbox";
    input.checked = enabled;
    input.onchange = () => chrome.storage.local.set({ [key]: input.checked });

    const slider = document.createElement("span");
    slider.className = "toggle-slider";

    toggle.append(input, slider);
    container.append(txt, toggle);
  });
}

function renderToggles() {
  makeToggle(autoAcceptDiv, "autoAccept", "⚡ Auto-Accept");
  autoAcceptDiv.title = "Automatically accepts incoming cases when they appear in the lobby";
  makeToggle(autoCleanDiv, "autoClean", "🧹 Auto-Clean Missed");
  autoCleanDiv.title = "Clears 'missed case' status automatically and sets you back to 'Available' AUX";
  autoIncrementDiv.title = "Clicks 'Increase Task' button automatically when present. Refresh lobby if not visible. ⚠️ Use at your own risk ⚠️";
  makeToggle(autoIncrementDiv, "autoIncrement", "📈 Auto-Increment Task");
  makeToggle(autoOpenDiv, "autoOpenAttachments", "📎 Auto-Open Attachments");
  autoOpenDiv.title = "Opens seller attachment images and files in new tabs when a case is loaded";
  makeToggle(paragonDarkDiv, "paragonDarkMode", "");
  paragonDarkDiv.title = "Forces dark mode on Paragon pages";
  chrome.storage.local.get(["paragonDarkMode"], (res) => {
    const on = res.paragonDarkMode || false;
    const label = paragonDarkDiv.querySelector("span");
    if (label) label.textContent = on ? "🌑 Dark Paragon" : "☀️ Day Paragon";
    const input = paragonDarkDiv.querySelector("input");
    if (input) {
      input.addEventListener("change", () => {
        const lbl = paragonDarkDiv.querySelector("span");
        if (lbl) lbl.textContent = input.checked ? "🌑 Dark Paragon" : "☀️ Day Paragon";
      });
    }
  });

  // Dev console visibility
  chrome.storage.local.get(["devMode"], (res) => {
    devConsole.style.display = res.devMode ? "" : "none";
    if (res.devMode) refreshDevConsole();
  });

  // Missed counter
  const mc = document.getElementById("missedCounter");
  chrome.storage.local.get(["missedCount"], (res) => {
    const count = res.missedCount || 0;
    mc.innerHTML = "";
    if (count > 0) {
      const txt = document.createElement("span");
      txt.textContent = "🚫 Missed cleaned: " + count;
      const btn = document.createElement("button");
      btn.className = "missed-clear";
      btn.textContent = "✖";
      btn.title = "Clear missed counter";
      btn.onclick = () => { chrome.storage.local.remove("missedCount"); mc.innerHTML = ""; };
      mc.append(txt, btn);
    }
  });
}

function render() {
  getQueues((qmap) => {
  chrome.storage.local.get(["stats_" + PROFILE_ID, "statsHistory_" + PROFILE_ID, "saveHistory", "collapsed", "pins_" + PROFILE_ID, "locks_" + PROFILE_ID, "statusTime", "statusTimeHistory", "auxLock", "auxCollapsed", "mpColors_" + PROFILE_ID, "unidentified_" + PROFILE_ID, "showRecentCases", "caseLog_" + PROFILE_ID], (res) => {
    var stats;
    var today = new Date().toISOString().slice(0, 10);
    var historyData = res["statsHistory_" + PROFILE_ID] || {};
    var historyOn = res.saveHistory || false;
    var mpColors = res["mpColors_" + PROFILE_ID] || {};
    if (viewingDate) {
      stats = historyData[viewingDate] || {};
    } else if (historyOn && historyData[today]) {
      stats = historyData[today];
    } else {
      stats = res["stats_" + PROFILE_ID] || {};
    }

    // Resolve statusTime for the viewed date
    var statusTimeHist = res.statusTimeHistory || {};
    var statusTime;
    if (viewingDate) {
      statusTime = statusTimeHist[viewingDate] || {};
    } else if (historyOn && statusTimeHist[today]) {
      statusTime = statusTimeHist[today];
    } else {
      statusTime = res.statusTime || {};
    }

    const collapsed = res.collapsed || {};
    // Default all MPs to collapsed
    const pins = res["pins_" + PROFILE_ID] || {};
    const locks = res["locks_" + PROFILE_ID] || {};
    const auxLock = res.auxLock || false;
    const auxCollapsed = res.auxCollapsed || false;
    const groups = groupByMp(qmap);

    // Show/hide export week button
    document.getElementById("exportWeekBtn").style.display = historyOn ? "" : "none";

    const allUnidentified = res["unidentified_" + PROFILE_ID] || [];
    const filterDate = viewingDate || today;
    const unidentifiedForDay = allUnidentified.filter(u => u.date === filterDate);

    // --- Total counter + history nav ---
    let totalCases = 0, totalSeconds = 0;
    for (const [q, s] of Object.entries(stats)) {
      if (q === "unknown") continue;
      totalCases += s.caseCount; totalSeconds += s.totalSeconds;
    }
    for (const u of unidentifiedForDay) {
      totalCases++; totalSeconds += u.seconds;
    }
    const totalAht = totalCases > 0 ? fmt(totalSeconds / totalCases) : "0:00";
    const dateLabel = viewingDate || "Today";
    totalCounter.innerHTML = "";

    var totalResetTimer = null;
    var totalResetTick = null;
    var resetTotalBtn = document.createElement("button");
    resetTotalBtn.textContent = "🔄";
    resetTotalBtn.title = "Reset case counter for this day";
    resetTotalBtn.style.cssText = "border:none;background:none;cursor:pointer;font-size:14px;padding:0 4px;opacity:0.4;transition:opacity 0.2s;color:inherit;display:flex;align-items:center;justify-content:center;";
    resetTotalBtn.onmouseenter = function() { resetTotalBtn.style.opacity = "1"; };
    resetTotalBtn.onmouseleave = function() { if (!totalResetTimer) resetTotalBtn.style.opacity = "0.5"; };
    resetTotalBtn.onclick = function() {
      if (totalResetTimer) {
        clearTimeout(totalResetTimer);
        clearInterval(totalResetTick);
        totalResetTimer = null;
        totalResetTick = null;
        resetTotalBtn.textContent = "🔄";
        resetTotalBtn.style.opacity = "0.5";
        return;
      }
      resetTotalBtn.textContent = "⏳5";
      resetTotalBtn.style.opacity = "1";
      var cd = 5;
      totalResetTick = setInterval(function() { cd--; if (cd > 0) resetTotalBtn.textContent = "⏳" + cd; }, 1000);
      totalResetTimer = setTimeout(function() {
        clearInterval(totalResetTick);
        totalResetTimer = null;
        totalResetTick = null;
        if (viewingDate && historyOn) {
          var histKey = "statsHistory_" + PROFILE_ID;
          chrome.storage.local.get([histKey, "unidentified_" + PROFILE_ID], function(r) {
            var hist = r[histKey] || {};
            delete hist[viewingDate];
            var unid = (r["unidentified_" + PROFILE_ID] || []).filter(function(u) { return u.date !== viewingDate; });
            var toSave = {}; toSave[histKey] = hist; toSave["unidentified_" + PROFILE_ID] = unid;
            chrome.storage.local.set(toSave); render();
          });
        } else {
          chrome.storage.local.remove(["stats_" + PROFILE_ID, "unidentified_" + PROFILE_ID]);
          render();
        }
      }, 5000);
    };

    // piramide centrada: stats > fecha > controles
    totalCounter.style.cssText = "text-align:center;position:relative;";

    var line1 = document.createElement("div");
    line1.style.cssText = "font-size:16px;font-weight:bold;padding:4px 0;";
    line1.append(document.createTextNode("📋 " + totalCases + " casos | Avg: " + totalAht + " "));
    totalCounter.appendChild(line1);
    if (!viewingDate) {
      resetTotalBtn.style.cssText += "position:absolute;top:50%;right:4px;transform:translateY(-50%);";
      totalCounter.appendChild(resetTotalBtn);
    }

    if (historyOn) {
      var line2 = document.createElement("div");
      line2.style.cssText = "font-size:10px;opacity:0.5;padding:1px 0;";
      line2.textContent = "📅 " + dateLabel + " 📅";
      totalCounter.appendChild(line2);

      var line3 = document.createElement("div");
      line3.style.cssText = "display:flex;align-items:center;justify-content:center;gap:10px;padding:2px 0;";

      var prevBtn = document.createElement("button");
      prevBtn.textContent = "◀";
      prevBtn.style.cssText = "border:none;background:none;cursor:pointer;font-size:14px;padding:2px 8px;color:inherit;opacity:0.6;";
      prevBtn.onclick = function() {
        var d = viewingDate ? new Date(viewingDate) : new Date();
        d.setDate(d.getDate() - 1);
        viewingDate = d.toISOString().slice(0, 10);
        render();
      };

      var todayBtn = document.createElement("button");
      todayBtn.textContent = "◉";
      todayBtn.title = "Back to today";
      todayBtn.style.cssText = "border:none;background:none;cursor:pointer;font-size:14px;padding:2px 6px;color:inherit;opacity:0.6;";
      todayBtn.onclick = function() { viewingDate = null; render(); };

      var nextBtn = document.createElement("button");
      nextBtn.textContent = "▶";
      nextBtn.style.cssText = "border:none;background:none;cursor:pointer;font-size:14px;padding:2px 8px;color:inherit;opacity:0.6;";
      nextBtn.onclick = function() {
        if (!viewingDate) return;
        var d = new Date(viewingDate);
        d.setDate(d.getDate() + 1);
        var tomorrow = d.toISOString().slice(0, 10);
        var today = new Date().toISOString().slice(0, 10);
        viewingDate = tomorrow >= today ? null : tomorrow;
        render();
      };

      line3.append(prevBtn, todayBtn, nextBtn);
      totalCounter.appendChild(line3);
    }


    // --- recent cases ~ ultimos 5 casos del dia ---
    recentCasesDiv.innerHTML = "";
    if (res.showRecentCases) {
      var caseLog = res["caseLog_" + PROFILE_ID] || {};
      var dayKey = viewingDate || today;
      var dayCases = caseLog[dayKey] || [];
      var recent = dayCases.slice(-5).reverse();
      for (var ri = 0; ri < recent.length; ri++) {
        var rc = recent[ri];
        var rRow = document.createElement("div");
        rRow.className = "recent-row";
        var rTime = document.createElement("span");
        rTime.className = "recent-time";
        rTime.textContent = rc.time || "";
        var rQueue = document.createElement("span");
        rQueue.className = "recent-queue";
        rQueue.textContent = short(rc.queue, qmap);
        rQueue.title = rc.queue;
        var rDur = document.createElement("span");
        rDur.className = "recent-duration";
        rDur.textContent = fmt(rc.seconds);
        rRow.append(rTime, rQueue, rDur);
        recentCasesDiv.appendChild(rRow);
      }
    }

    // --- Pinned queues ---
    pinnedDiv.innerHTML = "";
    const pinnedQueues = Object.keys(pins).filter(q => pins[q] && qmap[q]);

    for (const q of pinnedQueues) {
      const info = qmap[q];
      const s = stats[q];
      const count = s ? s.caseCount : 0;
      const avgSec = count > 0 ? s.totalSeconds / count : 0;
      const avgMin = avgSec / 60;
      const onTarget = count === 0 || avgMin <= info.targetMin;
      const locked = locks[info.mp];

      const row = document.createElement("div");
      row.className = "pinned-row";

      const dot = document.createElement("span");
      dot.className = "dot " + (count === 0 ? "neutral" : onTarget ? "green" : "red");

      const name = document.createElement("span");
      name.className = "queue-name";
      name.textContent = short(q, qmap);
      name.title = q;

      const aht = document.createElement("span");
      aht.className = "queue-aht";
      aht.textContent = fmt(avgSec) + " (" + count + ")";

      const target = document.createElement("span");
      target.className = "queue-target";
      target.textContent = "T:" + fmt(info.targetMin * 60);

      const unpin = document.createElement("button");
      unpin.className = "pin-btn active" + (locked ? " disabled" : "");
      unpin.textContent = "📌";
      unpin.title = locked ? "Locked" : "Unpin";
      unpin.onclick = () => {
        if (locked) return;
        pins[q] = false;
        chrome.storage.local.set({ ["pins_" + PROFILE_ID]: pins });
        render();
      };

      row.append(dot, name, aht, target, unpin);
      pinnedDiv.appendChild(row);
    }

    // --- Marketplace sections ---
    dashboard.innerHTML = "";

    for (const mp of MP_ORDER) {
      const queues = groups[mp];
      if (!queues) continue;

      const locked = locks[mp];

      let mpCases = 0, mpSeconds = 0;
      for (const q of queues) {
        const s = stats[q.queue];
        if (s) { mpCases += s.caseCount; mpSeconds += s.totalSeconds; }
      }
      const mpAht = mpCases > 0 ? fmt(mpSeconds / mpCases) : "0:00";

      const header = document.createElement("div");
      header.className = "mp-header";
      const mpColor = mpColors[mp] || null;
      if (mpColor) {
        header.style.background = "linear-gradient(135deg, " + mpColor + "66, " + mpColor + "26)";
        header.style.borderColor = mpColor + "4d";
      }

      const arrow = document.createElement("span");
      arrow.textContent = collapsed[mp] === false ? "▼" : "▶";

      const title = document.createElement("span");
      title.className = "mp-title";
      title.textContent = " " + mp + " — " + mpCases + " | " + mpAht;
      header.onclick = (e) => { if (e.target.closest("button")) return;
        collapsed[mp] = collapsed[mp] === false ? true : false;
        chrome.storage.local.set({ collapsed });
        render();
      };

      const lockBtn = document.createElement("button");
      lockBtn.className = "mp-btn";
      lockBtn.textContent = locked ? "🔒" : "🔓";
      lockBtn.title = "Lock this marketplace — prevents reset and pin changes";
      lockBtn.onclick = (e) => {
        e.stopPropagation();
        locks[mp] = !locked;
        chrome.storage.local.set({ ["locks_" + PROFILE_ID]: locks });
        render();
      };

      const resetMp = document.createElement("button");
      resetMp.className = "mp-btn" + (locked ? " disabled" : "");
      resetMp.textContent = "🗑";
      resetMp.title = "Reset stats for this marketplace";
      resetMp.onclick = (e) => {
        e.stopPropagation();
        if (locked) return;
        starConfirm("Reset " + mp + "?", function(ok) { if (!ok) return;
        for (const q of queues) delete stats[q.queue];
        chrome.storage.local.set({ ["stats_" + PROFILE_ID]: stats });
        render(); });
      };

      header.append(arrow, title, lockBtn, resetMp);
      dashboard.appendChild(header);

      const section = document.createElement("div");
      section.className = "mp-section" + (collapsed[mp] === false ? " open" : "");

      for (const q of queues) {
        const s = stats[q.queue];
        const count = s ? s.caseCount : 0;
        const avgSec = count > 0 ? s.totalSeconds / count : 0;
        const avgMin = avgSec / 60;
        const onTarget = count === 0 || avgMin <= q.targetMin;
        const isPinned = pins[q.queue];

        const row = document.createElement("div");
        row.className = "queue-row";

        const dot = document.createElement("span");
        dot.className = "dot " + (count === 0 ? "neutral" : onTarget ? "green" : "red");

        const name = document.createElement("span");
        name.className = "queue-name";
        name.textContent = short(q.queue, qmap);
        name.title = q.queue;

        const aht = document.createElement("span");
        aht.className = "queue-aht";
        aht.textContent = fmt(avgSec) + " (" + count + ")";

        const target = document.createElement("span");
        target.className = "queue-target";
        target.textContent = "T:" + fmt(q.targetMin * 60);

        const pin = document.createElement("button");
        pin.className = "pin-btn" + (isPinned ? " active" : "") + (locked ? " disabled" : "");
        pin.textContent = isPinned ? "📌" : "○";
        pin.title = isPinned ? "Unpin" : "Pin to top";
        pin.onclick = () => {
          if (locked) return;
          pins[q.queue] = !isPinned;
          chrome.storage.local.set({ ["pins_" + PROFILE_ID]: pins });
          render();
        };

        row.append(dot, name, aht, target, pin);
        section.appendChild(row);
      }

      dashboard.appendChild(section);
    }

    // --- Aux Used Today ---
    auxSection.innerHTML = "";
    const auxKeys = Object.keys(statusTime).filter(s => statusTime[s] > 0);

    const auxHeader = document.createElement("div");
    auxHeader.className = "aux-header";

    const auxArrow = document.createElement("span");
    auxArrow.textContent = auxCollapsed ? "▶" : "▼";

    const auxTitle = document.createElement("span");
    auxTitle.className = "mp-title";
    auxTitle.textContent = " Aux Used Today";
    auxHeader.onclick = (e) => { if (e.target.closest("button")) return;
      chrome.storage.local.set({ auxCollapsed: !auxCollapsed });
      render();
    };

    const auxLockBtn = document.createElement("button");
    auxLockBtn.className = "mp-btn";
    auxLockBtn.textContent = auxLock ? "🔒" : "🔓";
    auxLockBtn.title = "Lock aux section — prevents reset";
    auxLockBtn.onclick = (e) => {
      e.stopPropagation();
      chrome.storage.local.set({ auxLock: !auxLock });
      render();
    };

    const auxResetBtn = document.createElement("button");
    auxResetBtn.className = "mp-btn" + (auxLock ? " disabled" : "");
    auxResetBtn.textContent = "🗑";
    auxResetBtn.title = "Reset all aux times";
    auxResetBtn.onclick = (e) => {
      e.stopPropagation();
      if (auxLock) return;
      starConfirm("Reset auxiliares?", function(ok) { if (!ok) return;
      chrome.storage.local.remove("statusTime");
      render(); });
    };

    auxHeader.append(auxArrow, auxTitle, auxLockBtn, auxResetBtn);
    auxSection.appendChild(auxHeader);

    if (auxKeys.length > 0) {
      const auxBody = document.createElement("div");
      auxBody.className = "aux-section" + (auxCollapsed ? "" : " open");

      for (const s of auxKeys) {
        const row = document.createElement("div");
        row.className = "aux-row";

        const name = document.createElement("span");
        name.className = "aux-name";
        name.textContent = s;

        const time = document.createElement("span");
        time.className = "aux-time";
        time.textContent = fmt(statusTime[s]);

        const del = document.createElement("button");
        del.className = "aux-del" + (auxLock ? " disabled" : "");
        del.textContent = "✖";
        del.title = "Remove this aux entry";
        del.onclick = () => {
          if (auxLock) return;
          delete statusTime[s];
          chrome.storage.local.set({ statusTime });
          render();
        };

        row.append(name, time, del);
        auxBody.appendChild(row);
      }

      auxSection.appendChild(auxBody);
    }

    // --- Unidentified cases ---
    unknownDiv.innerHTML = "";
    chrome.storage.local.get(["unknownCollapsed"], (ures) => {
      const unidentified = unidentifiedForDay;
      if (unidentified.length === 0) return;

      const unkCollapsed = ures.unknownCollapsed || false;

      const header = document.createElement("div");
      header.className = "unknown-header";

      const arrow = document.createElement("span");
      arrow.textContent = unkCollapsed ? "▶" : "▼";

      const title = document.createElement("span");
      title.className = "mp-title";
      title.textContent = " ⚠️Not Identified⚠️ — " + unidentified.length;
      header.onclick = (e) => { if (e.target.closest("button")) return;
        chrome.storage.local.set({ unknownCollapsed: !unkCollapsed });
        render();
      };

      const clearBtn = document.createElement("button");
      clearBtn.className = "mp-btn";
      clearBtn.textContent = "🗑";
      clearBtn.title = "Clear all unidentified cases";
      clearBtn.onclick = (e) => {
        e.stopPropagation();
        starConfirm("Clear unidentified?", function(ok) { if (!ok) return;
        chrome.storage.local.remove("unidentified_" + PROFILE_ID);
        render(); });
      };

      header.append(arrow, title, clearBtn);
      unknownDiv.appendChild(header);

      if (!unkCollapsed) {
        for (const item of unidentified) {
          const row = document.createElement("div");
          row.className = "unknown-row";

          const name = document.createElement("span");
          name.className = "unknown-name";
          name.textContent = item.queue;

          const info = document.createElement("span");
          info.className = "unknown-info";
          info.textContent = fmt(item.seconds);

          const ts = document.createElement("span");
          ts.className = "unknown-time-stamp";
          ts.textContent = item.time;

          row.append(name, info, ts);
          unknownDiv.appendChild(row);
        }
      }
    });
  });
  });
}

// reset todo (respeta locks) ~ con 5s de undo
let resetTimer = null;
let resetTick = null;
resetBtn.onclick = () => {
  if (resetTimer) {
    // cancelar ~ deshacer
    clearTimeout(resetTimer);
    clearInterval(resetTick);
    resetTimer = null;
    resetTick = null;
    resetBtn.textContent = "🗑 Reset All";
    resetBtn.removeAttribute("style");
    return;
  }

  resetBtn.textContent = "⏳ Undo (5s)";
  resetBtn.style.background = "linear-gradient(135deg, rgba(231,76,60,0.7), rgba(192,57,43,0.5))";
  resetBtn.style.boxShadow = "0 4px 16px rgba(231,76,60,0.3), inset 0 0 12px -4px rgba(255,255,255,0.3)";

  let countdown = 5;
  resetTick = setInterval(() => {
    countdown--;
    if (countdown > 0) {
      resetBtn.textContent = "⏳ Undo (" + countdown + "s)";
    }
  }, 1000);

  resetTimer = setTimeout(() => {
    clearInterval(resetTick);
    resetTimer = null;
    resetTick = null;
    resetBtn.textContent = "🗑 Reset All";
    resetBtn.removeAttribute("style");

    getQueues((qmap) => {
    chrome.storage.local.get(["stats_" + PROFILE_ID, "locks_" + PROFILE_ID, "auxLock"], (res) => {
      const stats = res["stats_" + PROFILE_ID] || {};
      const locks = res["locks_" + PROFILE_ID] || {};

      for (const q of Object.keys(stats)) {
        const info = qmap[q];
        if (info && locks[info.mp]) continue;
        if (q === "unknown") { delete stats[q]; continue; }
        delete stats[q];
      }

      chrome.storage.local.set({ ["stats_" + PROFILE_ID]: stats });
      if (!res.auxLock) chrome.storage.local.remove("statusTime");
      chrome.storage.local.remove("unidentified_" + PROFILE_ID);
      render();
    });
    });
  }, 5000);
};

// ===== DEV CONSOLE =====
const devLogs = document.getElementById("devLogs");

function refreshDevConsole() {
  chrome.storage.session.get(["devLog"], (res) => {
    const logs = res.devLog || [];
    if (!devLogs) return;
    const wasAtBottom = devLogs.scrollTop + devLogs.clientHeight >= devLogs.scrollHeight - 10;
    devLogs.innerHTML = "";
    for (const entry of logs) {
      const div = document.createElement("div");
      div.className = "log-entry";
      const time = document.createElement("span");
      time.className = "log-time";
      time.textContent = entry.time + " ";
      const msg = document.createElement("span");
      msg.className = "log-" + (entry.cat || "content");
      msg.textContent = entry.msg;
      div.append(time, msg);
      devLogs.appendChild(div);
    }
    if (wasAtBottom) devLogs.scrollTop = devLogs.scrollHeight;
  });
}

document.getElementById("devClear").onclick = () => {
  chrome.storage.session.remove("devLog");
  devLogs.innerHTML = "";
};

document.getElementById("devCopy").onclick = () => {
  chrome.storage.session.get(["devLog"], (res) => {
    const logs = res.devLog || [];
    const text = logs.map(e => e.time + " " + e.msg).join("\n");
    navigator.clipboard.writeText(text);
  });
};

chrome.storage.onChanged.addListener((changes) => {
  if (changes["stats_" + PROFILE_ID] || changes.statusTime || changes.statusTimeHistory || changes["unidentified_" + PROFILE_ID] || changes["customQueues_" + PROFILE_ID] || changes.saveHistory || changes["mpColors_" + PROFILE_ID] || changes.showRecentCases || changes["caseLog_" + PROFILE_ID]) render();
  if (changes.autoAccept || changes.autoClean || changes.missedCount) renderToggles();
  if (changes.liteMode) { document.body.classList.toggle("lite", !!changes.liteMode.newValue); applyLiteProps(); }
  if (changes.liteCustomBg || changes.liteCustomText || changes.liteCustomAccent || changes.liteCustomFontSize) applyLiteProps();
  if (changes.devMode) {
    devConsole.style.display = changes.devMode.newValue ? "" : "none";
    if (changes.devMode.newValue) refreshDevConsole();
  }
  if (changes.devLog) refreshDevConsole();
  if (changes.customBanner) {
    bannerEl.style.backgroundImage = changes.customBanner.newValue ? "url(" + changes.customBanner.newValue + ")" : "none";
  }
  if (changes.bannerColor) {
    if (!changes.customBanner) {
      bannerEl.style.backgroundImage = "none";
      bannerEl.style.backgroundColor = changes.bannerColor.newValue || "#006878";
    }
    setBannerTextColor(changes.bannerColor.newValue || null);
  }
  if (changes.bgColor1 || changes.bgColor2 || changes.bgImage) {
    chrome.storage.local.get(["bgColor1", "bgColor2", "bgImage"], (r) => {
      applyBackground(r.bgColor1, r.bgColor2, r.bgImage);
    });
  }
});

renderToggles();
render();

// Reconnect - re-inject content scripts into Paragon tabs
document.getElementById("reconnectBtn").onclick = () => {
  var detectorFiles = {
    safet: ["profiles/safet/config.js", "profiles/safet/detector.js"],
    ssr: ["profiles/ssr/config.js", "profiles/ssr/detector.js"],
    pat: ["profiles/pat/config.js", "profiles/pat/detector.js"]
  };
  var myDetector = detectorFiles[PROFILE_ID] || detectorFiles.safet;
  chrome.tabs.query({ url: ["https://paragon-eu.amazon.com/*", "https://paragon-na.amazon.com/*"] }, (tabs) => {
    let count = 0;
    for (const tab of tabs) {
      chrome.scripting.executeScript({
        target: { tabId: tab.id, allFrames: true },
        files: ["content.js", "attachments.js"]
      });
      chrome.scripting.executeScript({
        target: { tabId: tab.id, allFrames: true },
        files: myDetector
      });
      count++;
    }
    starAlert("🔄 Reconnected to " + count + " Paragon tab(s)");
  });
};

// Export data (current view or historical)
document.getElementById("exportBtn").onclick = () => {
  getQueues((qmap) => {
    chrome.storage.local.get(["stats_" + PROFILE_ID, "statsHistory_" + PROFILE_ID, "saveHistory", "statusTime", "statusTimeHistory", "unidentified_" + PROFILE_ID, "caseLog_" + PROFILE_ID], (res) => {
      const exportDate = viewingDate || new Date().toISOString().slice(0, 10);
      const isHistorical = !!viewingDate;
      var historyData = res["statsHistory_" + PROFILE_ID] || {};
      var statusTimeHist = res.statusTimeHistory || {};

      var stats;
      if (isHistorical) {
        stats = historyData[exportDate] || {};
      } else if (res.saveHistory && historyData[exportDate]) {
        stats = historyData[exportDate];
      } else {
        stats = res["stats_" + PROFILE_ID] || {};
      }

      var statusTime;
      if (isHistorical) {
        statusTime = statusTimeHist[exportDate] || {};
      } else if (res.saveHistory && statusTimeHist[exportDate]) {
        statusTime = statusTimeHist[exportDate];
      } else {
        statusTime = res.statusTime || {};
      }

      const allUnidentified = res["unidentified_" + PROFILE_ID] || [];
      const unidentified = allUnidentified.filter(u => u.date === exportDate);
      const caseLog = res["caseLog_" + PROFILE_ID] || {};
      const dayLog = caseLog[exportDate] || [];
      const fmtT = (s) => { const m = Math.floor(s/60); const sec = Math.round(s%60); return m + ":" + String(sec).padStart(2,"0"); };

      let csv = "STAR Tracker Export - " + exportDate + "\n\n";
      csv += "Marketplace,Queue,Label,Cases,Total Time,Avg Time,Target,On Target\n";

      let totalCases = 0, totalSec = 0;

      for (const [q, s] of Object.entries(stats)) {
        const info = qmap[q];
        if (!info || q === "unknown") continue;
        const avg = s.caseCount > 0 ? s.totalSeconds / s.caseCount : 0;
        const onTarget = s.caseCount === 0 || (avg/60) <= info.targetMin;
        csv += [info.mp, q, info.label || "", s.caseCount, fmtT(s.totalSeconds), fmtT(avg), fmtT(info.targetMin*60), onTarget ? "Yes" : "No"].join(",") + "\n";
        totalCases += s.caseCount;
        totalSec += s.totalSeconds;
      }

      csv += "\nTotal Cases," + totalCases + "\n";
      csv += "Overall Avg," + (totalCases > 0 ? fmtT(totalSec/totalCases) : "0:00") + "\n";

      if (dayLog.length > 0) {
        csv += "\nCase Log - " + exportDate + "\nTime,Case ID,Queue,Duration\n";
        for (const c of dayLog) csv += [c.time, c.caseId, c.queue, fmtT(c.seconds)].join(",") + "\n";
      }

      if (unidentified.length > 0) {
        csv += "\nUnidentified Cases\nQueue,Time,Timestamp\n";
        for (const u of unidentified) csv += [u.queue, fmtT(u.seconds), u.time].join(",") + "\n";
      }

      if (Object.keys(statusTime).length > 0) {
        csv += "\nAux Used - " + exportDate + "\nStatus,Time\n";
        for (const [s, t] of Object.entries(statusTime)) csv += s + "," + fmtT(t) + "\n";
      }

      const blob = new Blob([csv], { type: "text/csv" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "STAR-Export-" + exportDate + ".csv";
      a.click();
      URL.revokeObjectURL(url);
    });
  });
};

// Export Week-to-Date
document.getElementById("exportWeekBtn").onclick = () => {
  getQueues((qmap) => {
    chrome.storage.local.get(["statsHistory_" + PROFILE_ID, "statusTimeHistory", "unidentified_" + PROFILE_ID, "caseLog_" + PROFILE_ID], (res) => {
      var historyData = res["statsHistory_" + PROFILE_ID] || {};
      var statusTimeHist = res.statusTimeHistory || {};
      var allUnidentified = res["unidentified_" + PROFILE_ID] || [];
      var caseLog = res["caseLog_" + PROFILE_ID] || {};
      const fmtT = (s) => { const m = Math.floor(s/60); const sec = Math.round(s%60); return m + ":" + String(sec).padStart(2,"0"); };

      // Get Monday of current week
      var now = new Date();
      var dayOfWeek = now.getDay();
      var monday = new Date(now);
      monday.setDate(now.getDate() - (dayOfWeek === 0 ? 6 : dayOfWeek - 1));
      var todayStr = now.toISOString().slice(0, 10);

      // Collect days from Monday to today
      var days = [];
      var d = new Date(monday);
      while (d.toISOString().slice(0, 10) <= todayStr) {
        days.push(d.toISOString().slice(0, 10));
        d.setDate(d.getDate() + 1);
      }

      var weekLabel = days[0] + " to " + days[days.length - 1];
      let csv = "STAR Tracker Week-to-Date Export\n" + weekLabel + "\n\n";

      // Aggregate stats across the week
      var weekStats = {};
      for (var day of days) {
        var dayStats = historyData[day] || {};
        for (var q in dayStats) {
          if (!weekStats[q]) weekStats[q] = { totalSeconds: 0, caseCount: 0 };
          weekStats[q].totalSeconds += dayStats[q].totalSeconds;
          weekStats[q].caseCount += dayStats[q].caseCount;
        }
      }

      csv += "Marketplace,Queue,Label,Cases,Total Time,Avg Time,Target,On Target\n";
      let totalCases = 0, totalSec = 0;
      for (const [q, s] of Object.entries(weekStats)) {
        const info = qmap[q];
        if (!info || q === "unknown") continue;
        const avg = s.caseCount > 0 ? s.totalSeconds / s.caseCount : 0;
        const onTarget = s.caseCount === 0 || (avg/60) <= info.targetMin;
        csv += [info.mp, q, info.label || "", s.caseCount, fmtT(s.totalSeconds), fmtT(avg), fmtT(info.targetMin*60), onTarget ? "Yes" : "No"].join(",") + "\n";
        totalCases += s.caseCount;
        totalSec += s.totalSeconds;
      }
      csv += "\nTotal Cases," + totalCases + "\n";
      csv += "Overall Avg," + (totalCases > 0 ? fmtT(totalSec/totalCases) : "0:00") + "\n";

      // Daily breakdown
      csv += "\nDaily Breakdown\nDate,Cases,Avg Time\n";
      for (var day of days) {
        var dayStats = historyData[day] || {};
        var dc = 0, ds = 0;
        for (var q in dayStats) { if (qmap[q]) { dc += dayStats[q].caseCount; ds += dayStats[q].totalSeconds; } }
        csv += day + "," + dc + "," + (dc > 0 ? fmtT(ds/dc) : "0:00") + "\n";
      }

      // Aux breakdown per day
      var hasAux = days.some(day => statusTimeHist[day] && Object.keys(statusTimeHist[day]).length > 0);
      if (hasAux) {
        csv += "\nAux Breakdown\nDate,Status,Time\n";
        for (var day of days) {
          var dayAux = statusTimeHist[day] || {};
          for (var s in dayAux) csv += day + "," + s + "," + fmtT(dayAux[s]) + "\n";
        }
      }

      // Case logs per day
      var hasLogs = days.some(day => caseLog[day] && caseLog[day].length > 0);
      if (hasLogs) {
        csv += "\nCase Log\nDate,Time,Case ID,Queue,Duration\n";
        for (var day of days) {
          var dl = caseLog[day] || [];
          for (var c of dl) csv += day + "," + [c.time, c.caseId, c.queue, fmtT(c.seconds)].join(",") + "\n";
        }
      }

      const blob = new Blob([csv], { type: "text/csv" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "STAR-Week-" + weekLabel.replace(/ to /g, "-to-") + ".csv";
      a.click();
      URL.revokeObjectURL(url);
    });
  });
};

// Banner
const bannerEl = document.getElementById("banner");

function setBannerTextColor(color) {
  if (!color) return;
  var r = parseInt(color.slice(1,3), 16);
  var g = parseInt(color.slice(3,5), 16);
  var b = parseInt(color.slice(5,7), 16);
  var textColor = (r * 0.299 + g * 0.587 + b * 0.114) > 150 ? "#333" : "#fff";
  document.documentElement.style.setProperty("--accent-text", textColor);
}

chrome.storage.local.get(["customBanner", "bannerColor"], (res) => {
  if (res.customBanner) {
    bannerEl.style.backgroundImage = "url(" + res.customBanner + ")";
  }
  if (res.bannerColor && !res.customBanner) {
    bannerEl.style.backgroundColor = res.bannerColor;
  }
  setBannerTextColor(res.bannerColor || null);
});

function applyBackground(c1, c2, img) {
  if (img) {
    document.body.style.background = "url(" + img + ") center/cover fixed";
  } else {
    var color1 = c1 || "#1a1a2e";
    var color2 = c2 || "#533483";
    document.body.style.background = "linear-gradient(135deg, " + color1 + " 0%, " + color2 + " 100%)";
  }
  document.body.style.minHeight = "100vh";
}

chrome.storage.local.get(["bgColor1", "bgColor2", "bgImage"], (res) => {
  if (res.bgColor1 || res.bgColor2 || res.bgImage) {
    applyBackground(res.bgColor1, res.bgColor2, res.bgImage);
  }
});

// Settings
document.getElementById("settingsBtn").onclick = () => {
  window.location.href = "settings.html";
};

