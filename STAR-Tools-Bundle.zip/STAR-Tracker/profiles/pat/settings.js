function starAlert(msg) { var o = document.createElement("div"); o.className = "star-modal-overlay"; o.innerHTML = '<div class="star-modal"><div class="star-modal-msg"></div><button class="star-modal-ok">OK</button></div>'; o.querySelector(".star-modal-msg").textContent = msg; o.querySelector(".star-modal-ok").onclick = function() { o.remove(); }; document.body.appendChild(o); }
function starConfirm(msg, cb) { var o = document.createElement("div"); o.className = "star-modal-overlay"; o.innerHTML = '<div class="star-modal"><div class="star-modal-msg"></div><div style="display:flex;gap:8px;justify-content:center"><button class="star-modal-ok">OK</button><button class="star-modal-ok" style="opacity:0.6">Cancel</button></div></div>'; o.querySelector(".star-modal-msg").textContent = msg; var btns = o.querySelectorAll("button"); btns[0].onclick = function() { o.remove(); cb(true); }; btns[1].onclick = function() { o.remove(); cb(false); }; document.body.appendChild(o); }
document.getElementById("backBtn").onclick = function() { window.location.href = "popup.html"; };
const FLAGS = { US: "🇺🇸", UK: "🇬🇧", CA: "🇨🇦", DE: "🇩🇪", FR: "🇫🇷", ES: "🇪🇸", IT: "🇮🇹", IN: "🇮🇳", JP: "🇯🇵", BR: "🇧🇷", MX: "🇲🇽", AU: "🇦🇺", AE: "🇦🇪", SA: "🇸🇦", EG: "🇪🇬", SG: "🇸🇬", PL: "🇵🇱", NL: "🇳🇱", SE: "🇸🇪", TR: "🇹🇷", BE: "🇧🇪", IE: "🇮🇪", ZA: "🇿🇦" };

// Collapsible sections
document.querySelectorAll(".section-toggle").forEach(h2 => {
  h2.onclick = () => {
    const section = h2.closest(".section");
    section.classList.toggle("collapsed");
    h2.textContent = h2.textContent.replace(/^[▶▼]/, section.classList.contains("collapsed") ? "▶" : "▼");
  };
});

// history toggle (instant ~ no es parte de Save All)
const historyChk = document.getElementById("saveHistoryChk");
chrome.storage.local.get(["saveHistory"], (res) => { historyChk.checked = res.saveHistory || false; });
historyChk.onchange = () => { chrome.storage.local.set({ saveHistory: historyChk.checked }); };

// recent cases toggle (instant)
var recentChk = document.getElementById("showRecentChk");
chrome.storage.local.get(["showRecentCases"], function(r) { recentChk.checked = r.showRecentCases || false; });
recentChk.onchange = function() { chrome.storage.local.set({ showRecentCases: recentChk.checked }); };

// lite mode toggle (instant ~ no es parte de Save All)
var liteModeChk = document.getElementById("liteModeChk");
chrome.storage.local.get(["liteMode"], function(r) { liteModeChk.checked = !!r.liteMode; if (r.liteMode) document.body.classList.add("lite"); toggleLiteAppearance(!!r.liteMode); });
liteModeChk.onchange = function() { chrome.storage.local.set({ liteMode: liteModeChk.checked }); document.body.classList.toggle("lite", liteModeChk.checked); toggleLiteAppearance(liteModeChk.checked); };

// lite appearance subsection ~ solo visible cuando lite mode esta on
var litePanel = document.getElementById("liteAppearance");
var liteBgInput = document.getElementById("liteBgColor");
var liteTextInput = document.getElementById("liteTextColor");
var liteAccentInput = document.getElementById("liteAccentColor");
var liteFontSelect = document.getElementById("liteFontSize");

function toggleLiteAppearance(on) { litePanel.style.display = on ? "" : "none"; }

// cargar valores guardados
chrome.storage.local.get(["liteCustomBg", "liteCustomText", "liteCustomAccent", "liteCustomFontSize"], function(r) {
  if (r.liteCustomBg) liteBgInput.value = r.liteCustomBg;
  if (r.liteCustomText) liteTextInput.value = r.liteCustomText;
  if (r.liteCustomAccent) liteAccentInput.value = r.liteCustomAccent;
  if (r.liteCustomFontSize) liteFontSelect.value = r.liteCustomFontSize;
});

// guardar al cambiar ~ instant, no parte de Save All
liteBgInput.onchange = function() { chrome.storage.local.set({ liteCustomBg: liteBgInput.value }); };
liteTextInput.onchange = function() { chrome.storage.local.set({ liteCustomText: liteTextInput.value }); };
liteAccentInput.onchange = function() { chrome.storage.local.set({ liteCustomAccent: liteAccentInput.value }); };
liteFontSelect.onchange = function() { chrome.storage.local.set({ liteCustomFontSize: liteFontSelect.value }); };

// ===== PENDING STATE (saved on Save All, reverted on close) =====
let pendingBanner = { color: null, image: null };
let pendingBg = { color1: null, color2: null, image: null };
let pendingMpColors = null; // null = not changed
let pendingChanges = false;

function markChanged() {
  pendingChanges = true;
  document.getElementById("saveStatus").textContent = "⚠️ Unsaved changes";
}

// Load originals
let originalBanner = {};
let originalBg = {};
let originalMpColors = {};

chrome.storage.local.get(["customBanner", "bannerColor", "bgColor1", "bgColor2", "bgImage", "mpColors_pat"], (res) => {
  originalBanner = { color: res.bannerColor || null, image: res.customBanner || null };
  originalBg = { color1: res.bgColor1 || "#1a1a2e", color2: res.bgColor2 || "#533483", image: res.bgImage || null };
  originalMpColors = res.mpColors_pat || {};

  if (originalBanner.color) document.getElementById("bannerColor").value = originalBanner.color;
  document.getElementById("bgColor1").value = originalBg.color1;
  document.getElementById("bgColor2").value = originalBg.color2;
  document.body.style.background = "linear-gradient(135deg, " + originalBg.color1 + " 0%, " + originalBg.color2 + " 100%)";

  if (originalBanner.image) {
    document.getElementById("banner").style.backgroundImage = "url(" + originalBanner.image + ")";
    document.getElementById("clearBannerImg").style.display = "";
  } else if (originalBanner.color) {
    document.getElementById("banner").style.backgroundColor = originalBanner.color;
  }
  if (originalBg.image) {
    document.getElementById("clearBgImg").style.display = "";
  }
});

// preview en vivo ~ que el fondo cambie cuando mueves los color pickers
function previewBg() {
  var c1 = document.getElementById("bgColor1").value;
  var c2 = document.getElementById("bgColor2").value;
  document.body.style.background = "linear-gradient(135deg, " + c1 + " 0%, " + c2 + " 100%)";
}

// Track changes on inputs
document.getElementById("bannerColor").onchange = () => { pendingBanner.color = document.getElementById("bannerColor").value; markChanged(); };
document.getElementById("bgColor1").onchange = () => { pendingBg.color1 = document.getElementById("bgColor1").value; markChanged(); previewBg(); };
document.getElementById("bgColor2").onchange = () => { pendingBg.color2 = document.getElementById("bgColor2").value; markChanged(); previewBg(); };
document.getElementById("bgColor1").oninput = previewBg;
document.getElementById("bgColor2").oninput = previewBg;

document.getElementById("bannerFile").onchange = (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (ev) => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement("canvas");
      canvas.width = Math.min(img.width, 400);
      canvas.height = Math.round(canvas.width * img.height / img.width);
      canvas.getContext("2d").drawImage(img, 0, 0, canvas.width, canvas.height);
      pendingBanner.image = canvas.toDataURL("image/jpeg", 0.7);
      document.getElementById("clearBannerImg").style.display = "";
      markChanged();
    };
    img.src = ev.target.result;
  };
  reader.readAsDataURL(file);
};

document.getElementById("clearBannerImg").onclick = () => {
  pendingBanner.image = "__remove__";
  document.getElementById("bannerFile").value = "";
  document.getElementById("clearBannerImg").style.display = "none";
  markChanged();
};

document.getElementById("bgFile").onchange = (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (ev) => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement("canvas");
      canvas.width = Math.min(img.width, 600);
      canvas.height = Math.round(canvas.width * img.height / img.width);
      canvas.getContext("2d").drawImage(img, 0, 0, canvas.width, canvas.height);
      pendingBg.image = canvas.toDataURL("image/jpeg", 0.6);
      document.getElementById("clearBgImg").style.display = "";
      markChanged();
    };
    img.src = ev.target.result;
  };
  reader.readAsDataURL(file);
};

document.getElementById("clearBgImg").onclick = () => {
  pendingBg.image = "__remove__";
  document.getElementById("bgFile").value = "";
  document.getElementById("clearBgImg").style.display = "none";
  markChanged();
};

// Revert on close without saving

// ⁘[ BACKUP / RESTORE STATS ]⁘
// exportar todo el historial como csv pa respaldo
document.getElementById("exportStatsBtn").onclick = function() {
  var keys = ["statsHistory_" + "pat", "caseLog_" + "pat", "statusTimeHistory"];
  chrome.storage.local.get(keys, function(res) {
    var hist = res["statsHistory_" + "pat"] || {};
    var caseLog = res["caseLog_" + "pat"] || {};
    var csv = "STAR Tracker Stats Backup - " + "pat" + "\nExported: " + new Date().toISOString() + "\n\n";
    csv += "=== DAILY STATS ===\nDate,Queue,Cases,Total Seconds\n";
    for (var day in hist) {
      for (var q in hist[day]) {
        csv += day + "," + q + "," + hist[day][q].caseCount + "," + hist[day][q].totalSeconds + "\n";
      }
    }
    csv += "\n=== CASE LOG ===\nDate,Time,Case ID,Queue,Seconds\n";
    for (var day in caseLog) {
      (caseLog[day] || []).forEach(function(c) {
        csv += day + "," + c.time + "," + c.caseId + "," + c.queue + "," + c.seconds + "\n";
      });
    }
    var stHist = res.statusTimeHistory || {};
    csv += "\n=== AUX TIME ===\nDate,Status,Seconds\n";
    for (var day in stHist) {
      for (var s in stHist[day]) {
        csv += day + "," + s + "," + stHist[day][s] + "\n";
      }
    }
    var a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    a.download = "STAR-Stats-" + "pat" + "-" + new Date().toISOString().slice(0,10) + ".csv";
    a.click();
  });
};

// importar csv de respaldo ~ acepta formato backup (=== DAILY STATS ===) y popup (STAR Tracker Export)
document.getElementById("importStatsBtn").onclick = function() {
  var file = document.getElementById("statsFile").files[0];
  var status = document.getElementById("statsImportStatus");
  if (!file) { status.textContent = "⚠️ Select a file first"; status.style.color = "#fbbf24"; return; }
  var reader = new FileReader();
  reader.onload = function(e) {
    var text = e.target.result;
    var lines = text.split("\n");
    var hist = {};
    var caseLog = {};
    var auxTime = {};

    // parsear m:ss o h:mm:ss a segundos ~ si no tiene : devuelve el numero directo
    var toSec = function(v) {
      if (!v) return 0;
      var p = v.split(":");
      if (p.length === 3) return parseInt(p[0])*3600 + parseInt(p[1])*60 + parseInt(p[2]);
      if (p.length === 2) return parseInt(p[0])*60 + parseInt(p[1]);
      return parseInt(v) || 0;
    };

    // detectar formato por contenido
    var isBackup = text.indexOf("=== DAILY STATS ===") !== -1;
    var popupDateMatch = lines[0] && lines[0].match(/STAR Tracker Export - (\d{4}-\d{2}-\d{2})/);

    if (isBackup) {
      // ⁘[ FORMATO BACKUP ]⁘
      var section = "";
      for (var i = 0; i < lines.length; i++) {
        var line = lines[i].trim();
        if (line === "=== DAILY STATS ===") { section = "stats"; continue; }
        if (line === "=== CASE LOG ===") { section = "log"; continue; }
        if (line === "=== AUX TIME ===") { section = "aux"; continue; }
        if (!line || line.startsWith("STAR") || line.startsWith("Exported") || line.startsWith("Date,")) continue;
        var parts = line.split(",");
        if (section === "stats" && parts.length >= 4) {
          var day = parts[0], q = parts[1], cases = parseInt(parts[2]), secs = parseInt(parts[3]);
          if (!day.match(/^\d{4}-/)) continue;
          if (!hist[day]) hist[day] = {};
          if (!hist[day][q]) hist[day][q] = { totalSeconds: 0, caseCount: 0 };
          hist[day][q].totalSeconds += secs;
          hist[day][q].caseCount += cases;
        }
        if (section === "log" && parts.length >= 5) {
          var day = parts[0];
          if (!caseLog[day]) caseLog[day] = [];
          caseLog[day].push({ time: parts[1], caseId: parts[2], queue: parts[3], seconds: parseInt(parts[4]) });
        }
        if (section === "aux" && parts.length >= 3) {
          var day = parts[0], st = parts[1], secs = parseInt(parts[2]);
          if (!day.match(/^\d{4}-/)) continue;
          if (!auxTime[day]) auxTime[day] = {};
          auxTime[day][st] = (auxTime[day][st] || 0) + secs;
        }
      }
    } else if (popupDateMatch) {
      // ⁘[ FORMATO POPUP EXPORT ]⁘
      var day = popupDateMatch[1];
      var section = "";
      for (var i = 0; i < lines.length; i++) {
        var line = lines[i].trim();
        if (line.startsWith("Marketplace,Queue,")) { section = "stats"; continue; }
        if (line.startsWith("Time,Case ID,")) { section = "log"; continue; }
        if (line.startsWith("Aux Used")) { section = "aux"; continue; }
        if (!line || line.startsWith("STAR") || line.startsWith("Total Cases") || line.startsWith("Overall Avg")) continue;
        if (line.startsWith("Unidentified") || line.startsWith("Queue,Time,Timestamp")) { section = ""; continue; }
        if (line === "Status,Time") continue;
        var parts = line.split(",");
        if (section === "stats" && parts.length >= 5) {
          var q = parts[1], cases = parseInt(parts[3]), totalTime = parts[4];
          if (!cases || isNaN(cases)) continue;
          if (!hist[day]) hist[day] = {};
          if (!hist[day][q]) hist[day][q] = { totalSeconds: 0, caseCount: 0 };
          hist[day][q].totalSeconds += toSec(totalTime);
          hist[day][q].caseCount += cases;
        }
        if (section === "log" && parts.length >= 4) {
          if (!caseLog[day]) caseLog[day] = [];
          caseLog[day].push({ time: parts[0], caseId: parts[1], queue: parts[2], seconds: toSec(parts[3]) });
        }
        if (section === "aux" && parts.length >= 2) {
          if (!auxTime[day]) auxTime[day] = {};
          auxTime[day][parts[0]] = toSec(parts[1]);
        }
      }
    }

    // validar que se parseo algo
    var days = Object.keys(hist).length;
    var totalCases = Object.values(hist).reduce(function(s, d) { return s + Object.values(d).reduce(function(s2, q) { return s2 + q.caseCount; }, 0); }, 0);
    var auxDays = Object.keys(auxTime).length;
    if (days === 0 && auxDays === 0) {
      status.textContent = "❌ No data found — unrecognized CSV format";
      status.style.color = "#f87171";
      return;
    }

    // merge con datos existentes ~ no sobreescribir
    var keys = ["statsHistory_" + "pat", "caseLog_" + "pat", "statusTimeHistory"];
    chrome.storage.local.get(keys, function(res) {
      var existing = res["statsHistory_" + "pat"] || {};
      var existingLog = res["caseLog_" + "pat"] || {};
      var existingAux = res.statusTimeHistory || {};

      for (var day in hist) {
        if (!existing[day]) { existing[day] = hist[day]; continue; }
        for (var q in hist[day]) {
          if (!existing[day][q]) { existing[day][q] = hist[day][q]; continue; }
          if (hist[day][q].caseCount > existing[day][q].caseCount) existing[day][q] = hist[day][q];
        }
      }
      for (var day in caseLog) {
        if (!existingLog[day] || existingLog[day].length === 0) existingLog[day] = caseLog[day];
      }
      for (var day in auxTime) {
        if (!existingAux[day]) { existingAux[day] = auxTime[day]; continue; }
        for (var s in auxTime[day]) {
          // mantener el mayor
          if (!existingAux[day][s] || auxTime[day][s] > existingAux[day][s]) existingAux[day][s] = auxTime[day][s];
        }
      }

      var toSave = {};
      toSave["statsHistory_" + "pat"] = existing;
      toSave["caseLog_" + "pat"] = existingLog;
      toSave.statusTimeHistory = existingAux;
      // si los datos importados incluyen hoy, tambien escribir al acumulador live
      var today = new Date().toISOString().slice(0, 10);
      if (existingAux[today]) toSave.statusTime = existingAux[today];
      // si los stats importados incluyen hoy, escribir al acumulador live tambien
      if (existing[today]) toSave["stats_" + "pat"] = existing[today];
      chrome.storage.local.set(toSave, function() {
        var msg = "✅ Imported: " + days + " days, " + totalCases + " cases";
        if (auxDays > 0) msg += ", " + auxDays + "d aux time";
        msg += " (merged)";
        status.textContent = msg;
        status.style.color = "#4ade80";
      });
    });
  };
  reader.readAsText(file);
};


// Dev Mode toggle
const devBtn = document.getElementById("devModeBtn");
chrome.storage.local.get(["devMode"], (res) => {
  if (res.devMode) devBtn.classList.add("active");
});
devBtn.onclick = () => {
  chrome.storage.local.get(["devMode"], (res) => {
    const on = !res.devMode;
    chrome.storage.local.set({ devMode: on });
    devBtn.classList.toggle("active", on);
  });
};

// Credits
document.getElementById("creditsBtn").onclick = () => {
  starAlert("STAR Tracker\n\nCreated by:\nSean Vargas Romero (@varseana)\n\nSpecial thanks to:\nMarco (@marcovma), Jay (@jasaguer), German (@germanwr),\nSteven (@astarte), David (@davivene), Javier (@gomjavia),\nAlex (@alexcamo), Sharon (@arguesha)\nand our L5: Stefan (@badras)\nfor giving feedback and ideas on the development.\n\nBuilt with ❤️ for the SEPO team");
};

// ===== QUEUE MANAGEMENT =====
let workingQueues = {};

function loadQueues(cb) {
  chrome.storage.local.get(["customQueues_pat"], (res) => {
    const custom = res.customQueues_pat || {};
    const merged = {};
    for (const [k, v] of Object.entries(QUEUE_MAP_PAT)) {
      if (custom[k] === null) continue;
      merged[k] = custom[k] || v;
    }
    for (const [k, v] of Object.entries(custom)) {
      if (v && !QUEUE_MAP_PAT[k]) merged[k] = v;
    }
    cb(merged);
  });
}

function saveAll() {
  const toSave = {};

  // Queues
  const custom = {};
  for (const [email, info] of Object.entries(workingQueues)) {
    custom[email] = info;
  }
  for (const email of Object.keys(QUEUE_MAP_PAT)) {
    if (!workingQueues[email]) custom[email] = null;
  }
  toSave.customQueues_pat = custom;

  // Banner
  if (pendingBanner.color !== null) toSave.bannerColor = pendingBanner.color;
  if (pendingBanner.image === "__remove__") {
    chrome.storage.local.remove("customBanner");
  } else if (pendingBanner.image !== null) {
    toSave.customBanner = pendingBanner.image;
  } else if (pendingBanner.color !== null) {
    chrome.storage.local.remove("customBanner");
  }

  // Background
  if (pendingBg.color1 !== null) toSave.bgColor1 = pendingBg.color1;
  if (pendingBg.color2 !== null) toSave.bgColor2 = pendingBg.color2;
  if (pendingBg.image === "__remove__") {
    chrome.storage.local.remove("bgImage");
  } else if (pendingBg.image !== null) {
    toSave.bgImage = pendingBg.image;
  }

  // MP Colors
  if (pendingMpColors !== null) toSave.mpColors_pat = pendingMpColors;

  chrome.storage.local.set(toSave, () => {
    pendingChanges = false;
    pendingBanner = { color: null, image: null };
    pendingBg = { color1: null, color2: null, image: null };
    pendingMpColors = null;
    document.getElementById("saveStatus").textContent = "✅ Saved!";
    setTimeout(() => document.getElementById("saveStatus").textContent = "", 2000);
  });
}

function renderList() {
  const list = document.getElementById("queueList");
  list.innerHTML = "";

  const sorted = Object.entries(workingQueues).sort((a, b) => {
    const mpCmp = a[1].mp.localeCompare(b[1].mp);
    return mpCmp !== 0 ? mpCmp : (a[1].label || a[0]).localeCompare(b[1].label || b[0]);
  });

  const countEl = document.getElementById("queueCount");
  if (countEl) countEl.textContent = sorted.length;

  for (const [email, info] of sorted) {
    const row = document.createElement("div");
    row.className = "q-row";

    const mp = document.createElement("span");
    mp.className = "q-mp";
    mp.textContent = info.mp;

    const label = document.createElement("span");
    label.className = "q-label";
    label.textContent = (info.flag || "") + " " + (info.label || "");

    const emailSpan = document.createElement("span");
    emailSpan.className = "q-email";
    emailSpan.textContent = email;
    emailSpan.title = email;

    const target = document.createElement("input");
    target.className = "q-target";
    target.type = "number";
    target.step = "0.01";
    target.value = info.targetMin;
    target.onchange = () => {
      const val = parseFloat(target.value);
      if (!isNaN(val) && val > 0) {
        workingQueues[email].targetMin = val;
        markChanged();
      }
    };

    const del = document.createElement("button");
    del.className = "q-del";
    del.textContent = "✖";
    del.title = "Delete " + email;
    del.onclick = () => {
      starConfirm("Delete " + (info.label || email) + "?", function(ok) { if (!ok) return;
      delete workingQueues[email];
      markChanged();
      renderList(); });
    };

    row.append(mp, label, emailSpan, target, del);
    list.appendChild(row);
  }
}

document.getElementById("addBtn").onclick = () => {
  const mp = document.getElementById("addMp").value;
  const queue = document.getElementById("addQueue").value.trim().toLowerCase();
  const label = document.getElementById("addLabel").value.trim();
  const target = parseFloat(document.getElementById("addTarget").value);

  if (!queue || !queue.includes("@") || !label || isNaN(target) || target <= 0) {
    starAlert("Fill all fields correctly");
    return;
  }

  workingQueues[queue] = { mp, targetMin: target, flag: FLAGS[mp] || "", label };
  document.getElementById("addQueue").value = "";
  document.getElementById("addLabel").value = "";
  document.getElementById("addTarget").value = "";
  markChanged();
  renderList();
};

document.getElementById("importBtn").onclick = () => {
  const file = document.getElementById("csvFile").files[0];
  if (!file) { starAlert("Select a CSV file"); return; }

  const reader = new FileReader();
  reader.onload = (e) => {
    const lines = e.target.result.split("\n").map(l => l.trim()).filter(Boolean);
    const status = document.getElementById("importStatus");
    let count = 0;
    workingQueues = {};

    for (const line of lines) {
      const parts = line.split(",").map(s => s.trim());
      if (parts.length < 4) continue;
      const [mp, queue, label, targetStr] = parts;
      const target = parseFloat(targetStr);
      if (!queue || !queue.includes("@") || isNaN(target)) continue;
      if (["MP", "mp", "Marketplace"].includes(mp)) continue;

      workingQueues[queue.toLowerCase()] = {
        mp: mp.toUpperCase(),
        targetMin: target,
        flag: FLAGS[mp.toUpperCase()] || "",
        label: label || queue.split("@")[0]
      };
      count++;
    }

    status.textContent = "📥 Imported " + count + " queues (click Save All to apply)";
    status.style.color = "#2ecc40";
    markChanged();
    renderList();
  };
  reader.readAsText(file);
};

document.getElementById("exportBtn").onclick = () => {
  let csv = "MP,Queue,Label,Target\n";
  for (const [email, info] of Object.entries(workingQueues)) {
    csv += [info.mp, email, info.label || "", info.targetMin].join(",") + "\n";
  }
  const blob = new Blob([csv], { type: "text/csv" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "star-queues.csv";
  a.click();
  URL.revokeObjectURL(url);
};

document.getElementById("saveAllBtn").onclick = saveAll;

// ===== MARKETPLACE COLORS =====
const MP_ORDER = ["US", "UK", "CA", "DE", "FR", "ES", "IT", "IN", "JP", "BR", "MX", "AU", "AE", "SA", "EG", "SG", "PL", "NL", "SE", "TR", "BE", "IE", "ZA"];

function renderMpColors() {
  const container = document.getElementById("mpColorList");
  container.innerHTML = "";
  const colors = pendingMpColors || originalMpColors;
  const mps = new Set(MP_ORDER);
  for (const q of Object.values(workingQueues)) { mps.add(q.mp); }

  for (const mp of mps) {
    const color = colors[mp] || "#006878";
    const row = document.createElement("div");
    row.className = "mp-color-row";

    const label = document.createElement("span");
    label.className = "mp-color-label";
    label.textContent = (FLAGS[mp] || "") + " " + mp;

    const picker = document.createElement("input");
    picker.type = "color";
    picker.value = color;
    picker.onchange = () => {
      if (!pendingMpColors) pendingMpColors = Object.assign({}, originalMpColors);
      pendingMpColors[mp] = picker.value;
      markChanged();
    };

    row.append(label, picker);
    container.appendChild(row);
  }
}

loadQueues((merged) => {
  workingQueues = merged;
  renderList();
  renderMpColors();
});


// ⁘[ KEYWORD ALERTS ]⁘
var kwList = [];
function renderKeywords() {
  var container = document.getElementById("keywordList");
  container.innerHTML = "";
  if (!kwList.length) { container.innerHTML = '<div class="kw-empty">no keywords ~ add one above</div>'; return; }
  kwList.forEach(function(kw, i) {
    var row = document.createElement("div"); row.className = "kw-row";
    var toggle = document.createElement("label"); toggle.className = "toggle-switch"; toggle.style.cssText = "transform:scale(0.8);";
    toggle.innerHTML = '<input type="checkbox"' + (kw.enabled ? " checked" : "") + '><span class="toggle-slider"></span>';
    toggle.querySelector("input").onchange = function() { kwList[i].enabled = this.checked; chrome.storage.local.set({ starKeywords: kwList }); };
    var text = document.createElement("span"); text.className = "kw-text"; text.textContent = kw.text;
    var del = document.createElement("button"); del.className = "kw-del"; del.textContent = "✕";
    del.onclick = function() { kwList.splice(i, 1); chrome.storage.local.set({ starKeywords: kwList }); renderKeywords(); };
    row.append(toggle, text, del); container.appendChild(row);
  });
}
chrome.storage.local.get(["starKeywords"], function(res) { kwList = res.starKeywords || []; renderKeywords(); });
document.getElementById("addKeywordBtn").onclick = function() {
  var input = document.getElementById("addKeyword"); var val = input.value.trim();
  if (!val) return;
  if (kwList.some(function(k) { return k.text.toLowerCase() === val.toLowerCase(); })) { starAlert("Keyword already exists"); return; }
  kwList.push({ text: val, enabled: true }); chrome.storage.local.set({ starKeywords: kwList }); input.value = ""; renderKeywords();
};
document.getElementById("addKeyword").onkeydown = function(e) { if (e.key === "Enter") document.getElementById("addKeywordBtn").click(); };
