// ⁘[ DETECTOR PAT ]⁘
// detecta queues de product authenticity en el iframe ctps
// usa nombres unicos pa no chocar con safet/ssr

if (!window._starQueueDetectorPAT) {
window._starQueueDetectorPAT = true;

var lastQueuePAT = null;
var lastTaskIdPAT = null;

function safeSendPAT(msg) {
  try { chrome.runtime.sendMessage(msg); } catch(e) {}
}

function detectQueuePAT() {
  var text = document.body ? document.body.innerText : "";
  var match = text.match(/Queue:\s*(\S+@amazon\S+)/i);
  return match ? match[1].toLowerCase().trim() : null;
}

function detectTaskIdPAT() {
  var text = document.body ? document.body.innerText : "";
  var match = text.match(/Task\s*ID:\s*(\d+)/i);
  return match ? match[1] : null;
}

setInterval(function() {
  var queue = detectQueuePAT();
  var taskId = detectTaskIdPAT();

  if (queue && (queue !== lastQueuePAT || taskId !== lastTaskIdPAT)) {
    if (typeof QUEUE_MAP_PAT !== "undefined" && QUEUE_MAP_PAT[queue]) {
      lastQueuePAT = queue;
      lastTaskIdPAT = taskId;
      safeSendPAT({ type: "QUEUE_DETECTED", queue: queue, taskId: taskId, profileId: "pat" });
      console.log("[STAR pat] Queue detected:", queue, "Task:", taskId);
    }
  }
}, 2000);

}
