if (!window._starQueueDetectorLoaded) {
window._starQueueDetectorLoaded = true;

function safeSend(msg) {
  try { chrome.runtime.sendMessage(msg); } catch(e) {}
}

function detectQueue() {
  var text = document.body ? document.body.innerText : "";
  var match = text.match(/Queue:\s*(\S+@amazon\S+)/i);
  return match ? match[1].toLowerCase() : null;
}

function detectTaskId() {
  var text = document.body ? document.body.innerText : "";
  var match = text.match(/Task ID:\s*(\d+)/i);
  return match ? match[1] : null;
}

var lastQueue = null;
var lastTaskId = null;

setInterval(function() {
  var queue = detectQueue();
  var taskId = detectTaskId();

  if (queue && (queue !== lastQueue || taskId !== lastTaskId)) {
    if (typeof QUEUE_MAP_SAFET !== "undefined" && QUEUE_MAP_SAFET[queue]) {
      lastQueue = queue;
      lastTaskId = taskId;
      safeSend({ type: "QUEUE_DETECTED", queue: queue, taskId: taskId, profileId: "safet" });
      console.log("[STAR safet] Queue detected:", queue, "Task:", taskId);
    }
  }
}, 1000);

// ⁘[ AUTO-OPEN PEEKNOW ]⁘
var _aotPeekTaskId = null;
chrome.runtime.onMessage.addListener(function(msg) {
  if (msg.type === "AUTO_OPEN_TOOLS" && msg.tools && msg.taskId && msg.taskId !== _aotPeekTaskId) {
    if (msg.tools.indexOf("peeknow") !== -1) {
      _aotPeekTaskId = msg.taskId;
      var attempts = 0;
      (function tryPeek() {
        var widget = document.querySelector("peek-now-widget");
        if (!widget) { if (++attempts < 8) setTimeout(tryPeek, 2000); return; }
        var lockIcon = widget.querySelector('kat-icon[name="lock_outline"]');
        if (lockIcon) { console.log("[STAR AOT] PeekNow locked, skipping"); return; }
        var katBtn = widget.querySelector("kat-button");
        if (!katBtn) { if (++attempts < 8) setTimeout(tryPeek, 2000); return; }
        var btn = katBtn.shadowRoot ? katBtn.shadowRoot.querySelector("button") : katBtn.querySelector("button");
        if (btn) { btn.click(); console.log("[STAR AOT] PeekNow clicked"); }
      })();
    }
  }
});

}
