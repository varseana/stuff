if (!window._starQueueDetectorLoaded) {
window._starQueueDetectorLoaded = true;

function safeSend(msg) {
  try { chrome.runtime.sendMessage(msg); } catch(e) {}
}

function detectQueue() {
  var text = document.body ? document.body.innerText : "";
  var match = text.match(/Queue:\s*(\S+@amazon\S+)/i);
  return match ? match[1].toLowerCase() : null;
}

function detectTaskId() {
  var text = document.body ? document.body.innerText : "";
  var match = text.match(/Task ID:\s*(\d+)/i);
  return match ? match[1] : null;
}

var lastQueue = null;
var lastTaskId = null;

setInterval(function() {
  var queue = detectQueue();
  var taskId = detectTaskId();

  if (queue && (queue !== lastQueue || taskId !== lastTaskId)) {
    if (typeof QUEUE_MAP_SAFET !== "undefined" && QUEUE_MAP_SAFET[queue]) {
      lastQueue = queue;
      lastTaskId = taskId;
      safeSend({ type: "QUEUE_DETECTED", queue: queue, taskId: taskId, profileId: "safet" });
      console.log("[STAR safet] Queue detected:", queue, "Task:", taskId);
    }
  }
}, 1000);

// ⁘[ AUTO-OPEN PEEKNOW + TOOLS ]⁘
// peeknow vive en este iframe (ctps), grass/oblt/spot pueden estar aqui o en paragon frames
// attachments.js los busca en paragon frames, este detector los busca aqui por si estan en ctps
var _aotPeekTaskId = null;
var _aotToolLabels = { grass: "Grass", oblt: "OBLT", spot: "SPOT" };

function _aotScanForLink(label) {
  var bolds = document.querySelectorAll("b");
  for (var i = 0; i < bolds.length; i++) {
    if (bolds[i].textContent.trim() === label) {
      var node = bolds[i].nextSibling;
      while (node) {
        if (node.nodeType === 1 && node.tagName === "A") return node;
        if (node.nodeType === 1 && node.querySelector && node.querySelector("a")) return node.querySelector("a");
        node = node.nextSibling;
      }
      var parent = bolds[i].parentElement;
      if (parent) { var a = parent.querySelector("a"); if (a) return a; }
    }
  }
  return null;
}

chrome.runtime.onMessage.addListener(function(msg) {
  if (msg.type === "AUTO_OPEN_TOOLS" && msg.tools && msg.taskId && msg.taskId !== _aotPeekTaskId) {
    _aotPeekTaskId = msg.taskId;

    // peeknow ~ boton en shadow dom del widget
    if (msg.tools.indexOf("peeknow") !== -1) {
      var attempts = 0;
      (function tryPeek() {
        var widget = document.querySelector("peek-now-widget");
        if (!widget) { if (++attempts < 8) setTimeout(tryPeek, 2000); return; }
        var lockIcon = widget.querySelector('kat-icon[name="lock_outline"]');
        if (lockIcon) { console.log("[STAR AOT] PeekNow locked, skipping"); return; }
        var katBtn = widget.querySelector("kat-button");
        if (!katBtn) { if (++attempts < 8) setTimeout(tryPeek, 2000); return; }
        var btn = katBtn.shadowRoot ? katBtn.shadowRoot.querySelector("button") : katBtn.querySelector("button");
        if (btn) { btn.click(); console.log("[STAR AOT] PeekNow clicked"); }
      })();
    }

    // grass/oblt/spot ~ buscar links <b>LABEL</b> + <a> en este frame
    var otherTools = msg.tools.filter(function(t) { return t in _aotToolLabels; });
    if (otherTools.length) {
      var toolAttempts = 0;
      var toolOpened = {};
      (function tryTools() {
        var remaining = [];
        otherTools.forEach(function(toolId, idx) {
          if (toolOpened[toolId]) return;
          var link = _aotScanForLink(_aotToolLabels[toolId]);
          if (link) {
            toolOpened[toolId] = true;
            setTimeout(function() {
              link.click();
              console.log("[STAR AOT detector] Opened:", toolId);
            }, idx * 500);
          } else {
            remaining.push(toolId);
          }
        });
        otherTools = remaining;
        toolAttempts++;
        if (otherTools.length && toolAttempts < 10) setTimeout(tryTools, 2000);
      })();
    }
  }
});

}
