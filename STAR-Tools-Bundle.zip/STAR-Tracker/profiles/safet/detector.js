if (!window._starQueueDetectorLoaded) {
window._starQueueDetectorLoaded = true;

function safeSend(msg) {
  try { chrome.runtime.sendMessage(msg); } catch(e) {}
}

function detectQueue() {
  var text = document.body ? document.body.innerText : "";
  var match = text.match(/Queue:\s*(\S+@amazon\S+)/i);
  return match ? match[1].toLowerCase() : null;
}

function detectTaskId() {
  var text = document.body ? document.body.innerText : "";
  var match = text.match(/Task ID:\s*(\d+)/i);
  return match ? match[1] : null;
}

var lastQueue = null;
var lastTaskId = null;

setInterval(function() {
  var queue = detectQueue();
  var taskId = detectTaskId();

  if (queue && (queue !== lastQueue || taskId !== lastTaskId)) {
    // Only claim if queue belongs to SAFET
    if (typeof QUEUE_MAP_SAFET !== "undefined" && QUEUE_MAP_SAFET[queue]) {
      lastQueue = queue;
      lastTaskId = taskId;
      safeSend({ type: "QUEUE_DETECTED", queue: queue, taskId: taskId, profileId: "safet" });
      console.log("[STAR safet] Queue detected:", queue, "Task:", taskId);
    }
  }
}, 1000);

}
