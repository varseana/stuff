if (typeof QUEUE_MAP_SAFET === "undefined") {

var QUEUE_MAP_SAFET = {
  // NA 🇺🇸
  "mre-refund-enforcement-prod@amazon.com": { mp: "NA", targetMin: 0.78, flag: "🇺🇸", label: "MRE" },
  "trms-pi-claims-csba-safe-t@amazon.com": { mp: "NA", targetMin: 2.71, flag: "🇺🇸", label: "CSBA" },
  "trms-pi-claims-csba-safe-t-cn@amazon.com": { mp: "NA", targetMin: 2.71, flag: "🇺🇸", label: "CSBA CN" },
  "trms-pi-claims-prl-sfp-safe-t@amazon.com": { mp: "NA", targetMin: 2.72, flag: "🇺🇸", label: "PRL" },
  "trms-pi-claims-sfp-safe-t@amazon.com": { mp: "NA", targetMin: 2.72, flag: "🇺🇸", label: "SFP" },
  "csba-safe-t-contacts@amazon.com": { mp: "NA", targetMin: 3.21, flag: "🇺🇸", label: "CSBA contacts" },
  "csba-safe-t-contacts-cn@amazon.com": { mp: "NA", targetMin: 3.21, flag: "🇺🇸", label: "CSBA contacts CN" },
  "trms-pi-claims-snowballprl-sfp-safe-t@amazon.com": { mp: "NA", targetMin: 3.81, flag: "🇺🇸", label: "Snowball PRL" },
  "trms-pi-claims-snowballcsba-safe-t-cn@amazon.com": { mp: "NA", targetMin: 3.8, flag: "🇺🇸", label: "Snowball CSBA CN" },
  "trms-pi-claims-snowballcsba-safe-t@amazon.com": { mp: "NA", targetMin: 3.8, flag: "🇺🇸", label: "Snowball CSBA" },
  "trms-pi-claims-snowballsfp-safe-t@amazon.com": { mp: "NA", targetMin: 3.81, flag: "🇺🇸", label: "Snowball SFP" },
  // UK 🇬🇧
  "trms-pi-claims-csba-safe-t@amazon.co.uk": { mp: "UK", targetMin: 2.68, flag: "🇬🇧", label: "CSBA" },
  "trms-pi-claims-csba-safe-t-cn@amazon.co.uk": { mp: "UK", targetMin: 2.68, flag: "🇬🇧", label: "CSBA CN" },
  "trms-pi-claims-prl-sfp-safe-t@amazon.co.uk": { mp: "UK", targetMin: 2.92, flag: "🇬🇧", label: "PRL" },
  "trms-pi-claims-sfp-safe-t@amazon.co.uk": { mp: "UK", targetMin: 2.92, flag: "🇬🇧", label: "SFP" },
  "csba-safe-t-contacts@amazon.co.uk": { mp: "UK", targetMin: 3.18, flag: "🇬🇧", label: "CSBA contacts" },
  "csba-safe-t-contacts-cn@amazon.co.uk": { mp: "UK", targetMin: 3.18, flag: "🇬🇧", label: "CSBA contacts CN" },
  "trms-pi-claims-snowballsfp-safe-t@amazon.co.uk": { mp: "UK", targetMin: 4.09, flag: "🇬🇧", label: "Snowball SFP" },
  "trms-pi-claims-snowballprl-sfp-safe-t@amazon.co.uk": { mp: "UK", targetMin: 4.09, flag: "🇬🇧", label: "Snowball PRL" },
  "trms-pi-claims-snowballcsba-safe-t@amazon.co.uk": { mp: "UK", targetMin: 3.75, flag: "🇬🇧", label: "Snowball CSBA" },
  // IN 🇮🇳
  "trms-pi-claims-eship-safe-t@amazon.in": { mp: "IN", targetMin: 1.82, flag: "🇮🇳", label: "Easy Ship" },
  "trms-pi-cops-sf-switcheroo-safe-t-claims@amazon.in": { mp: "IN", targetMin: 1.96, flag: "🇮🇳", label: "switcheroo" },
  "trms-pi-safe-t-sf-abusive-seller@amazon.in": { mp: "IN", targetMin: 2.15, flag: "🇮🇳", label: "safe-t-sf-abusive" },
  "trms-pi-claims-safe-t-abusive-sellers@amazon.in": { mp: "IN", targetMin: 1.63, flag: "🇮🇳", label: "safe-t-abusive" },
  "trms-pi-claims-mfngold-safe-t-abusive-sellers@amazon.in": { mp: "IN", targetMin: 1.97, flag: "🇮🇳", label: "mfngold abusive" },
  "trms-pi-claims-mfngold-safe-t@amazon.in": { mp: "IN", targetMin: 1.9, flag: "🇮🇳", label: "mfngold" },
  "trms-pi-claims-snowballeship-safe-t@amazon.in": { mp: "IN", targetMin: 2.55, flag: "🇮🇳", label: "snowball-easyship" },
  "trms-pi-cops-snowballsf-switcheroo-safe-t-claims@amazon.in": { mp: "IN", targetMin: 2.75, flag: "🇮🇳", label: "snowball-sf" },
  "trms-pi-claims-snowballsafe-t-abusive-sellers@amazon.in": { mp: "IN", targetMin: 2.29, flag: "🇮🇳", label: "snowball-abusive" },
  // BR 🇧🇷
  "trms-pi-claims-eship-safe-t@amazon.com.br": { mp: "BR", targetMin: 3.34, flag: "🇧🇷", label: "Easy Ship" },
  "trms-pi-claims-mfncsba-safe-t@amazon.com.br": { mp: "BR", targetMin: 5.66, flag: "🇧🇷", label: "MFN-CSBA" },
  "eship-safe-t-contacts@amazon.com.br": { mp: "BR", targetMin: 3.84, flag: "🇧🇷", label: "contacts" },
  "safe-t-br-escalation@amazon.com.br": { mp: "BR", targetMin: 3.84, flag: "🇧🇷", label: "escalation" },
  "trms-pi-claims-snowballeship-safe-t@amazon.com.br": { mp: "BR", targetMin: 4.68, flag: "🇧🇷", label: "snowball-easyship" },
  "trms-pi-claims-snowballmfncsba-safe-t@amazon.com.br": { mp: "BR", targetMin: 7.92, flag: "🇧🇷", label: "snowball-mfncsba" },
  // MX 🇲🇽
  "trms-pi-claims-eship-safe-t@amazon.com.mx": { mp: "MX", targetMin: 3.05, flag: "🇲🇽", label: "Easy Ship" },
  "trms-pi-claims-mfncsba-safe-t@amazon.com.mx": { mp: "MX", targetMin: 6.35, flag: "🇲🇽", label: "MFN-CSBA" },
  "safe-t-mx-escalation@amazon.com.mx": { mp: "MX", targetMin: 3.76, flag: "🇲🇽", label: "escalation" },
  "trms-pi-claims-snowballeship-safe-t@amazon.com.mx": { mp: "MX", targetMin: 4.26, flag: "🇲🇽", label: "snowball-easyship" },
  "trms-pi-claims-snowballmfncsba-safe-t@amazon.com.mx": { mp: "MX", targetMin: 8.89, flag: "🇲🇽", label: "snowball-mfncsba" },
  // ES 🇪🇸
  "trms-pi-claims-prl-sfp-safe-t@amazon.es": { mp: "ES", targetMin: 3.61, flag: "🇪🇸", label: "PRL" },
  "trms-pi-claims-sfp-safe-t@amazon.es": { mp: "ES", targetMin: 3.61, flag: "🇪🇸", label: "SFP" },
  "trms-pi-claims-csba-safe-t-cn@amazon.es": { mp: "ES", targetMin: 3.47, flag: "🇪🇸", label: "CSBA CN" },
  "trms-pi-claims-csba-safe-t@amazon.es": { mp: "ES", targetMin: 3.47, flag: "🇪🇸", label: "CSBA" },
  "csba-safe-t-contacts@amazon.es": { mp: "ES", targetMin: 3.97, flag: "🇪🇸", label: "contacts" },
  "trms-pi-claims-eship-safe-t-contacts@amazon.es": { mp: "ES", targetMin: 6.67, flag: "🇪🇸", label: "eship contacts" },
  "trms-pi-claims-snowballsfp-safe-t@amazon.es": { mp: "ES", targetMin: 5.06, flag: "🇪🇸", label: "Snowball SFP" },
  "trms-pi-claims-snowballprl-sfp-safe-t@amazon.es": { mp: "ES", targetMin: 5.06, flag: "🇪🇸", label: "Snowball PRL" },
  "trms-pi-claims-snowballcsba-safe-t@amazon.es": { mp: "ES", targetMin: 4.86, flag: "🇪🇸", label: "Snowball CSBA" },
  "trms-pi-claims-snowballcsba-safe-t-cn@amazon.es": { mp: "ES", targetMin: 4.86, flag: "🇪🇸", label: "Snowball CSBA-CN" }
};
}
