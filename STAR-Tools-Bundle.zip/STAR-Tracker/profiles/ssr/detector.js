if (!window._starQueueDetectorSSR) {
window._starQueueDetectorSSR = true;

function safeSendSSR(msg) {
  try { chrome.runtime.sendMessage(msg); } catch(e) {}
}

function detectQueueSSR() {
  var text = document.body ? document.body.innerText : "";
  var match = text.match(/Queue:\s*(\S+@amazon\S+)/i);
  return match ? match[1].toLowerCase() : null;
}

function detectTaskIdSSR() {
  var text = document.body ? document.body.innerText : "";
  var match = text.match(/Task ID:\s*(\d+)/i);
  return match ? match[1] : null;
}

var lastQueueSSR = null;
var lastTaskIdSSR = null;

setInterval(function() {
  var queue = detectQueueSSR();
  var taskId = detectTaskIdSSR();

  if (queue && (queue !== lastQueueSSR || taskId !== lastTaskIdSSR)) {
    if (typeof QUEUE_MAP_SSR !== "undefined" && QUEUE_MAP_SSR[queue]) {
      lastQueueSSR = queue;
      lastTaskIdSSR = taskId;
      safeSendSSR({ type: "QUEUE_DETECTED", queue: queue, taskId: taskId, profileId: "ssr" });
      console.log("[STAR ssr] Queue detected:", queue, "Task:", taskId);
    }
  }
}, 1000);

}
