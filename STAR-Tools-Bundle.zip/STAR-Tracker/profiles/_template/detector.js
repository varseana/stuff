// ============================================================
// QUEUE DETECTOR TEMPLATE
// This script runs inside the page where your cases are investigated
// It reads the queue name and task ID from the DOM and sends them to background
// ============================================================

if (!window._starDetectorYOURPROFILE) {
window._starDetectorYOURPROFILE = true;

// CHANGE THIS: Your profile ID (must match registry.js)
var MY_PROFILE_ID = "yourprofile";

function safeSend(msg) {
  try { chrome.runtime.sendMessage(msg); } catch(e) {}
}

// CHANGE THIS: How to detect the queue from the page
function detectQueue() {
  // Example: read from a table cell, header text, etc.
  // var el = document.querySelector(".queue-selector");
  // return el ? el.textContent.trim().toLowerCase() : null;
  var text = document.body ? document.body.innerText : "";
  var match = text.match(/Queue:\s*(\S+@amazon\S+)/i);
  return match ? match[1].toLowerCase() : null;
}

// CHANGE THIS: How to detect the task/case ID from the page
function detectTaskId() {
  var text = document.body ? document.body.innerText : "";
  var match = text.match(/(?:Task ID|Case ID):\s*(\d+)/i);
  return match ? match[1] : null;
}

var lastQueue = null;
var lastTaskId = null;

setInterval(function() {
  var queue = detectQueue();
  var taskId = detectTaskId();

  if (queue && (queue !== lastQueue || taskId !== lastTaskId)) {
    lastQueue = queue;
    lastTaskId = taskId;
    safeSend({ type: "QUEUE_DETECTED", queue: queue, taskId: taskId, profileId: MY_PROFILE_ID });
    console.log("[STAR " + MY_PROFILE_ID + "] Queue detected:", queue, "Task:", taskId);
  }
}, 1000);

}
