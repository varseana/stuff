// ============================================================
// PROFILE CONFIG TEMPLATE
// Copy this folder and fill in the values below
// ============================================================

// 1. Change QUEUE_MAP to your profile's queues
// 2. Each key is the queue email address (must match exactly)
// 3. mp = marketplace code, targetMin = target time in minutes
// 4. flag = emoji flag, label = short display name

if (typeof QUEUE_MAP_YOURPROFILE === "undefined") {
var QUEUE_MAP_YOURPROFILE = {
  // "your-queue@amazon.com": { mp: "NA", targetMin: 3.00, flag: "🇺🇸", label: "Your Queue" },
  // "another-queue@amazon.co.uk": { mp: "UK", targetMin: 2.50, flag: "🇬🇧", label: "Another" },
};
}
