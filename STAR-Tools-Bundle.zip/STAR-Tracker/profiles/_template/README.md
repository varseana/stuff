# How to Create a New AHT Tracker Profile

## Steps

1. **Copy this folder** — Duplicate `_template/` and rename it (e.g., `pat/`)

2. **Edit `config.js`** — Add your queues with email, marketplace, target, and label

3. **Edit `detector.js`** — Change `MY_PROFILE_ID` to your profile ID. Modify `detectQueue()` and `detectTaskId()` to read from your specific page/widget DOM

4. **Edit `popup.html`** — Change the title to your profile name

5. **Copy `popup.js` from safet/** — Change `PROFILE_ID` at the top to your profile ID

6. **Register in `profiles/registry.js`** — Add your profile entry:
   ```js
   { id: "pat", name: "PAT", icon: "🔍", description: "Product Authenticity", popup: "profiles/pat/popup.html" }
   ```

7. **Update `background.js`** — Add `importScripts("profiles/pat/config.js");` and register your queues in `ALL_QUEUES`

8. **Update `manifest.json`** — Add content_scripts entry for your detector on your specific hosts

## File Reference

| File | Purpose |
|------|---------|
| `config.js` | Queue map with emails, targets, labels |
| `detector.js` | Content script that reads queue from page DOM |
| `popup.html` | Dashboard UI |
| `popup.js` | Dashboard logic (copy from safet, change PROFILE_ID) |

## Important

- Profile ID must be unique and lowercase (e.g., "pat", "gating")
- Queue emails must match EXACTLY — typos won't count
- Storage is scoped: `stats_pat`, `caseLog_pat`, etc. — profiles never mix data
- Toggles (auto-accept, etc.) are GLOBAL — shared across all profiles
