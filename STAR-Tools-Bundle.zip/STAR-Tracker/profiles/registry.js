// registro de perfiles ~ agregar nuevos perfiles aqui
// Each profile needs: id, name, icon, description, popup path
// Then create a folder in profiles/ with config.js, detector.js, popup.html/js

var PROFILES = [
  {
    id: "safet",
    name: "SAFE-T",
    icon: "🛡️",
    description: "SAFE-T claim investigations",
    popup: "profiles/safet/popup.html",
    width: 380,
    height: 650
  },
  {
    id: "ssr",
    name: "SSR",
    icon: "📋",
    description: "Strategic Sellers Review",
    popup: "profiles/ssr/popup.html",
    width: 380,
    height: 650
  },
  {
    id: "pat",
    name: "PAT",
    icon: "🔍",
    description: "Product Authenticity",
    popup: "profiles/pat/popup.html",
    width: 380,
    height: 650
  }
];
