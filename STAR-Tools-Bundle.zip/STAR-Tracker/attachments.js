if (!window._starAttachmentsLoaded) {
window._starAttachmentsLoaded = true;

// corre en TODOS los frames de paragon ~ abre attachments automaticamente + detecta el submit
// este archivo es el que hace el trabajo sucio dentro de los iframes

var _starLite = false;
chrome.storage.local.get(["liteMode"], function(r) { _starLite = !!r.liteMode; });
chrome.storage.onChanged.addListener(function(c) { if (c.liteMode) _starLite = !!c.liteMode.newValue; });

function safeSend(msg) {
  try { chrome.runtime.sendMessage(msg); } catch(e) {}
}

// ⁘[ ABRIR ATTACHMENTS AUTOMATICAMENTE ]⁘
// busca links de attachments del seller y los abre en tabs nuevos, pa no tener que clickear uno por uno

let autoOpenEnabled = false;
let openedUrls = {};

chrome.storage.local.get(["autoOpenAttachments"], (res) => {
  autoOpenEnabled = res.autoOpenAttachments || false;
});

chrome.storage.onChanged.addListener((changes) => {
  if (changes.autoOpenAttachments) autoOpenEnabled = changes.autoOpenAttachments.newValue;
});

function findAttachments() {
  const urls = [];

  document.querySelectorAll("a.claimAttachmentLink[data-download-url]").forEach(a => {
    urls.push(a.getAttribute("data-download-url"));
  });

  document.querySelectorAll("iframe[srcdoc]").forEach(iframe => {
    try {
      const doc = iframe.contentDocument;
      if (doc) {
        doc.querySelectorAll("a.claimAttachmentLink[data-download-url]").forEach(a => {
          urls.push(a.getAttribute("data-download-url"));
        });
      }
    } catch(e) {}
  });

  return urls;
}

function openAttachments() {
  const urls = findAttachments();
  let opened = 0;
  for (const url of urls) {
    if (url && !openedUrls[url]) {
      openedUrls[url] = true;
      window.open(url, "_blank");
      opened++;
    }
  }
  if (opened > 0) console.log("[STAR] Auto-opened " + opened + " attachments");
}

(function loopAttach() {
  if (autoOpenEnabled) {
    const urls = findAttachments();
    if (urls.length > 0) {
      const newUrls = urls.filter(u => !openedUrls[u]);
      if (newUrls.length > 0) openAttachments();
    }
  }
  setTimeout(loopAttach, _starLite ? 5000 : 2000);
})();

// ⁘[ DETECCION DEL BOTON SUBMIT ]⁘
// intercepta el click en Submit como señal definitiva de que el caso termino
// manda CASE_SUBMITTED al background pa que cierre el timer de una
// esto es mas rapido que esperar a que desaparezca la card del lobby

// ⁘[ DETECCION DE QUEUE DESDE EL DOM ]⁘
// fuente backup de la queue: lee el input oculto #queue_name de los iframes
// esto atrapa queues que detector.js no pudo detectar (cuando el iframe ctps no carga)

let lastDetectedQueue = null;

function detectQueueFromDOM() {
  // revisar hidden input en current frame
  var qInput = document.getElementById("queue_name");
  if (qInput && qInput.value) {
    var queue = qInput.value.trim().toLowerCase();
    if (queue && queue !== lastDetectedQueue && queue.indexOf("@amazon") !== -1) {
      lastDetectedQueue = queue;
      // sacar caseId de claim_id o URL
      var claimIdEl = document.getElementById("claim_id");
      var taskId = claimIdEl ? claimIdEl.value : null;
      if (!taskId) {
        var urlMatch = window.location.href.match(/[?&](?:caseId|taskId)=(\d+)/i);
        if (urlMatch) taskId = urlMatch[1];
      }
      // chekear data-widget-param-task-id en el contenedor padre
      if (!taskId) {
        var widget = document.querySelector("[data-widget-param-task-id]");
        if (widget) taskId = widget.getAttribute("data-widget-param-task-id");
      }
      if (taskId) {
        safeSend({ type: "QUEUE_DETECTED", queue: queue, taskId: taskId, profileId: null });
        console.log("[STAR] Queue from DOM:", queue, "taskId:", taskId);
      }
    }
  }

  // chquear srcdoc iframes para buscar queue_name
  document.querySelectorAll("iframe[srcdoc]").forEach(function(iframe) {
    try {
      var doc = iframe.contentDocument;
      if (!doc) return;
      var q = doc.getElementById("queue_name");
      if (q && q.value) {
        var queue = q.value.trim().toLowerCase();
        if (queue && queue !== lastDetectedQueue && queue.indexOf("@amazon") !== -1) {
          lastDetectedQueue = queue;
          var taskEl = doc.getElementById("claim_id");
          var taskId = taskEl ? taskEl.value : null;
          if (!taskId) {
            var container = iframe.closest("[data-widget-param-task-id]");
            if (container) taskId = container.getAttribute("data-widget-param-task-id");
          }
          if (taskId) {
            safeSend({ type: "QUEUE_DETECTED", queue: queue, taskId: taskId, profileId: null });
            console.log("[STAR] Queue from iframe DOM:", queue, "taskId:", taskId);
          }
        }
      }
    } catch(e) {}
  });
}

(function loopQueue() {
  detectQueueFromDOM();
  setTimeout(loopQueue, _starLite ? 5000 : 2000);
})();

let submitWired = false;

function wireSubmitButton() {
  if (submitWired) return;
  const btn = document.getElementById("btn_claimActionSubmitNative");
  if (!btn) return;

  submitWired = true;
  btn.addEventListener("click", () => {
    let caseId = null;
    let queue = null;
    let taskId = null;

    const text = document.body.innerText || "";

    const caseMatch = text.match(/Case(?:\s*ID)?[:\s]+(\d{8,})/i);
    if (caseMatch) caseId = caseMatch[1];

    if (!caseId) {
      const urlMatch = window.location.href.match(/[?&]caseId=(\d+)/i);
      if (urlMatch) caseId = urlMatch[1];
    }

    const queueMatch = text.match(/Queue:\s*(\S+@amazon\S+)/i);
    if (queueMatch) queue = queueMatch[1].toLowerCase();

    const taskMatch = text.match(/Task\s*ID:\s*(\d+)/i);
    if (taskMatch) taskId = taskMatch[1];

    console.log("[STAR] Submit clicked - caseId:", caseId, "taskId:", taskId, "queue:", queue);
    safeSend({
      type: "CASE_SUBMITTED",
      caseId: caseId,
      taskId: taskId,
      queue: queue
    });

    submitWired = false;
  }, { once: true });

  console.log("[STAR] Submit button wired");
}

(function loopSubmit() {
  wireSubmitButton();
  setTimeout(loopSubmit, _starLite ? 3000 : 1000);
})();

// ⁘[ KEYWORD SCANNER ]⁘
// cada frame escanea su propio texto y reporta matches al content.js via background

var _kwScannedFrame = false;

function kwScanFrame() {
  if (_kwScannedFrame) return;
  // escanear este frame + iframes hermanos accesibles desde top
  var texts = [];
  var selfText = document.body ? document.body.innerText || "" : "";
  if (selfText.length > 20) texts.push(selfText);
  try {
    var topDoc = window.top.document;
    topDoc.querySelectorAll("iframe").forEach(function(f) {
      try {
        var d = f.contentDocument;
        if (d && d.body && d.body.innerText.length > 20) texts.push(d.body.innerText);
      } catch(e) {}
    });
  } catch(e) {}
  var text = texts.join("\n");
  if (text.length < 20) return;
  console.log("[STAR KW] scanning, total text length:", text.length, "from", texts.length, "sources");

  chrome.storage.local.get(["starKeywords"], function(res) {
    var keywords = (res.starKeywords || []).filter(function(k) { return k.enabled; });
    console.log("[STAR KW] keywords:", keywords.length);
    if (!keywords.length) return;

    var matches = [];
    var textLower = text.toLowerCase();
    keywords.forEach(function(kw) {
      if (textLower.indexOf(kw.text.toLowerCase()) !== -1) matches.push(kw.text);
    });

    console.log("[STAR KW] matches:", matches);
    if (matches.length) {
      _kwScannedFrame = true;
      safeSend({ type: "KEYWORD_MATCHES", matches: matches });
    }
  });
}

// esperar a que el frame cargue su contenido
setTimeout(kwScanFrame, 3000);
setTimeout(kwScanFrame, 8000);

// ⁘[ AUTO-OPEN TOOLS ]⁘
// escucha el mensaje del background y clickea los links de Grass/OBLT/SPOT
var _aotLastTaskId = null;
var _aotToolLabels = { grass: "Grass", oblt: "OBLT", spot: "SPOT" };

function _aotFindToolLink(toolId) {
  var label = _aotToolLabels[toolId];
  if (!label) return null;
  // solo buscar en ESTE frame ~ no en iframes hijos
  // attachments.js ya corre en cada frame, el que tiene los links lo encuentra directo
  return _aotScanDoc(document, label);
}

function _aotScanDoc(doc, label) {
  // buscar <b>LABEL</b> y agarrar el <a> que le sigue inmediatamente
  var bolds = doc.querySelectorAll("b");
  for (var i = 0; i < bolds.length; i++) {
    if (bolds[i].textContent.trim() === label) {
      // caminar los siblings hasta encontrar el primer <a>
      var node = bolds[i].nextSibling;
      while (node) {
        if (node.nodeType === 1 && node.tagName === "A") return node;
        node = node.nextSibling;
      }
    }
  }
  return null;
}

function _aotOpenTools(tools, taskId) {
  if (_aotLastTaskId === taskId) { console.log("[STAR AOT] Skipped (dedup):", taskId); return; }
  _aotLastTaskId = taskId;
  var pending = tools.filter(function(t) { return t in _aotToolLabels; });
  if (!pending.length) { console.log("[STAR AOT] No matching tools in this frame"); return; }
  // solo actuar si este frame puede encontrar al menos un tool link
  var hasAny = false;
  for (var t = 0; t < pending.length; t++) { if (_aotFindToolLink(pending[t])) { hasAny = true; break; } }
  if (!hasAny) { console.log("[STAR AOT] No tool links found in this frame, skipping"); return; }
  console.log("[STAR AOT] Processing tools:", pending.join(","), "taskId:", taskId, "frame:", window.location.href.substring(0, 80));
  var attempts = 0;
  var maxAttempts = 8;
  var opened = {};
  function tryOpen() {
    var remaining = [];
    pending.forEach(function(toolId, idx) {
      if (opened[toolId]) return;
      var link = _aotFindToolLink(toolId);
      if (link) {
        opened[toolId] = true;
        setTimeout(function() {
          var href = link.getAttribute("href");
          var onclick = link.getAttribute("onclick");
          if (onclick) {
            link.dispatchEvent(new MouseEvent("click", { bubbles: false }));
          } else if (href && href !== "#") {
            window.open(href.indexOf("http") === 0 ? href : "https://paragon-na.amazon.com" + href, "_blank");
          }
          console.log("[STAR AOT] Opened:", toolId);
        }, idx * 500);
      } else {
        remaining.push(toolId);
      }
    });
    pending = remaining;
    attempts++;
    if (pending.length && attempts < maxAttempts) {
      setTimeout(tryOpen, 2000);
    }
  }
  tryOpen();
}

// solo el frame que tiene los tool links deberia actuar
// los demas frames no van a encontrar los links y no haran nada
chrome.runtime.onMessage.addListener(function(msg) {
  if (msg.type === "AUTO_OPEN_TOOLS" && msg.tools && msg.taskId) {
    _aotOpenTools(msg.tools, msg.taskId);
  }
});

}
