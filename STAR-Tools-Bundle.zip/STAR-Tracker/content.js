if (!window._starContentLoaded) {
window._starContentLoaded = true;

console.log("[STAR content.js] Loaded on:", window.location.href);

// corre en el lobby de paragon + view-case ~ detecta casos, timer interno, status del agente
// basicamente el ojo que todo lo ve en paragon

// ⁘[ MODO OSCURO DE PARAGON ]⁘
// invierte los colores de toda la pagina pa que no te quedes ciego a las 3am
const DARK_CSS_ID = "_star-paragon-dark";
const DARK_STYLE = `
html, body { background-color: #c9cbd7 !important; }
html { filter: invert(1) hue-rotate(180deg) !important; }
img, video, picture, canvas, svg image,
[style*="background-image"] { filter: invert(1) hue-rotate(180deg) !important; }
`;

function applyParagonDark(on) {
  let el = document.getElementById(DARK_CSS_ID);
  if (on && !el) {
    el = document.createElement("style");
    el.id = DARK_CSS_ID;
    el.textContent = DARK_STYLE;
    document.documentElement.appendChild(el);
  } else if (!on && el) {
    el.remove();
  }
}

chrome.storage.local.get(["paragonDarkMode"], (res) => applyParagonDark(res.paragonDarkMode || false));
chrome.storage.onChanged.addListener((changes) => {
  if (changes.paragonDarkMode) applyParagonDark(changes.paragonDarkMode.newValue);
});

// mantener el tab activo con un sonido invisible
// chrome mata los tabs inactivos, este truco lo evita con un oscilador silencioso
(function keepAlive() {
  var started = false;
  function start() {
    if (started) return;
    started = true;
    var ctx = new (window.AudioContext || window.webkitAudioContext)();
    var osc = ctx.createOscillator();
    var gain = ctx.createGain();
    gain.gain.value = 0.00001;
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
  }
  document.addEventListener("click", start, { once: true });
})();

function safeSend(msg) {
  try { chrome.runtime.sendMessage(msg); } catch(e) {}
}

function devLog(msg, cat) {
  chrome.storage.local.get(["devMode"], function(res) {
    if (!res.devMode) return;
    chrome.storage.session.get(["devLog"], function(r) {
      var logs = r.devLog || [];
      logs.push({ time: new Date().toLocaleTimeString(), msg: msg, cat: cat || "content" });
      if (logs.length > 100) logs = logs.slice(-100);
      chrome.storage.session.set({ devLog: logs });
    });
  });
}

// casos activos guardados en session storage pa que sobrevivan cuando navegas entre paginas
// { caseId: { startedAt, region } } ~ startedAt es cuando empezo el caso en milisegundos
let activeCases = {};
let endedCases = new Map();
let lastStatus = null;
let statusStart = null;

// cargar casos activos del session storage al arrancar
chrome.storage.session.get(["activeCases"], (res) => {
  if (res.activeCases) {
    chrome.storage.local.get(["activeProfile"], (pres) => {
      // safet: 1hr max, ssr/pat: 4hr (casos largos)
      var maxAge = (pres.activeProfile === "safet" ? 1 : 4) * 60 * 60 * 1000;
      var now = Date.now();
      var cleaned = {};
      var count = 0;
      for (var id in res.activeCases) {
        var c = res.activeCases[id];
        if (c && c.startedAt && (now - c.startedAt) < maxAge && /^\d{8,}$/.test(id) && count < 10) {
          cleaned[id] = c;
          count++;
        }
      }
      activeCases = cleaned;
      if (Object.keys(cleaned).length !== Object.keys(res.activeCases).length) {
        persistActiveCases();
      }
      console.log("[STAR] Restored active cases:", Object.keys(activeCases), "maxAge:", maxAge / 3600000 + "hr");
    });
  }
});

function persistActiveCases() {
  chrome.storage.session.set({ activeCases: activeCases });
  chrome.storage.local.set({ activeCasesData: activeCases });
}

function parseTime(t) {
  const parts = t.split(":").map(Number);
  if (parts.length === 2) return parts[0] * 60 + parts[1];
  if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
  return 0;
}

function getCaseCards() {
  const cards = document.querySelectorAll("kat-card#taskItem");
  const result = [];
  cards.forEach(card => {
    const link = card.querySelector("a.case-type");
    if (!link) return;
    const match = link.textContent.match(/Case:\s*(\d+)/);
    if (!match) return;
    const timer = card.querySelector("#taskTimer");
    const paragonTime = timer ? parseTime(timer.textContent.trim()) : 0;
    const regionMatch = link.textContent.match(/\((EU|NA)\)/i);
    const region = regionMatch ? regionMatch[1].toUpperCase() : null;
    result.push({ caseId: match[1], paragonTime: paragonTime, region: region });
  });
  return result;
}

// ⁘[ DETECCION DE CASOS (timer interno) ]⁘
// cada segundo revisamos las cards del lobby pa ver si hay casos nuevos o terminados

function checkTimers() {
  const currentCards = getCaseCards();
  const currentIds = new Set(currentCards.map(c => c.caseId));

  // detectar casos que ya se fueron ~ si la card desaparecio, el caso termino
  for (const id of Object.keys(activeCases)) {
    if (!currentIds.has(id) && !endedCases.has(id)) {
      const elapsed = Math.round((Date.now() - activeCases[id].startedAt) / 1000);
      const region = activeCases[id].region;
      endedCases.set(id, Date.now());
      console.log("[STAR] Caso terminado:", id, elapsed + "s (internal timer)", "region:", region);
      devLog("⏹ Ended: " + id + " " + elapsed + "s " + (region || ""), "content");
      safeSend({ type: "CASE_ENDED", seconds: elapsed, caseId: id, region: region });
      delete activeCases[id];
      persistActiveCases();
    }
  }

  // detectar casos nuevos ~ si aparece una card que no teniamos, empezo un caso
  for (const card of currentCards) {
    if (endedCases.has(card.caseId) && !activeCases[card.caseId]) {
      if (Date.now() - endedCases.get(card.caseId) > 30000) {
        endedCases.delete(card.caseId);
      } else {
        continue;
      }
    }

    if (!activeCases[card.caseId]) {
      activeCases[card.caseId] = {
        startedAt: Date.now() - (card.paragonTime * 1000),
        region: card.region
      };
      safeSend({ type: "CASE_STARTED", caseId: card.caseId, region: card.region });
      console.log("[STAR] Caso iniciado:", card.caseId, "region:", card.region, "(paragon offset:", card.paragonTime + "s)");
      devLog("▶ Started: " + card.caseId + " " + (card.region || "") + " offset:" + card.paragonTime + "s", "content");
      persistActiveCases();

      // si el caso ya estaba corriendo (paragonTime > 5s), re-inyectar los detectors
      // esto pasa cuando recargas la pagina con un caso abierto
      if (card.paragonTime > 5 && !window._starReconnected) {
        window._starReconnected = true;
        // inyectar de una + reintentar en 5s por si los iframes cargan tarde (clasico paragon)
        chrome.runtime.sendMessage({ type: "RECONNECT_DETECTORS" });
        setTimeout(function() { chrome.runtime.sendMessage({ type: "RECONNECT_DETECTORS" }); }, 5000);
        devLog("🔄 Auto-reconnect: case already running (" + card.paragonTime + "s)", "content");
      }
    }
  }
}

// throttle pa que el observer no dispare checkTimers 50 veces por segundo
var _checkScheduled = false;
function scheduleCheck() {
  if (_checkScheduled) return;
  _checkScheduled = true;
  requestAnimationFrame(function() { _checkScheduled = false; checkTimers(); });
}

const observer = new MutationObserver(scheduleCheck);
var _observerActive = false;

function startObserving() {
  if (document.body) {
    chrome.storage.local.get(["liteMode"], function(lr) {
      if (!lr.liteMode) {
        observer.observe(document.body, { childList: true, subtree: true, characterData: true });
        _observerActive = true;
      }
    });
    checkTimers();
  } else {
    setTimeout(startObserving, 100);
  }
}

// reaccionar a cambios de lite mode en vivo
chrome.storage.onChanged.addListener(function(changes) {
  if (changes.liteMode) {
    if (changes.liteMode.newValue && _observerActive) {
      observer.disconnect();
      _observerActive = false;
    } else if (!changes.liteMode.newValue && !_observerActive && document.body) {
      observer.observe(document.body, { childList: true, subtree: true, characterData: true });
      _observerActive = true;
    }
  }
});

startObserving();
setInterval(checkTimers, 1000);

// limpiar endedCases viejos de mas de 6 horas cada 30 min, pa no acumular basura
setInterval(() => {
  const sixHours = 6 * 60 * 60 * 1000;
  const now = Date.now();
  for (const [id, ts] of endedCases) {
    if (now - ts > sixHours) endedCases.delete(id);
  }
}, 30 * 60 * 1000);

// ⁘[ AUTO-ACCEPT, AUTO-INCREMENT Y AUTO-CLEAN ]⁘
// las 3 automatizaciones que te ahorran clicks: aceptar caso, subir task, limpiar missed

let autoAcceptEnabled = false;
let autoCleanEnabled = false;
let autoIncrementEnabled = false;

chrome.storage.local.get(["autoAccept", "autoClean", "autoIncrement"], (res) => {
  autoAcceptEnabled = res.autoAccept || false;
  autoCleanEnabled = res.autoClean || false;
  autoIncrementEnabled = res.autoIncrement || false;
});

chrome.storage.onChanged.addListener((changes) => {
  if (changes.autoAccept) autoAcceptEnabled = changes.autoAccept.newValue;
  if (changes.autoClean) autoCleanEnabled = changes.autoClean.newValue;
  if (changes.autoIncrement) autoIncrementEnabled = changes.autoIncrement.newValue;
});

setInterval(() => {
  if (autoAcceptEnabled) {
    const link = document.querySelector(".notification-action a");
    if (link && link.textContent.trim() === "Accept") {
      link.click();
      console.log("[STAR] Auto-accepted case");
    }
  }

  if (autoIncrementEnabled) {
    const incBtn = document.querySelector(".increase-button kat-button button");
    if (incBtn && incBtn.textContent.trim() === "Increase Task") {
      incBtn.click();
      console.log("[STAR] Auto-clicked Increase Task");
    }
  }

  if (autoCleanEnabled) {
    const btn = document.querySelector(".missed-action");
    if (btn && btn.textContent.trim() === "Change AUX to available") {
      btn.click();
      console.log("[STAR] Auto-cleaned missed case");
      safeSend({ type: "MISSED_CLEANED" });
    }
  }
}, 1000);

// ⁘[ TRACKING DEL STATUS DEL AGENTE ]⁘
// content.js solo avisa "cambie a X" ~ el background lleva el timer interno
// manda paragonTimer pa que el background pueda recuperar tiempo si arranco tarde

var _lastSentStatus = null;
var _auxWaitingForTimer = null; // si el primer status tiene paragonTimer=0, esperamos a que suba

setInterval(function() {
  var el = document.querySelector(".agentStatusText");
  if (!el) return;
  var status = el.textContent.trim();
  if (!status) return;

  var timerEl = document.querySelector(".timerText");
  var paragonTimer = timerEl ? parseTime(timerEl.textContent.trim()) : 0;

  // widget: raw status + timer de paragon
  chrome.storage.local.set({ auxLiveStatus: { status: status, paragonTimer: paragonTimer, ts: Date.now() } });

  if (status !== _lastSentStatus) {
    if (_lastSentStatus === null && paragonTimer < 3) {
      // primer reporte despues de cargar ~ paragon aun no renderizo el timer real
      // esperamos a que suba pa mandar el paragonTimer correcto al recovery
      _auxWaitingForTimer = status;
      return;
    }
    console.log("[STAR AUX] Status changed:", _lastSentStatus, "→", status, "| paragonTimer:", paragonTimer + "s");
    safeSend({ type: "AUX_STATUS_CHANGED", status: status, paragonTimer: paragonTimer });
    _lastSentStatus = status;
    _auxWaitingForTimer = null;
  } else if (_auxWaitingForTimer && paragonTimer >= 3) {
    // el timer ya subio ~ ahora si mandamos el primer reporte con el valor real
    console.log("[STAR AUX] First report (delayed):", status, "| paragonTimer:", paragonTimer + "s");
    safeSend({ type: "AUX_STATUS_CHANGED", status: status, paragonTimer: paragonTimer });
    _lastSentStatus = status;
    _auxWaitingForTimer = null;
  }
}, 1000);

// ⁘[ WIDGET FLOTANTE se mudo a widget.js (corre en todas las paginas) ]⁘

// ⁘[ KEYWORD ALERTS ]⁘
// escanea el caso cuando carga y alerta si encuentra keywords configuradas
// solo corre en view-case, no en lobby

var _kwModalQueue = [];
var _kwModalActive = false;
var _kwShown = {};

// escuchar matches de los iframes (via background relay)
chrome.runtime.onMessage.addListener(function(msg) {
  if (msg.type === "SHOW_KEYWORD_ALERTS" && msg.matches) {
    msg.matches.forEach(function(kw) {
      if (!_kwShown[kw.toLowerCase()]) {
        _kwShown[kw.toLowerCase()] = true;
        _kwModalQueue.push(kw);
      }
    });
    kwShowNext();
  }
});

// escanear el top frame tambien (tiene texto visible fuera de iframes)
function kwScanTopFrame() {
  if (!/view-case/i.test(location.href)) return;
  var text = document.body ? document.body.innerText || "" : "";
  if (text.length < 50) return;
  chrome.storage.local.get(["starKeywords"], function(res) {
    var keywords = (res.starKeywords || []).filter(function(k) { return k.enabled; });
    if (!keywords.length) return;
    var textLower = text.toLowerCase();
    keywords.forEach(function(kw) {
      if (textLower.indexOf(kw.text.toLowerCase()) !== -1 && !_kwShown[kw.text.toLowerCase()]) {
        _kwShown[kw.text.toLowerCase()] = true;
        _kwModalQueue.push(kw.text);
      }
    });
    if (_kwModalQueue.length) kwShowNext();
  });
}

function kwShowNext() {
  if (_kwModalActive || !_kwModalQueue.length) return;
  _kwModalActive = true;
  var keyword = _kwModalQueue.shift();
  kwInjectModal(keyword, function() {
    _kwModalActive = false;
    if (_kwModalQueue.length) setTimeout(kwShowNext, 300);
  });
}

function kwInjectModal(keyword, onDismiss) {
  chrome.storage.local.get(["liteMode", "liteCustomBg", "liteCustomText", "liteCustomAccent", "paragonDarkMode"], function(res) {
    var lite = res.liteMode;
    var dark = res.paragonDarkMode;
    var bg, text, accent, border, shadow, blur, overlayBg;
    if (lite) {
      bg = res.liteCustomBg || "#1e1e2e";
      text = res.liteCustomText || "#e6e6e6";
      accent = res.liteCustomAccent || "#006878";
      border = "1px solid " + accent;
      shadow = "0 8px 32px rgba(0,0,0,0.5)";
      blur = "none";
      overlayBg = "rgba(0,0,0,0.6)";
    } else if (dark) {
      bg = "rgba(15,20,40,0.85)";
      text = "#fff";
      accent = "#006878";
      border = "1px solid rgba(255,255,255,0.15)";
      shadow = "0 8px 32px rgba(0,0,0,0.4), inset 0 0 15px -5px rgba(255,255,255,0.2)";
      blur = "blur(16px)";
      overlayBg = "rgba(0,0,0,0.3)";
    } else {
      bg = "rgba(255,255,255,0.88)";
      text = "#1a1a2e";
      accent = "#006878";
      border = "1px solid rgba(0,0,0,0.1)";
      shadow = "0 8px 32px rgba(0,0,0,0.15), inset 0 0 15px -5px rgba(255,255,255,0.5)";
      blur = "blur(16px)";
      overlayBg = "rgba(0,0,0,0.2)";
    }

    // transiciones ~ lite mode no tiene animaciones
    var transition = lite ? "none" : "transform 250ms cubic-bezier(0.34,1.56,0.64,1),opacity 250ms ease-out";
    var btnTransition = lite ? "none" : "transform 150ms cubic-bezier(0.4,0,0.2,1),box-shadow 150ms cubic-bezier(0.4,0,0.2,1)";
    var overlayTransition = lite ? "none" : "opacity 200ms ease-out";

    var overlay = document.createElement("div");
    overlay.id = "_star-kw-overlay";
    overlay.style.cssText = "position:fixed;top:0;left:0;width:100%;height:100%;z-index:999999;display:flex;align-items:center;justify-content:center;background:" + overlayBg + ";backdrop-filter:" + (lite ? "none" : "blur(4px)") + ";-webkit-backdrop-filter:" + (lite ? "none" : "blur(4px)") + ";opacity:" + (lite ? "1" : "0") + ";transition:" + overlayTransition + ";";

    var modal = document.createElement("div");
    modal.style.cssText = "background:" + bg + ";color:" + text + ";border:" + border + ";border-radius:16px;padding:24px 32px;text-align:center;font-family:'Amazon Ember','Segoe UI',Arial,sans-serif;box-shadow:" + shadow + ";backdrop-filter:" + blur + ";-webkit-backdrop-filter:" + blur + ";max-width:400px;width:90%;transform:" + (lite ? "none" : "scale(0.95)") + ";opacity:" + (lite ? "1" : "0") + ";transition:" + transition + ";";

    var label = document.createElement("div");
    label.style.cssText = "font-size:11px;text-transform:uppercase;letter-spacing:2px;opacity:0.5;margin-bottom:8px;font-weight:600;";
    label.textContent = "Keyword Found";

    var kwText = document.createElement("div");
    kwText.style.cssText = "font-size:22px;font-weight:700;margin-bottom:20px;word-break:break-word;color:" + accent + ";";
    kwText.textContent = keyword;

    var btn = document.createElement("button");
    btn.style.cssText = "background:linear-gradient(135deg," + accent + "," + accent + "cc);color:#fff;border:none;border-radius:10px;padding:12px 32px;font-size:13px;font-weight:700;cursor:pointer;letter-spacing:0.5px;transition:" + btnTransition + ";outline:none;";
    btn.textContent = "Acknowledge";
    if (!lite) {
      btn.onmouseover = function() { btn.style.transform = "translateY(-2px)"; btn.style.boxShadow = "0 4px 16px " + accent + "66"; };
      btn.onmouseout = function() { btn.style.transform = ""; btn.style.boxShadow = ""; };
      btn.onfocus = function() { btn.style.boxShadow = "0 0 0 3px " + accent + "44"; };
      btn.onblur = function() { btn.style.boxShadow = ""; };
    }
    btn.onmousedown = function() { if (!lite) btn.style.transform = "scale(0.95)"; };
    btn.onmouseup = function() { if (!lite) btn.style.transform = ""; };
    btn.onclick = function() {
      if (lite) { overlay.remove(); onDismiss(); return; }
      // exit ~ scale down + fade out
      modal.style.transform = "scale(0.97)";
      modal.style.opacity = "0";
      overlay.style.opacity = "0";
      setTimeout(function() { overlay.remove(); onDismiss(); }, 200);
    };

    modal.append(label, kwText, btn);
    overlay.appendChild(modal);
    document.body.appendChild(overlay);

    // entrance ~ spring scale in (lite mode skips)
    if (!lite) {
      requestAnimationFrame(function() {
        requestAnimationFrame(function() {
          overlay.style.opacity = "1";
          modal.style.transform = "scale(1)";
          modal.style.opacity = "1";
        });
      });
    }
  });
}

// escanear cuando la pagina carga
if (/view-case/i.test(location.href)) {
  setTimeout(kwScanTopFrame, 3000);
}

}
