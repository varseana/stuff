function starAlert(msg) { var o = document.createElement("div"); o.className = "star-modal-overlay"; o.innerHTML = '<div class="star-modal"><div class="star-modal-msg"></div><button class="star-modal-ok">OK</button></div>'; o.querySelector(".star-modal-msg").textContent = msg; o.querySelector(".star-modal-ok").onclick = function() { o.remove(); }; document.body.appendChild(o); }
chrome.storage.local.get(["liteMode"], function(r) { if (r.liteMode) document.body.classList.add("lite"); });
var container = document.getElementById("profiles");

PROFILES.forEach(function(p) {
  var btn = document.createElement("button");
  btn.className = "profile-btn";
  btn.innerHTML = '<span class="profile-icon">' + p.icon + '</span>' +
    '<span class="profile-info"><span class="profile-name">' + p.name + '</span>' +
    '<span class="profile-desc">' + (p.description || "") + '</span></span>';
  btn.onclick = function() {
    chrome.storage.local.get(["activeProfile"], function(res) {
      if (res.activeProfile) {
        // si ya hay perfil activo, navegar directo a el
        var active = PROFILES.find(function(pr) { return pr.id === res.activeProfile; });
        if (active) window.location.href = active.popup;
        return;
      }
      chrome.storage.local.set({ activeProfile: p.id });
      // navegar en la misma tab ~ no abrir ventana nueva
      window.location.href = p.popup;
    });
  };
  container.appendChild(btn);
});
