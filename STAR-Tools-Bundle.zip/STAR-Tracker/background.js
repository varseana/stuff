// I don't even get how this fucking code works, but it does.
//
//
//                       uuuuuuuuuuuuuuuuuuuuu.
//                   .u$$$$$$$$$$$$$$$$$$$$$$$$$$W.
//                 u$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$Wu.
//               $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$i
//              $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
//         `    $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
//           .i$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$i
//           $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$W
//          .$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$W
//        .$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$i
//         #$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$.
//         W$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
//$u       #$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$~
//$#      `"$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
//$i        $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
//$$        #$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
//$$         $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
//#$.        $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$#
// $$      $iW$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$!
// $$i      $$$$$$$#"" `"""#$$$$$$$$$$$$$$$$$#""""""#$$$$$$$$$$$$$$$W
// #$$W    `$$$#"            "       !$$$$$`           `"#$$$$$$$$$$#
//  $$$     ``                 ! !iuW$$$$$                 #$$$$$$$#
//  #$$    $u                  $   $$$$$$$                  $$$$$$$~
//   "#    #$$i.               #   $$$$$$$.                 `$$$$$$
//          $$$$$i.                """#$$$$i.               .$$$$#
//          $$$$$$$$!         .   `    $$$$$$$$$i           $$$$$
//          `$$$$$  $iWW   .uW`        #$$$$$$$$$W.       .$$$$$$#
//            "#$$$$$$$$$$$$#`          $$$$$$$$$$$iWiuuuW$$$$$$$$W
//               !#""    ""             `$$$$$$$##$$$$$$$$$$$$$$$$
//          i$$$$    .                   !$$$$$$ .$$$$$$$$$$$$$$$#
//        $$$$$$$$$$`                    $$$$$$$$$Wi$$$$$$#"#$$`
//         #$$$$$$$$$W.                   $$$$$$$$$$$#   ``
//          `$$$$##$$$$!       i$u.  $. .i$$$$$$$$$#""
//             "     `#W       $$$$$$$$$$$$$$$$$$$`      u$#
//                            W$$$$$$$$$$$$$$$$$$      $$$$W
//                            $$`!$$$##$$$$``$$$$      $$$$!
//                           i$" $$$$  $$#"`  """     W$$$$
//                                                   W$$$$!
//                      uW$$  uu  uu.  $$$  $$$Wu#   $$$$$$
//                     ~$$$$iu$$iu$$$uW$$! $$$$$$i .W$$$$$$
//             ..  !   "#$$$$$$$$$$##$$$$$$$$$$$$$$$$$$$$#"
//             $$W  $     "#$$$$$$$iW$$$$$$$$$$$$$$$$$$$$$W
//             $#`   `       ""#$$$$$$$$$$$$$$$$$$$$$$$$$$$
//                              !$$$$$$$$$$$$$$$$$$$$$#`
//                              $$$$$$$$$$$$$$$$$$$$$$!
//                            $$$$$$$$$$$$$$$$$$$$$$$`
//                             $$$$$$$$$$$$$$$$$$$$"
//
// STAR Tracker v3.5 ~ edicion multi-perfil
// hecho por sean v. (@varseana) con poca paciencia

importScripts("profiles/registry.js");

// cargamos los configs de cada perfil, sin esto no sabemos ni que queues existen
importScripts("profiles/safet/config.js");
importScripts("profiles/ssr/config.js");
importScripts("profiles/pat/config.js");

// ⁘[ DEV LOG ]⁘
// pa debuggear sin explicarle a la gente y volverse loco, escribe mensajitos en storage cuando devMode esta on
var MAX_DEV_LOG = 100;
function devLog(msg, cat) {
  chrome.storage.local.get(["devMode"], function(res) {
    if (!res.devMode) return;
    chrome.storage.session.get(["devLog"], function(r) {
      var logs = r.devLog || [];
      logs.push({ time: new Date().toLocaleTimeString(), msg: msg, cat: cat || "bg" });
      if (logs.length > MAX_DEV_LOG) logs = logs.slice(-MAX_DEV_LOG);
      chrome.storage.session.set({ devLog: logs });
    });
  });
}
// ⁘[ LIMPIEZA DE STORAGE ]⁘
// borra logs viejos de mas de 30 dias y le pone un tope de 200 a los no identificados
// porque si no, el storage se llena y chrome se pone triste
var MAX_LOG_DAYS = 30;
var MAX_UNIDENTIFIED = 200;

function cleanupStorage() {
  var cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - MAX_LOG_DAYS);
  var cutoffStr = cutoff.toISOString().slice(0, 10);

  chrome.storage.local.get(null, function(all) {
    var toSave = {};
    var toRemove = [];
    for (var key in all) {
      // limpiar caseLog_*, statsHistory_* y statusTimeHistory ~ si es viejo, fuera
      if (/^(caseLog_|statsHistory_|statusTimeHistory$)/.test(key) && typeof all[key] === "object" && !Array.isArray(all[key])) {
        var obj = all[key];
        var changed = false;
        for (var day in obj) {
          if (day < cutoffStr) { delete obj[day]; changed = true; }
        }
        if (changed) toSave[key] = obj;
      }
      // si hay mas de 200 no identificados, cortamos la lista, sorry not sorry
      if (/^unidentified_/.test(key) && Array.isArray(all[key]) && all[key].length > MAX_UNIDENTIFIED) {
        toSave[key] = all[key].slice(-MAX_UNIDENTIFIED);
      }
    }
    if (Object.keys(toSave).length > 0) {
      chrome.storage.local.set(toSave, function() {
        console.log("[STAR bg] Storage cleanup done");
      });
    }
  });
}

// limpiamos al arrancar y despues cada 24h, como buen aseador
cleanupStorage();
setInterval(cleanupStorage, 24 * 60 * 60 * 1000);

// juntamos TODAS las queues de safet + ssr en un solo mapa gigante
// cada queue tiene su _profileId pa saber de donde viene
var ALL_QUEUES = {};
(function() {
  if (typeof QUEUE_MAP_SAFET !== "undefined") {
    for (var q in QUEUE_MAP_SAFET) {
      ALL_QUEUES[q] = QUEUE_MAP_SAFET[q];
      ALL_QUEUES[q]._profileId = "safet";
    }
  }
  if (typeof QUEUE_MAP_SSR !== "undefined") {
    for (var q in QUEUE_MAP_SSR) {
      ALL_QUEUES[q] = QUEUE_MAP_SSR[q];
      ALL_QUEUES[q]._profileId = "ssr";
    }
  }
  if (typeof QUEUE_MAP_PAT !== "undefined") {
    for (var q in QUEUE_MAP_PAT) {
      ALL_QUEUES[q] = QUEUE_MAP_PAT[q];
      ALL_QUEUES[q]._profileId = "pat";
    }
  }
})();

function safeSet(data) {
  chrome.storage.local.set(data, function() {
    if (chrome.runtime.lastError) {
      console.error("[STAR bg] Storage error:", chrome.runtime.lastError.message);
    }
  });
}

function todayKey() {
  return new Date().toISOString().slice(0, 10);
}

function pKey(key, profileId) {
  return key + "_" + profileId;
}

// mapa de caseId/taskId → { queue, profileId } ~ pa saber que queue tiene cada caso
var caseQueues = {};
var _aotSent = {}; // { tabId_taskId: true } ~ se limpia cuando el tab navega

// limpiar dedup de auto-open cuando el tab recarga o navega
chrome.tabs.onUpdated.addListener(function(tabId, info) {
  if (info.status === "loading") {
    var cleared = 0;
    for (var key in _aotSent) { if (key.indexOf(tabId + "_") === 0) { delete _aotSent[key]; cleared++; } }
    if (cleared) devLog("🔧 AOT dedup cleared for tab " + tabId + " (" + cleared + " keys)", "aot");
  }
});
// timers internos: caseId → cuando empezo (timestamp en ms)
var caseTimers = {};
// mapa inverso: taskId → caseId (pa que el submit encuentre el timer correcto)
var taskToCaseId = {};

function isCaseSaved(caseId, cb) {
  if (!caseId) return cb(false);
  chrome.storage.session.get(["savedCases"], function(res) {
    cb((res.savedCases || {})[caseId] === true);
  });
}

function markCaseSaved(caseId) {
  if (!caseId) return;
  chrome.storage.session.get(["savedCases"], function(res) {
    var saved = res.savedCases || {};
    saved[caseId] = true;
    chrome.storage.session.set({ savedCases: saved });
  });
}

function clearCaseSaved(caseId) {
  if (!caseId) return;
  chrome.storage.session.get(["savedCases"], function(res) {
    var saved = res.savedCases || {};
    delete saved[caseId];
    chrome.storage.session.set({ savedCases: saved });
  });
}

// ⁘[ INYECCION DINAMICA DE DETECTORS ]⁘
// solo inyectar el detector del perfil activo ~ no gastar cpu en queues que no son tuyas
var PROFILE_FILES = {
  safet: ["profiles/safet/config.js", "profiles/safet/detector.js"],
  ssr: ["profiles/ssr/config.js", "profiles/ssr/detector.js"],
  pat: ["profiles/pat/config.js", "profiles/pat/detector.js"]
};

function injectDetectorForProfile(profileId) {
  var files = PROFILE_FILES[profileId];
  if (!files) return;
  devLog("🔧 Injecting detector for " + profileId, "aot");
  chrome.tabs.query({ url: ["https://paragon-eu.amazon.com/*", "https://paragon-na.amazon.com/*"] }, function(tabs) {
    tabs.forEach(function(tab) {
      // resetear guards antes de inyectar ~ si no, el guard bloquea el nuevo codigo
      chrome.scripting.executeScript({
        target: { tabId: tab.id, allFrames: true },
        func: function() { window._starQueueDetectorLoaded = false; window._starQueueDetectorSSR = false; window._starQueueDetectorPAT = false; }
      }).then(function() {
        chrome.scripting.executeScript({
          target: { tabId: tab.id, allFrames: true },
          files: files
        }).catch(function() {});
      }).catch(function() {});
    });
  });
}

// cuando cambia el perfil activo, inyectar su detector
chrome.storage.onChanged.addListener(function(changes) {
  if (changes.activeProfile && changes.activeProfile.newValue) {
    injectDetectorForProfile(changes.activeProfile.newValue);
  }
});

// si ya hay perfil activo al arrancar, inyectar
chrome.storage.local.get("activeProfile", function(res) {
  if (res.activeProfile) injectDetectorForProfile(res.activeProfile);
});

// el launcher ~ abre como popup window, todo se navega adentro
chrome.action.onClicked.addListener(function() {
  chrome.windows.create({
    url: chrome.runtime.getURL("launcher.html"),
    type: "popup",
    width: 380,
    height: 650
  });
});

// guardar casos, me quiero morir, pero bueno
// si dura menos de 10s lo ignoramos (probablemente fue un click accidental)
// si es safet y dura mas de 1hr tambien lo ignoramos (por los outliers y asi gracias Germitan)
// ssr no tiene limite porque esos casos si pueden durar horas lol
function saveCase(queue, seconds, caseId, profileId, region) {
  if (seconds <= 10) return;
  if (profileId === "safet" && seconds > 3600) return;
  if (!profileId) profileId = "safet";

  isCaseSaved(caseId, function(alreadySaved) {
    if (alreadySaved) return;
    markCaseSaved(caseId);

    chrome.storage.local.get(["customQueues_" + profileId, "saveHistory"], function(cres) {
      var custom = cres["customQueues_" + profileId] || {};
      var historyOn = cres.saveHistory || false;
      var hasCustom = Object.values(custom).some(function(v) { return v !== null; });

      var profileQueues = {};
      for (var q in ALL_QUEUES) {
        if (ALL_QUEUES[q]._profileId === profileId) profileQueues[q] = ALL_QUEUES[q];
      }
      var isKnown = queue !== "unknown" && (hasCustom ? (custom[queue] && custom[queue] !== null) : !!profileQueues[queue]);

      if (isKnown) {
        var statsKey = pKey("stats", profileId);
        var histKey = pKey("statsHistory", profileId);
        var logKey = pKey("caseLog", profileId);

        chrome.storage.local.get([statsKey, histKey, logKey], function(res) {
          var stats = res[statsKey] || {};
          if (!stats[queue]) stats[queue] = { totalSeconds: 0, caseCount: 0 };
          stats[queue].totalSeconds += seconds;
          stats[queue].caseCount += 1;

          var toSave = {};
          toSave[statsKey] = stats;

          var day = todayKey();
          if (historyOn) {
            var history = res[histKey] || {};
            if (!history[day]) history[day] = {};
            if (!history[day][queue]) history[day][queue] = { totalSeconds: 0, caseCount: 0 };
            history[day][queue].totalSeconds += seconds;
            history[day][queue].caseCount += 1;
            toSave[histKey] = history;
          }

          var caseLog = res[logKey] || {};
          if (!caseLog[day]) caseLog[day] = [];
          caseLog[day].push({ time: new Date().toLocaleTimeString(), caseId: caseId, queue: queue, seconds: seconds });
          toSave[logKey] = caseLog;

          safeSet(toSave);
          console.log("[STAR bg] ✅ Saved (" + profileId + "):", queue, seconds + "s", "| caseId:", caseId);
          devLog("✅ Saved: " + queue + " " + seconds + "s | case:" + caseId, "bg");
        });
      } else {
        var unidKey = pKey("unidentified", profileId);
        chrome.storage.local.get([unidKey], function(res) {
          var unidentified = res[unidKey] || [];
          unidentified.push({ queue: queue, seconds: seconds, time: new Date().toLocaleTimeString(), date: todayKey(), region: region || "?" });
          var toSave = {};
          toSave[unidKey] = unidentified;
          safeSet(toSave);
          console.log("[STAR bg] Unidentified (" + profileId + "):", queue, seconds + "s");
          devLog("⚠️ Unidentified: " + queue + " " + seconds + "s", "bg");
        });
      }
    });
  });
}

// ⁘[ VENTANA DE MERGE ]⁘
// tanto CASE_ENDED como CASE_SUBMITTED alimentan pendingCases
// esperamos 5 segundos (o hasta que lleguen ambos) y combinamos lo mejor de cada uno
// asi minimizamos los "not identified" ~ el submit trae la queue, el lobby trae el tiempo
// es como un rompecabezas de 2 piezas que a veces llegan en desorden

var pendingCases = {}; // caseId → { submit: {...}, ended: {...}, timer }
var MERGE_WINDOW_MS = 5000;

// ⁘[ AUX TIMER INTERNO ]⁘
// el background lleva el timer ~ content.js solo avisa "cambie a X"
// no importa cuantas tabs manden el mismo cambio, solo se procesa una vez
var _auxCurrentStatus = null;
var _auxStartedAt = null;

function _saveAuxTime(status, seconds) {
  chrome.storage.local.get(["statusTime", "statusTimeDate", "statusTimeHistory", "saveHistory"], function(res) {
    var today = todayKey();
    var statusTime = res.statusTime || {};
    if (res.statusTimeDate !== today) statusTime = {};
    if (!statusTime[status]) statusTime[status] = 0;
    statusTime[status] += seconds;
    var toSave = { statusTime: statusTime, statusTimeDate: today };
    if (res.saveHistory) {
      var history = res.statusTimeHistory || {};
      if (!history[today]) history[today] = {};
      if (!history[today][status]) history[today][status] = 0;
      history[today][status] += seconds;
      toSave.statusTimeHistory = history;
    }
    safeSet(toSave);
  });
}

function resolveCaseId(caseId, taskId) {
  if (caseId) return caseId;
  if (taskId && taskToCaseId[taskId]) return taskToCaseId[taskId];
  return taskId || null;
}

function feedPending(id, source, data) {
  if (!id) return;

  if (!pendingCases[id]) {
    pendingCases[id] = {};
  }
  pendingCases[id][source] = data;

  // si ya llegaron las dos señales, flush de 1, no hay que esperar
  if (pendingCases[id].submit && pendingCases[id].ended) {
    clearTimeout(pendingCases[id].timer);
    flushPending(id);
    return;
  }

  // si no, esperamos la ventana de merge 5secs a ver si llega la otra señal
  if (!pendingCases[id].timer) {
    pendingCases[id].timer = setTimeout(function() {
      flushPending(id);
    }, MERGE_WINDOW_MS);
  }
}

function flushPending(id) {
  var p = pendingCases[id];
  if (!p) return;
  delete pendingCases[id];

  var sub = p.submit || {};
  var end = p.ended || {};

  // preferimos la queue del submit pq es mas confiable pq el inv hizo el submit
  var queue = sub.queue || end.queue || "unknown";
  var taskId = sub.taskId || null;
  var profileId = sub.profileId || end.profileId || "safet";
  var region = sub.region || end.region || null;

  // si no encontramos queue, buscamos en nuestros mapas a ver si ya la teniamos
  if (queue === "unknown" && caseQueues[id]) {
    queue = caseQueues[id].queue;
    profileId = caseQueues[id].profileId;
  }
  if (queue === "unknown" && taskId && caseQueues[taskId]) {
    queue = caseQueues[taskId].queue;
    profileId = caseQueues[taskId].profileId;
  }

  // tiempo: usamos el MAS ALTO de todos los timers ~ si alguno reporta menos, llego tarde
  var bgSeconds = 0;
  if (caseTimers[id]) {
    bgSeconds = Math.round((Date.now() - caseTimers[id]) / 1000);
  }
  var endSeconds = end.seconds || 0;
  var subSeconds = sub.seconds || 0;
  var seconds = Math.max(bgSeconds, endSeconds, subSeconds);

  var sources = [];
  if (p.submit) sources.push("submit");
  if (p.ended) sources.push("card-gone");
  console.log("[STAR bg] Merge flush:", id,
    "| queue:", queue,
    "| final:", seconds + "s",
    "(bg:" + bgSeconds + "s, content:" + endSeconds + "s, submit:" + subSeconds + "s)",
    "| sources:", sources.join("+"),
    "| taskId:", taskId || "none",
    "| region:", region || "?"
  );
  devLog("🔀 Case " + id + " matched → " + queue + " (" + profileId + ") " + seconds + "s", "bg");

  if (queue === "unknown" && id !== "unknown") {
    // ultima oportunidad: esperamos 3s mas por si llega un QUEUE_DETECTED tardio
    setTimeout(function() {
      if (caseQueues[id]) { queue = caseQueues[id].queue; profileId = caseQueues[id].profileId; }
      if (queue === "unknown" && taskId && caseQueues[taskId]) { queue = caseQueues[taskId].queue; profileId = caseQueues[taskId].profileId; }
      saveCase(queue, seconds, id, profileId, region);
      cleanup(id, taskId);
    }, 3000);
  } else {
    saveCase(queue, seconds, id, profileId, region);
    cleanup(id, taskId);
  }
}

function cleanup(caseId, taskId) {
  if (caseId) { delete caseQueues[caseId]; delete caseTimers[caseId]; }
  if (taskId) { delete caseQueues[taskId]; delete taskToCaseId[taskId]; }
}

// limpieza periodica: borra caseQueues/taskToCaseId viejos cada 5 min pa no llenar la memoria
setInterval(function() {
  var activeIds = Object.keys(caseTimers);
  for (var key in caseQueues) {
    if (activeIds.indexOf(key) === -1 && !caseTimers[key]) {
      delete caseQueues[key];
    }
  }
  for (var tid in taskToCaseId) {
    if (!caseTimers[taskToCaseId[tid]]) {
      delete taskToCaseId[tid];
    }
  }
}, 5 * 60 * 1000);

// alimentar el widget flotante con info de la queue (nombre bonito, task, target)
function enrichWidgetCase(caseId, queue) {
  var info = ALL_QUEUES[queue];
  if (!info) return;
  chrome.storage.local.get(["widgetCases"], function(res) {
    var wc = res.widgetCases || {};
    wc[caseId] = {
      queue: queue,
      label: info.label || "",
      flag: info.flag || "",
      targetMin: info.targetMin || 0,
      profileId: info._profileId || "safet",
      mp: info.mp || ""
    };
    chrome.storage.local.set({ widgetCases: wc });
  });
}

// ⁘[ LA JUPA DE CABEZA DE CEBRERO DE AY AY AY AYUDA ]⁘
// aqui llegan todos los mensajes de content.js, attachments.js y los detectors
chrome.runtime.onMessage.addListener(function(msg, sender) {
  if (msg.type === "QUEUE_DETECTED") {
    // resolver profileId: del mensaje, del mapa ALL_QUEUES, o default safet (yolo)
    var detectedProfileId = msg.profileId || (ALL_QUEUES[msg.queue] ? ALL_QUEUES[msg.queue]._profileId : null) || "safet";
    if (msg.taskId) {
      // dedup: si ya procesamos este taskId+queue, no repetir el mapeo
      var existingQ = caseQueues[msg.taskId];
      var isNew = !existingQ || existingQ.queue !== msg.queue;
      caseQueues[msg.taskId] = { queue: msg.queue, profileId: detectedProfileId };
      if (isNew) {
      var matched = false;
      for (var cid in caseTimers) {
        if (!caseQueues[cid] || !caseQueues[cid].queue || caseQueues[cid].queue === "unknown") {
          taskToCaseId[msg.taskId] = cid;
          caseQueues[cid] = { queue: msg.queue, profileId: detectedProfileId };
          var elapsed = Math.round((Date.now() - caseTimers[cid]) / 1000);
          console.log("[STAR bg] Queue mapped:", msg.taskId, "→", msg.queue, "| linked to caseId:", cid, "| running:", elapsed + "s");
          devLog("🔗 Queue: " + msg.queue + " → case:" + cid + " (" + elapsed + "s)", "queue");
          matched = true;
          // mandar info de la queue al widget flotante pa que se vea bonito
          enrichWidgetCase(cid, msg.queue);
          break;
        }
      }
      if (!matched) {
        console.log("[STAR bg] Queue mapped:", msg.taskId, "→", msg.queue, "| NO active case matched. Timers:", Object.keys(caseTimers), "Queued:", Object.keys(caseQueues));
        // igual mandamos al widget por si taskId === caseId (pasa en safet)
        enrichWidgetCase(msg.taskId, msg.queue);
      }
      } // isNew

      // ⁘[ AUTO-OPEN TOOLS ]⁘
      // si es safet, revisar si hay tools configurados pa abrir automaticamente
      if (detectedProfileId === "safet" && sender && sender.tab) {
        var queueInfo = ALL_QUEUES[msg.queue];
        var mp = queueInfo ? queueInfo.mp : null;
        devLog("🔧 AOT check: queue=" + msg.queue + " mp=" + mp + " taskId=" + msg.taskId + " tab=" + sender.tab.id, "aot");
        if (mp) {
          var aotKey = sender.tab.id + "_" + msg.taskId;
          if (_aotSent[aotKey]) {
            devLog("🔧 AOT skipped (dedup): " + aotKey, "aot");
            return;
          }
          _aotSent[aotKey] = true;
          chrome.storage.local.get(["autoOpenTools_safet"], function(r) {
            var cfg = r.autoOpenTools_safet || {};
            devLog("🔧 AOT config: " + JSON.stringify(cfg), "aot");
            var toolsToOpen = [];
            for (var toolId in cfg) {
              if (cfg[toolId] && cfg[toolId].indexOf(mp) !== -1) toolsToOpen.push(toolId);
            }
            if (toolsToOpen.length) {
              chrome.tabs.sendMessage(sender.tab.id, { type: "AUTO_OPEN_TOOLS", tools: toolsToOpen, taskId: msg.taskId, queue: msg.queue }, function(response) {
                if (chrome.runtime.lastError) {
                  devLog("🔧 AOT sendMessage ERROR: " + chrome.runtime.lastError.message, "aot");
                  // si fallo, reintentar en 3s ~ el frame puede no haber cargado aun
                  setTimeout(function() {
                    chrome.tabs.sendMessage(sender.tab.id, { type: "AUTO_OPEN_TOOLS", tools: toolsToOpen, taskId: msg.taskId, queue: msg.queue }, function() {
                      if (chrome.runtime.lastError) devLog("🔧 AOT retry also failed: " + chrome.runtime.lastError.message, "aot");
                      else devLog("🔧 AOT retry delivered", "aot");
                    });
                  }, 3000);
                } else {
                  devLog("🔧 AOT message delivered", "aot");
                }
              });
              devLog("🔧 AOT sent: " + toolsToOpen.join(",") + " mp=" + mp + " task=" + msg.taskId, "aot");
            } else {
              devLog("🔧 AOT no tools matched for mp=" + mp, "aot");
            }
          });
        } else {
          devLog("🔧 AOT no mp resolved for queue=" + msg.queue, "aot");
        }
      }
    }
  }

  if (msg.type === "CASE_STARTED") {
    var id = msg.caseId;
    if (id) {
      clearCaseSaved(id);
      caseTimers[id] = Date.now();
      // si ya teniamos el queue, no la pisamos, solo agregamos la region
      var existing = caseQueues[id] || {};
      if (msg.region) existing.region = msg.region;
      caseQueues[id] = existing;
      // si el queue ya se detecto por taskId (en safet taskId = caseId), linkear
      if (!existing.queue && caseQueues[id]) {
        // buscar si algun taskId ya tiene queue pero no tiene timer -> ese es nuestro match
        for (var tid in caseQueues) {
          if (tid !== id && caseQueues[tid] && caseQueues[tid].queue && !caseTimers[tid]) {
            // tiene queue pero no timer -> probablemente es el nuestro, lo linkeamos
            caseQueues[id] = Object.assign(existing, { queue: caseQueues[tid].queue, profileId: caseQueues[tid].profileId });
            taskToCaseId[tid] = id;
            console.log("[STAR bg] Late-linked queue:", tid, "→", id, "queue:", caseQueues[tid].queue);
            break;
          }
        }
      }
    }
    console.log("[STAR bg] Case started:", id || "unknown", "region:", msg.region || "?", "queue:", (caseQueues[id] || {}).queue || "pending");
    devLog("▶ Case started: " + (id || "?") + " region:" + (msg.region || "?"), "bg");
  }

  if (msg.type === "CASE_ENDED") {
    var caseId = msg.caseId || "unknown";
    var qInfo = caseQueues[caseId] || {};
    console.log("[STAR bg] CASE_ENDED:", caseId, "| content timer:", msg.seconds + "s", "| queue:", qInfo.queue || "unknown", "| region:", msg.region || qInfo.region || "?");
    devLog("⏹ Case ended: " + caseId + " " + msg.seconds + "s queue:" + (qInfo.queue || "?"), "bg");
    feedPending(caseId, "ended", {
      seconds: msg.seconds,
      queue: qInfo.queue || null,
      region: msg.region || qInfo.region || null,
      profileId: qInfo.profileId || null
    });
    // limpiar datos del widget cuando el caso termina
    chrome.storage.local.get(["widgetCases"], function(res) {
      var wc = res.widgetCases || {};
      delete wc[caseId];
      chrome.storage.local.set({ widgetCases: wc });
    });
  }

  if (msg.type === "CASE_SUBMITTED") {
    var caseId = resolveCaseId(msg.caseId, msg.taskId);
    var bgSeconds = caseId && caseTimers[caseId] ? Math.round((Date.now() - caseTimers[caseId]) / 1000) : 0;
    console.log("[STAR bg] CASE_SUBMITTED:", "caseId:", msg.caseId, "taskId:", msg.taskId, "resolved:", caseId, "| bg timer:", bgSeconds + "s", "| queue:", msg.queue || "none");
    devLog("📤 Submitted: case:" + (msg.caseId || "?") + " task:" + (msg.taskId || "?") + " queue:" + (msg.queue || "?"), "bg");
    if (!caseId) {
      console.log("[STAR bg] Submit detected but no ID resolved");
      return;
    }

    // resolver profileId de la queue pa saber a que perfil guardar
    var submitProfileId = "safet";
    if (msg.queue && ALL_QUEUES[msg.queue]) {
      submitProfileId = ALL_QUEUES[msg.queue]._profileId;
    } else if (caseQueues[caseId] && caseQueues[caseId].profileId) {
      submitProfileId = caseQueues[caseId].profileId;
    }

    // guardar la queue pa que CASE_ENDED tambien la pueda usar
    if (msg.queue) {
      caseQueues[caseId] = { queue: msg.queue, profileId: submitProfileId };
      if (msg.taskId) caseQueues[msg.taskId] = { queue: msg.queue, profileId: submitProfileId };
    }

    feedPending(caseId, "submit", {
      seconds: bgSeconds,
      queue: msg.queue || null,
      taskId: msg.taskId || null,
      profileId: submitProfileId
    });
  }

  if (msg.type === "RECONNECT_DETECTORS") {
    var tabId = sender && sender.tab ? sender.tab.id : null;
    if (tabId) {
      // resetear guards y re-inyectar solo el perfil activo
      chrome.scripting.executeScript({
        target: { tabId: tabId, allFrames: true },
        func: function() { window._starQueueDetectorLoaded = false; window._starQueueDetectorSSR = false; window._starQueueDetectorPAT = false; }
      }, function() {
        chrome.storage.local.get("activeProfile", function(res) {
          var files = PROFILE_FILES[res.activeProfile];
          if (files) {
            chrome.scripting.executeScript({
              target: { tabId: tabId, allFrames: true },
              files: files
            });
          }
        });
      });
      devLog("🔄 Auto-reconnected detectors in tab " + tabId, "bg");
    }
  }

  if (msg.type === "MISSED_CLEANED") {
    chrome.storage.local.get(["missedCount"], function(res) {
      safeSet({ missedCount: (res.missedCount || 0) + 1 });
    });
  }

  // ⁘[ AUX STATUS CHANGED ]⁘
  // content.js avisa "cambie a X" ~ background calcula cuanto duro el anterior
  if (msg.type === "AUX_STATUS_CHANGED" && msg.status) {
    if (msg.status === _auxCurrentStatus) return; // misma tab o otra tab reportando lo mismo
    var now = Date.now();

    if (_auxCurrentStatus && _auxStartedAt) {
      // caso normal: habia un status corriendo, calcular duracion y guardar
      var prevStatus = _auxCurrentStatus;
      var seconds = Math.round((now - _auxStartedAt) / 1000);
      if (seconds > 2) {
        console.log("[STAR bg] Aux saved:", prevStatus, seconds + "s", "| now:", msg.status);
        _saveAuxTime(prevStatus, seconds);
      }
    } else if (msg.paragonTimer > 5) {
      // recovery: extension arranco tarde, paragon ya tenia un aux corriendo
      // guardar el tiempo recuperado, pero arrancar timer desde AHORA
      // el widget usa auxWidgetStatus.since backdateado pa mostrar el timer real
      // _auxStartedAt = now pa que el siguiente cambio solo cuente tiempo nuevo
      console.log("[STAR bg] Aux recovered:", msg.status, msg.paragonTimer + "s", "(extension reconnected to existing session)");
      _saveAuxTime(msg.status, msg.paragonTimer);
      _auxCurrentStatus = msg.status;
      _auxStartedAt = now;
      safeSet({ auxWidgetStatus: { status: msg.status, since: now - (msg.paragonTimer * 1000) } });
      return;
    }

    _auxCurrentStatus = msg.status;
    _auxStartedAt = now;
    // escribir una sola vez pa que el widget lea ~ no depender de multiples tabs
    safeSet({ auxWidgetStatus: { status: msg.status, since: now } });
  }

  // ⁘[ KEYWORD MATCHES ]⁘
  if (msg.type === "KEYWORD_MATCHES" && msg.matches && sender.tab) {
    // reenviar al content.js del mismo tab pa que muestre los modals
    chrome.tabs.sendMessage(sender.tab.id, { type: "SHOW_KEYWORD_ALERTS", matches: msg.matches });
  }
});
