// // helpers de storage pa los perfiles del star tracker
// Each profile stores data with a prefix: stats_safet, caseLog_safet, etc.

function profileKey(key, profileId) {
  return key + "_" + profileId;
}

function safeSet(data, cb) {
  chrome.storage.local.set(data, function() {
    if (chrome.runtime.lastError) {
      console.error("[STAR] Storage error:", chrome.runtime.lastError.message);
    }
    if (cb) cb();
  });
}

function profileGet(keys, profileId, cb) {
  var prefixed = keys.map(function(k) { return profileKey(k, profileId); });
  chrome.storage.local.get(prefixed, function(res) {
    var result = {};
    for (var i = 0; i < keys.length; i++) {
      result[keys[i]] = res[prefixed[i]];
    }
    cb(result);
  });
}

function profileSet(data, profileId, cb) {
  var prefixed = {};
  for (var k in data) {
    prefixed[profileKey(k, profileId)] = data[k];
  }
  safeSet(prefixed, cb);
}
